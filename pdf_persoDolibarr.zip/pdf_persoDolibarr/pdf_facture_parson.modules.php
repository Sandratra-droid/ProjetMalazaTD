<?php
/* Copyright (C) 2004-2014	Laurent Destailleur			<eldy@users.sourceforge.net>
 * Copyright (C) 2005-2012	Regis Houssin				<regis.houssin@inodbox.com>
 * Copyright (C) 2008		Raphael Bertrand			<raphael.bertrand@resultic.fr>
 * Copyright (C) 2010-2014	Juanjo Menent				<jmenent@2byte.es>
 * Copyright (C) 2012		Christophe Battarel			<christophe.battarel@altairis.fr>
 * Copyright (C) 2012		Cédric Salvador				<csalvador@gpcsolutions.fr>
 * Copyright (C) 2012-2014	Raphaël Doursenaud			<rdoursenaud@gpcsolutions.fr>
 * Copyright (C) 2015		Marcos García				<marcosgdf@gmail.com>
 * Copyright (C) 2017-2018	Ferran Marcet				<fmarcet@2byte.es>
 * Copyright (C) 2018-2025  Frédéric France				<frederic.france@free.fr>
 * Copyright (C) 2022-2024	Anthony Berton				<anthony.berton@bb2a.fr>
 * Copyright (C) 2022		Charlene Benke				<charlene@patas-monkey.com>
 * Copyright (C) 2024-2025	MDW							<mdeweerd@users.noreply.github.com>
 * Copyright (C) 2024-2025	Nick Fragoulis
 * Copyright (C) 2024-2025	Alexandre Spangaro			<alexandre@inovea-conseil.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 * or see https://www.gnu.org/
 */

/**
 *	\file       htdocs/core/modules/facture/doc/pdf_crabe.modules.php
 *	\ingroup    invoice
 *	\brief      File of class to generate customers invoices from crabe model
 */

require_once DOL_DOCUMENT_ROOT.'/core/modules/facture/modules_facture.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions2.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/pdf.lib.php';


/**
 *	Class to generate the customer invoice PDF with template Crabe
 */
class pdf_facture_parson extends ModelePDFFactures
{
	/**
	 * @var DoliDB Database handler
	 */
	public $db;

	/**
	 * @var string model name
	 */
	public $name;

	/**
	 * @var string model description (short text)
	 */
	public $description;

	/**
	 * @var int 	Save the name of generated file as the main doc when generating a doc with this template
	 */
	public $update_main_doc_field;

	/**
	 * @var string document type
	 */
	public $type;

	/**
	 * Dolibarr version of the loaded document
	 * @var string Version, possible values are: 'development', 'experimental', 'dolibarr', 'dolibarr_deprecated' or a version string like 'x.y.z'''|'development'|'dolibarr'|'experimental'
	 */
	public $version = 'dolibarr';

	/**
	 * @var bool Situation invoice type
	 */
	public $situationinvoice;

	/**
	 * @var float X position for the situation progress column
	 */
	public $posxprogress;

	/**
	 * @var int Category of operation
	 */
	public $categoryOfOperation = -1; // unknown by default


	/**
	 *	Constructor
	 *
	 *  @param		DoliDB		$db      Database handler
	 */
	public function __construct($db)
{
	global $langs, $mysoc;

	$langs->loadLangs(array("main", "bills"));

	$this->db = $db;
	$this->name = "facture_parson";
	$this->description = $langs->trans('PDFCrabeDescription');
	$this->update_main_doc_field = 1;
	$this->type = 'pdf';

	$this->page_largeur = 35;
	$this->page_hauteur = 78;
	$this->format = array($this->page_largeur, $this->page_hauteur);

	$this->marge_gauche = 2;
	$this->marge_droite = 2;
	$this->marge_haute = 2;
	$this->marge_basse = 2;
	$this->corner_radius = 0;

	$this->option_logo = 1;
	$this->option_tva = 1;
	$this->option_modereg = 1;
	$this->option_condreg = 1;
	$this->option_multilang = 1;
	$this->option_escompte = 1;
	$this->option_credit_note = 1;
	$this->option_freetext = 1;
	$this->option_draft_watermark = 1;
	$this->watermark = '';

	$this->posxdesc = $this->marge_gauche + 1;
	$this->posxtva = 0;
	$this->posxup = 18;
	$this->posxqty = 24;
	$this->posxunit = 28;
	$this->posxdiscount = 30;
	$this->posxprogress = 30;
	$this->postotalht = 30;
	$this->posxpicture = $this->posxdesc;

	$this->tva = array();
	$this->tva_array = array();
	$this->localtax1 = array();
	$this->localtax2 = array();
	$this->atleastoneratenotnull = 0;
	$this->atleastonediscount = 0;
	$this->situationinvoice = false;

	if ($mysoc === null) {
		dol_syslog(get_class($this).'::__construct() Global $mysoc should not be null.'. getCallerInfoString(), LOG_ERR);
		return;
	}

	$this->emetteur = $mysoc;
	if (empty($this->emetteur->country_code)) {
		$this->emetteur->country_code = substr($langs->defaultlang, -2);
	}
}
	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	/**
	 *  Function to build pdf onto disk
	 *
	 *  @param		Facture			$object				Object to generate
	 *  @param		Translate		$outputlangs		Lang output object
	 *  @param		string			$srctemplatepath	Full path of source filename for generator using a template file
	 *  @param		int<0,1>		$hidedetails		Do not show line details
	 *  @param		int<0,1>		$hidedesc			Do not show desc
	 *  @param		int<0,1>		$hideref			Do not show ref
	 *  @return		int<-1,1>							1=OK, <=0=KO
	 */
public function write_file($object, $outputlangs, $srctemplatepath = '', $hidedetails = 0, $hidedesc = 0, $hideref = 0)
{
	global $user, $langs, $conf, $mysoc, $hookmanager, $nblines;

	dol_syslog("write_file outputlangs->defaultlang=".(is_object($outputlangs) ? $outputlangs->defaultlang : 'null'));

	if (!is_object($outputlangs)) {
		$outputlangs = $langs;
	}
	if (getDolGlobalString('MAIN_USE_FPDF')) {
		$outputlangs->charset_output = 'ISO-8859-1';
	}

	$outputlangs->loadLangs(array("main", "bills", "products", "dict", "companies", "compta"));

	if ($object->status == $object::STATUS_DRAFT && getDolGlobalString('FACTURE_DRAFT_WATERMARK')) {
		$this->watermark = getDolGlobalString('FACTURE_DRAFT_WATERMARK');
	}

	global $outputlangsbis;
	$outputlangsbis = null;
	if (getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE') && $outputlangs->defaultlang != getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE')) {
		$outputlangsbis = new Translate('', $conf);
		$outputlangsbis->setDefaultLang(getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE'));
		$outputlangsbis->loadLangs(array("main", "bills", "products", "dict", "companies", "compta"));
	}

	$nblines = count($object->lines);
	$isTicket = true;

	$realpatharray = array();
	if (!$isTicket && getDolGlobalString('MAIN_GENERATE_INVOICES_WITH_PICTURE')) {
		for ($i = 0; $i < $nblines; $i++) {
			if (empty($object->lines[$i]->fk_product)) continue;
			$objphoto = new Product($this->db);
			$objphoto->fetch($object->lines[$i]->fk_product);
			$pdir = get_exdir($object->lines[$i]->fk_product, 2, 0, 0, $objphoto, 'product').$object->lines[$i]->fk_product."/photos/";
			$dir = $conf->product->dir_output.'/'.$pdir;
			foreach ($objphoto->liste_photos($dir, 1) as $obj) {
				$realpatharray[$i] = $dir.$obj['photo'];
				break;
			}
		}
	}

	if (count($realpatharray) == 0) {
		$this->posxpicture = $this->posxtva;
	}

	if ($conf->facture->dir_output) {
		$object->fetch_thirdparty();

		$deja_regle = $object->getSommePaiement((isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? 1 : 0);
		$amount_credit_notes_included = $object->getSumCreditNotesUsed((isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? 1 : 0);
		$amount_deposits_included = $object->getSumDepositsUsed((isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? 1 : 0);

		if ($object->specimen) {
			$dir = empty($conf->facture->multidir_output[$object->entity ?? $conf->entity]) ? $conf->facture->dir_output : $conf->facture->multidir_output[$object->entity ?? $conf->entity];
			$file = $dir."/SPECIMEN.pdf";
		} else {
			$objectref = dol_sanitizeFileName($object->ref);
			$dir = (empty($conf->facture->multidir_output[$object->entity ?? $conf->entity]) ? $conf->facture->dir_output : $conf->facture->multidir_output[$object->entity ?? $conf->entity])."/".$objectref;
			$file = $dir."/".$objectref.".pdf";
		}

		if (!file_exists($dir) && dol_mkdir($dir) < 0) {
			$this->error = $langs->transnoentities("ErrorCanNotCreateDir", $dir);
			return 0;
		}

		if (file_exists($dir)) {
			if (!is_object($hookmanager)) {
				include_once DOL_DOCUMENT_ROOT.'/core/class/hookmanager.class.php';
				$hookmanager = new HookManager($this->db);
			}
			$hookmanager->initHooks(array('pdfgeneration'));
			$parameters = array('file' => $file, 'object' => $object, 'outputlangs' => $outputlangs);
			global $action;
			$hookmanager->executeHooks('beforePDFCreation', $parameters, $object, $action);

			$nbpayments = count($object->getListOfPayments());

			$pdf = pdf_getInstance($this->format);
			$default_font_size = pdf_getPDFFontSize($outputlangs);
			$pdf->setAutoPageBreak(false, 0);

			$heightforfreetext = 3;
			$heightforfooter = $this->marge_basse + 2;
			$heightforinfotot = 14;

			if (class_exists('TCPDF')) {
				$pdf->setPrintHeader(false);
				$pdf->setPrintFooter(false);
			}
			$pdf->SetFont(pdf_getPDFFont($outputlangs));
			$pdf->Open();
			$pdf->SetDrawColor(128, 128, 128);
			$pdf->SetMargins($this->marge_gauche, $this->marge_haute, $this->marge_droite);

			$this->atleastonediscount = 0;
			$this->situationinvoice = false;

			$categoryOfOperation = 0;
			$nbProduct = 0;
			$nbService = 0;
			for ($i = 0; $i < $nblines; $i++) {
				if ($object->lines[$i]->remise_percent) $this->atleastonediscount++;
				if ($object->lines[$i]->product_type == Product::TYPE_PRODUCT) $nbProduct++;
				elseif ($object->lines[$i]->product_type == Product::TYPE_SERVICE) $nbService++;
			}
			if ($nbProduct > 0 && $nbService > 0) $categoryOfOperation = 2;
			elseif ($nbProduct == 0 && $nbService > 0) $categoryOfOperation = 1;
			$this->categoryOfOperation = $categoryOfOperation;

			if (empty($this->atleastonediscount)) {
				$delta = ($this->posxprogress - $this->posxdiscount);
				$this->posxpicture += $delta;
				$this->posxtva += $delta;
				$this->posxup += $delta;
				$this->posxqty += $delta;
				$this->posxunit += $delta;
				$this->posxdiscount += $delta;
			}

			if ($object->situation_cycle_ref && !getDolGlobalString('MAIN_PDF_HIDE_SITUATION')) {
				$this->situationinvoice = true;
				$shift = 6;
				$this->posxpicture -= $shift;
				$this->posxtva -= $shift;
				$this->posxup -= $shift;
				$this->posxqty -= $shift;
				$this->posxunit -= $shift;
				$this->posxdiscount -= $shift;
				$this->posxprogress -= $shift;
			}

			$pdf->AddPage();
			$top_shift = $this->_pagehead($pdf, $object, 1, $outputlangs, $outputlangsbis);
			$pdf->SetFont('', '', $default_font_size - 1);

			$tab_top = 34 + $top_shift;
			$tab_top_newpage = 10;

			$iniY = $tab_top + 6;
			$curY = $iniY;
			$nexY = $iniY;

			for ($i = 0; $i < $nblines; $i++) {
	$curY = $nexY;
	$pdf->SetFont('', '', $default_font_size - 5);
	$pdf->SetTextColor(0, 0, 0);

	$pdf->setTopMargin($tab_top_newpage);

	pdf_writelinedesc($pdf, $object, $i, $outputlangs, 10, 3, $this->posxdesc - 1, $curY, $hideref, $hidedesc);

	$pdf->SetXY($this->postotalht, $curY);
	$pdf->MultiCell($this->page_largeur - $this->marge_droite - $this->postotalht, 3, pdf_getlinetotalexcltax($object, $i, $outputlangs, $hidedetails), 0, 'R', false);

	$nexY = max($pdf->GetY(), $curY + 4);

	if ($object->lines[$i]->remise_percent) {
		$pdf->SetXY($this->posxdiscount - 2, $curY);
		$pdf->MultiCell(4, 3, pdf_getlineremisepercent($object, $i, $outputlangs, $hidedetails), 0, 'R');
	}

	if ($this->situationinvoice) {
		$pdf->SetXY($this->posxprogress, $curY);
		$pdf->MultiCell(4, 3, pdf_getlineprogress($object, $i, $outputlangs, $hidedetails), 0, 'R');
	}

	$nexY += 1;
}

			$bottomlasttab = 62;

			$posy = $this->_tableau_info($pdf, $object, $bottomlasttab, $outputlangs, $outputlangsbis);
			$posy = $this->_tableau_tot($pdf, $object, $deja_regle, $bottomlasttab, $outputlangs, $outputlangsbis);

			$this->_pagefoot($pdf, $object, $outputlangs, 0, $this->getHeightForQRInvoice($pdf->getPage(), $object, $langs));
			if (method_exists($pdf, 'AliasNbPages')) {
				$pdf->AliasNbPages();
			}

			$pdf->Close();
			$pdf->Output($file, 'F');
			$hookmanager->executeHooks('afterPDFCreation', array('file' => $file, 'object' => $object, 'outputlangs' => $outputlangs), $this, $action);

			dolChmod($file);
			$this->result = array('fullpath' => $file);
			return 1;
		}

		$this->error = $langs->transnoentities("ErrorCanNotCreateDir", $dir);
		return 0;
	}

	$this->error = $langs->transnoentities("ErrorConstantNotDefined", "FAC_OUTPUTDIR");
	return 0;
}
	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore
	/**
	 *  Show payments table
	 *
	 *  @param	TCPDF		$pdf            	Object PDF
	 *  @param  Facture		$object         	Object invoice
	 *  @param  float		$posy           	Position y in PDF
	 *  @param  Translate	$outputlangs    	Object langs for output
	 *  @param  float		$heightforfooter 	Height for footer
	 *  @return float             				Return integer <0 if KO, >0 if OK
	 */
	protected function _tableau_versements(&$pdf, $object, $posy, $outputlangs, $heightforfooter = 0)
	{
		// phpcs:enable

		$sign = 1;
		if ($object->type == 2 && getDolGlobalString('INVOICE_POSITIVE_CREDIT_NOTE')) {
			$sign = -1;
		}

		$current_page = $pdf->getPage();
		$tab3_posx = 120;
		$tab3_top = $posy + 8;
		$tab3_width = 80;
		$tab3_height = 4;
		if ($this->page_largeur < 210) { // To work with US executive format
			$tab3_posx -= 15;
		}

		$default_font_size = pdf_getPDFFontSize($outputlangs);

		$this->_tableau_versements_header($pdf, $object, $outputlangs, $default_font_size, $tab3_posx, $tab3_top, $tab3_width, $tab3_height);

		$y = 0;

		$pdf->SetFont('', '', $default_font_size - 4);


		// Loop on each discount available (deposits and credit notes and excess of payment included)
		$sql = "SELECT re.rowid, re.amount_ht, re.multicurrency_amount_ht, re.amount_tva, re.multicurrency_amount_tva,  re.amount_ttc, re.multicurrency_amount_ttc,";
		$sql .= " re.description, re.fk_facture_source,";
		$sql .= " f.type, f.datef";
		$sql .= " FROM ".MAIN_DB_PREFIX."societe_remise_except as re, ".MAIN_DB_PREFIX."facture as f";
		$sql .= " WHERE re.fk_facture_source = f.rowid AND re.fk_facture = ".((int) $object->id);
		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			$i = 0;
			$invoice = new Facture($this->db);
			while ($i < $num) {
				$y += 3;
				if ($tab3_top + $y >= ($this->page_hauteur - $heightforfooter)) {
					$y = 0;
					$current_page++;
					$pdf->AddPage('', '', true);
					/*if (!empty($tplidx)) {
						$pdf->useTemplate($tplidx);
					}*/
					if (!getDolGlobalInt('MAIN_PDF_DONOTREPEAT_HEAD')) {
						$top_shift = $this->_pagehead($pdf, $object, 0, $outputlangs);
						$tab_top_newpage = (!getDolGlobalInt('MAIN_PDF_DONOTREPEAT_HEAD') ? 42 + $top_shift : 10);
					}
					$pdf->setPage($current_page);
					$this->_tableau_versements_header($pdf, $object, $outputlangs, $default_font_size, $tab3_posx, $tab3_top + $y - 3, $tab3_width, $tab3_height);
				}

				$obj = $this->db->fetch_object($resql);

				if ($obj->type == 2) {
					$text = $outputlangs->transnoentities("CreditNote");
				} elseif ($obj->type == 3) {
					$text = $outputlangs->transnoentities("Deposit");
				} elseif ($obj->type == 0) {
					$text = $outputlangs->transnoentities("ExcessReceived");
				} else {
					$text = $outputlangs->transnoentities("UnknownType");
				}

				$invoice->fetch($obj->fk_facture_source);

				$pdf->SetXY($tab3_posx, $tab3_top + $y);
				$pdf->MultiCell(20, 3, dol_print_date($this->db->jdate($obj->datef), 'day', false, $outputlangs, true), 0, 'L', false);
				$pdf->SetXY($tab3_posx + 21, $tab3_top + $y);
				$pdf->MultiCell(20, 3, price((isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? $obj->multicurrency_amount_ttc : $obj->amount_ttc, 0, $outputlangs), 0, 'L', false);
				$pdf->SetXY($tab3_posx + 40, $tab3_top + $y);
				$pdf->MultiCell(20, 3, $text, 0, 'L', false);
				$pdf->SetXY($tab3_posx + 58, $tab3_top + $y);
				$pdf->MultiCell(20, 3, $invoice->ref, 0, 'L', false);

				$pdf->line($tab3_posx, $tab3_top + $y + 3, $tab3_posx + $tab3_width, $tab3_top + $y + 3);

				$i++;
			}
		} else {
			$this->error = $this->db->lasterror();
			return -1;
		}

		// Loop on each payment
		// TODO Call getListOfPayments instead of hard coded sql
		$sql = "SELECT p.datep as date, p.fk_paiement, p.num_paiement as num, pf.amount as amount, pf.multicurrency_amount,";
		$sql .= " cp.code";
		$sql .= " FROM ".MAIN_DB_PREFIX."paiement_facture as pf, ".MAIN_DB_PREFIX."paiement as p";
		$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."c_paiement as cp ON p.fk_paiement = cp.id";
		$sql .= " WHERE pf.fk_paiement = p.rowid AND pf.fk_facture = ".((int) $object->id);
		//$sql.= " WHERE pf.fk_paiement = p.rowid AND pf.fk_facture = 1";
		$sql .= " ORDER BY p.datep";

		$resql = $this->db->query($sql);
		if ($resql) {
			$num = $this->db->num_rows($resql);
			$i = 0;
			$y += 3;
			$maxY = $y;
			while ($i < $num) {
				if ($tab3_top + $y >= ($this->page_hauteur - $heightforfooter)) {
					$y = 0;
					$current_page++;
					$pdf->AddPage('', '', true);
					/*if (!empty($tplidx)) {
						$pdf->useTemplate($tplidx);
					}*/
					if (!getDolGlobalInt('MAIN_PDF_DONOTREPEAT_HEAD')) {
						$top_shift = $this->_pagehead($pdf, $object, 0, $outputlangs);
						$tab_top_newpage = (!getDolGlobalInt('MAIN_PDF_DONOTREPEAT_HEAD') ? 42 + $top_shift : 10);
					}
					$pdf->setPage($current_page);
					$this->_tableau_versements_header($pdf, $object, $outputlangs, $default_font_size, $tab3_posx, $tab3_top + $y - 3, $tab3_width, $tab3_height);
				}

				$row = $this->db->fetch_object($resql);

				$pdf->SetXY($tab3_posx, $tab3_top + $y);
				$pdf->MultiCell(20, 3, dol_print_date($this->db->jdate($row->date), 'day', false, $outputlangs, true), 0, 'L', false);
				$pdf->SetXY($tab3_posx + 21, $tab3_top + $y);
				$pdf->MultiCell(20, 3, price($sign * ((isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? $row->multicurrency_amount : $row->amount), 0, $outputlangs), 0, 'L', false);
				$pdf->SetXY($tab3_posx + 40, $tab3_top + $y);
				$oper = $outputlangs->transnoentitiesnoconv("PaymentTypeShort".$row->code);

				$pdf->MultiCell(20, 3, $oper, 0, 'L', false);
				$maxY = max($pdf->GetY() - $tab3_top - 3, $maxY);
				$pdf->SetXY($tab3_posx + 58, $tab3_top + $y);
				$pdf->MultiCell(30, 3, $row->num, 0, 'L', false);
				$y = $maxY = max($pdf->GetY() - $tab3_top - 3, $maxY);
				$pdf->line($tab3_posx, $tab3_top + $y + 3, $tab3_posx + $tab3_width, $tab3_top + $y + 3);
				$y += 3;
				$i++;
			}

			return $tab3_top + $y + 3;
		} else {
			$this->error = $this->db->lasterror();
			return -1;
		}
	}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore
	/**
	 * Function _tableau_versements_header
	 *
	 * @param TCPDF 		$pdf				Object PDF
	 * @param Facture		$object				Object invoice
	 * @param Translate		$outputlangs		Object langs for output
	 * @param int			$default_font_size	Font size
	 * @param float			$tab3_posx			pos x
	 * @param float			$tab3_top			pos y
	 * @param float			$tab3_width			width
	 * @param float			$tab3_height		height
	 * @return void
	 */
	protected function _tableau_versements_header($pdf, $object, $outputlangs, $default_font_size, $tab3_posx, $tab3_top, $tab3_width, $tab3_height)
	{
		// phpcs:enable
		$title = $outputlangs->transnoentities("PaymentsAlreadyDone");
		if ($object->type == 2) {
			$title = $outputlangs->transnoentities("PaymentsBackAlreadyDone");
		}

		$pdf->SetFont('', '', $default_font_size - 3);
		$pdf->SetXY($tab3_posx, $tab3_top - 4);
		$pdf->MultiCell(60, 3, $title, 0, 'L', false);

		$pdf->line($tab3_posx, $tab3_top, $tab3_posx + $tab3_width, $tab3_top);

		$pdf->SetFont('', '', $default_font_size - 4);
		$pdf->SetXY($tab3_posx, $tab3_top);
		$pdf->MultiCell(20, 3, $outputlangs->transnoentities("Payment"), 0, 'L', false);
		$pdf->SetXY($tab3_posx + 21, $tab3_top);
		$pdf->MultiCell(20, 3, $outputlangs->transnoentities("Amount"), 0, 'L', false);
		$pdf->SetXY($tab3_posx + 40, $tab3_top);
		$pdf->MultiCell(20, 3, $outputlangs->transnoentities("Type"), 0, 'L', false);
		$pdf->SetXY($tab3_posx + 58, $tab3_top);
		$pdf->MultiCell(20, 3, $outputlangs->transnoentities("Num"), 0, 'L', false);

		$pdf->line($tab3_posx, $tab3_top - 1 + $tab3_height, $tab3_posx + $tab3_width, $tab3_top - 1 + $tab3_height);
	}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore
	/**
	 *   Show miscellaneous information (payment mode, payment term, ...)
	 *
	 *   @param		TCPDF		$pdf     		Object PDF
	 *   @param		Facture		$object			Object to show
	 *   @param		float		$posy			Y
	 *   @param		Translate	$outputlangs	Langs object
	 *   @param  	?Translate	$outputlangsbis	Object lang for output bis
	 *   @return	float						Pos y
	 */
	protected function _tableau_info(&$pdf, $object, $posy, $outputlangs, $outputlangsbis)
{
	$default_font_size = pdf_getPDFFontSize($outputlangs);
	$pdf->SetFont('', '', $default_font_size - 5);
	$pdf->SetTextColor(0, 0, 0);

	$x = $this->marge_gauche;
	$w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;
	$y = $posy;

	if ($object->cond_reglement_label || $object->cond_reglement) {
		$pdf->SetXY($x, $y);
		$pdf->MultiCell($w, 3, 'Condition de règlement : '.($object->cond_reglement_label ?: $object->cond_reglement), 0, 'L', false);
		$y = $pdf->GetY();
	}

	if ($object->mode_reglement_label || $object->mode_reglement_code) {
		$pdf->SetXY($x, $y);
		$pdf->MultiCell($w, 3, 'Mode de règlement : '.($object->mode_reglement_label ?: $object->mode_reglement_code), 0, 'L', false);
		$y = $pdf->GetY();
	}

	if (!empty($object->date_lim_reglement)) {
		$pdf->SetXY($x, $y);
		$pdf->MultiCell($w, 3, 'Date limite : '.dol_print_date($object->date_lim_reglement, 'day', false, $outputlangs, true), 0, 'L', false);
		$y = $pdf->GetY();
	}

	return $y;
}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.ScopeNotCamelCaps
	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore
	/**
	 *	Show total to pay
	 *
	 *	@param	TCPDF		$pdf            Object PDF
	 *	@param  Facture		$object         Object invoice
	 *	@param  float		$deja_regle     Amount already paid (in the currency of invoice)
	 *	@param	float		$posy			Position depart
	 *	@param	Translate	$outputlangs	Object langs
	 *  @param  ?Translate	$outputlangsbis	Object lang for output bis
	 *	@return float						Position pour suite
	 */
	protected function _tableau_tot(&$pdf, $object, $deja_regle, $posy, $outputlangs, $outputlangsbis)
{
	$default_font_size = pdf_getPDFFontSize($outputlangs);
	$pdf->SetFont('', 'B', $default_font_size - 4);

	$x = $this->marge_gauche;
	$w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;
	$y = $posy;

	$total_ttc = (isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? $object->multicurrency_total_ttc : $object->total_ttc;
	$resteapayer = price2num($total_ttc - $deja_regle - $object->getSumCreditNotesUsed((isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? 1 : 0) - $object->getSumDepositsUsed((isModEnabled("multicurrency") && $object->multicurrency_tx != 1) ? 1 : 0), 'MT');

	$pdf->SetXY($x, $y);
	$pdf->MultiCell($w, 3, 'Total TTC : '.price($total_ttc, 0, $outputlangs), 0, 'L', false);
	$y = $pdf->GetY();

	$pdf->SetXY($x, $y);
	$pdf->MultiCell($w, 3, 'Reste à payer : '.price($resteapayer, 0, $outputlangs), 0, 'L', false);
	$y = $pdf->GetY();

	return $y;
}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore
	/**
	 *   Show table for lines
	 *
	 *   @param		TCPDF		$pdf     		Object PDF
	 *   @param		float|int	$tab_top		Top position of table
	 *   @param		float|int	$tab_height		Height of table (rectangle)
	 *   @param		int			$nexY			Y (not used)
	 *   @param		Translate	$outputlangs	Langs object
	 *   @param		int			$hidetop		1=Hide top bar of array and title, 0=Hide nothing, -1=Hide only title
	 *   @param		int			$hidebottom		Hide bottom bar of array
	 *   @param		string		$currency		Currency code
	 *   @return	void
	 */
protected function _tableau(&$pdf, $tab_top, $tab_height, $nobottom, $outputlangs, $newpage = 0, $hideprogress = 0, $multicurrency_code = '')
{
	$default_font_size = pdf_getPDFFontSize($outputlangs);

	$x = $this->marge_gauche;
	$w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;
	$y = $tab_top;
	$header_h = 4;

	$pdf->SetFillColor(240, 240, 240);
	$pdf->SetDrawColor(180, 180, 180);
	$pdf->SetFont('', 'B', $default_font_size - 5);
	$pdf->RoundedRect($x, $y, $w, $header_h, 0, '1234', 'D');

	$colDesc = $x + 1;
	$colPU = 18;
	$colQty = 24;
	$colTot = 30;

	$pdf->SetXY($colDesc, $y + 1);
	$pdf->MultiCell(10, 3, 'Désignation', 0, 'L', false);

	$pdf->SetXY($colPU, $y + 1);
	$pdf->MultiCell(5, 3, 'P.U', 0, 'R', false);

	$pdf->SetXY($colQty, $y + 1);
	$pdf->MultiCell(4, 3, 'Qté', 0, 'R', false);

	$pdf->SetXY($colTot, $y + 1);
	$pdf->MultiCell($w - ($colTot - $x), 3, 'Total', 0, 'R', false);

	$pdf->SetFont('', '', $default_font_size - 5);
	return $y + $header_h;
}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore
	/**
	 *  Show top header of page.
	 *
	 *  @param	TCPDF		$pdf     		Object PDF
	 *  @param  Facture		$object     	Object to show
	 *  @param  int	    	$showaddress    0=no, 1=yes
	 *  @param  Translate	$outputlangs	Object lang for output
	 *  @param  Translate	$outputlangsbis	Object lang for output bis
	 *  @return	float|int                   Return topshift value
	 */
	protected function _pagehead(&$pdf, $object, $showaddress, $outputlangs, $outputlangsbis = null)
{
	global $conf, $langs;

	$default_font_size = pdf_getPDFFontSize($outputlangs);
	$isTicket = ($this->page_largeur <= 100);

	pdf_pagehead($pdf, $outputlangs, $this->page_hauteur);

	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetFont('', 'B', $default_font_size - 5);

	$posy = $this->marge_haute;
	$w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;

	if (!getDolGlobalInt('PDF_DISABLE_MYCOMPANY_LOGO') && !empty($this->emetteur->logo)) {
		$logodir = $conf->mycompany->dir_output;
		if (!empty($conf->mycompany->multidir_output[$object->entity ?? $conf->entity])) {
			$logodir = $conf->mycompany->multidir_output[$object->entity ?? $conf->entity];
		}
		$logo = $logodir.'/logos/thumbs/'.$this->emetteur->logo_small;
		if (is_readable($logo)) {
			$pdf->Image($logo, $this->marge_gauche, $posy, 0, 8);
		}
	}

	$pdf->SetXY($this->marge_gauche, $posy + 9);
	$pdf->MultiCell($w, 3, $outputlangs->convToOutputCharset($this->emetteur->name), 0, 'C', false);

	$pdf->SetFont('', 'B', $default_font_size - 4);
	$pdf->SetXY($this->marge_gauche, $posy + 13);
	$pdf->MultiCell($w, 3, 'TICKET DE CAISSE', 0, 'C', false);

	$pdf->SetFont('', '', $default_font_size - 6);
	$pdf->SetXY($this->marge_gauche, $posy + 17);
	$pdf->MultiCell($w, 3, 'Facture : '.$object->ref, 0, 'C', false);

	return $isTicket ? 18 : 0;
}

	// phpcs:disable PEAR.NamingConventions.ValidFunctionName.PublicUnderscore
	/**
	 *   	Show footer of page. Need this->emetteur object
	 *
	 *   	@param	TCPDF		$pdf     			PDF
	 * 		@param	Facture		$object				Object to show
	 *      @param	Translate	$outputlangs		Object lang for output
	 *      @param	int			$hidefreetext		1=Hide free text
	 *      @param	int			$heightforqrinvoice	Height for QR invoices
	 *      @return	int								Return height of bottom margin including footer text
	 */
	protected function _pagefoot(&$pdf, $object, $outputlangs, $hidefreetext = 0, $heightforqrinvoice = 0)
	{
		$showdetails = getDolGlobalInt('MAIN_GENERATE_DOCUMENTS_SHOW_FOOT_DETAILS', 0);

		return pdf_pagefoot($pdf, $outputlangs, 'INVOICE_FREE_TEXT', $this->emetteur, $heightforqrinvoice + $this->marge_basse, $this->marge_gauche, $this->page_hauteur, $object, $showdetails, $hidefreetext, $this->page_largeur, $this->watermark);
	}
}
