<?php
require_once DOL_DOCUMENT_ROOT.'/core/modules/facture/modules_facture.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions2.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/pdf.lib.php';

class pdf_facture_parson extends ModelePDFFactures
{
    public $db;
    public $name;
    public $description;
    public $update_main_doc_field;
    public $type;
    public $version = 'dolibarr';
    public $situationinvoice;
    public $posxprogress;
    public $categoryOfOperation = -1;

    public function __construct($db)
    {
        global $langs, $mysoc;

        $langs->loadLangs(array('main', 'bills'));

        $this->db = $db;
        $this->name = 'facture_parson';
        $this->description = $langs->trans('PDFCrabeDescription');
        $this->update_main_doc_field = 1;
        $this->type = 'pdf';

        $this->page_largeur = 35;
        $this->page_hauteur = 78;
        $this->format = array($this->page_largeur, $this->page_hauteur);

        $this->marge_gauche = 0;
        $this->marge_droite = 0;
        $this->marge_haute = 0;
        $this->marge_basse = 2;
        $this->corner_radius = 0;

        $this->option_logo = 1;
        $this->option_tva = 1;
        $this->option_modereg = 1;
        $this->option_condreg = 1;
        $this->option_multilang = 1;
        $this->option_escompte = 1;
        $this->option_credit_note = 1;
        $this->option_freetext = 1;
        $this->option_draft_watermark = 1;
        $this->watermark = '';

        $this->posxdesc = 1;
        $this->posxtva = 0;
        $this->posxup = 18;
        $this->posxqty = 24;
        $this->posxunit = 28;
        $this->posxdiscount = 30;
        $this->posxprogress = 30;
        $this->postotalht = 30;
        $this->posxpicture = $this->posxdesc;

        $this->tva = array();
        $this->tva_array = array();
        $this->localtax1 = array();
        $this->localtax2 = array();
        $this->atleastoneratenotnull = 0;
        $this->atleastonediscount = 0;
        $this->situationinvoice = false;

        if ($mysoc === null) {
            return;
        }

        $this->emetteur = $mysoc;
        if (empty($this->emetteur->country_code)) {
            $this->emetteur->country_code = substr($langs->defaultlang, -2);
        }
    }

    public function write_file($object, $outputlangs, $srctemplatepath = '', $hidedetails = 0, $hidedesc = 0, $hideref = 0)
    {
        global $user, $langs, $conf, $mysoc, $hookmanager, $nblines, $action;

        if (!is_object($outputlangs)) {
            $outputlangs = $langs;
        }
        if (getDolGlobalString('MAIN_USE_FPDF')) {
            $outputlangs->charset_output = 'ISO-8859-1';
        }
        $outputlangs->loadLangs(array('main', 'bills', 'products', 'dict', 'companies', 'compta'));

        if ($object->status == $object::STATUS_DRAFT && getDolGlobalString('FACTURE_DRAFT_WATERMARK')) {
            $this->watermark = getDolGlobalString('FACTURE_DRAFT_WATERMARK');
        }

        global $outputlangsbis;
        $outputlangsbis = null;
        if (getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE') && $outputlangs->defaultlang != getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE')) {
            $outputlangsbis = new Translate('', $conf);
            $outputlangsbis->setDefaultLang(getDolGlobalString('PDF_USE_ALSO_LANGUAGE_CODE'));
            $outputlangsbis->loadLangs(array('main', 'bills', 'products', 'dict', 'companies', 'compta'));
        }

        $nblines = count($object->lines);

        if (!$conf->facture->dir_output) {
            $this->error = $langs->transnoentities('ErrorConstantNotDefined', 'FAC_OUTPUTDIR');
            return 0;
        }

        $object->fetch_thirdparty();
        $deja_regle = $object->getSommePaiement((isModEnabled('multicurrency') && $object->multicurrency_tx != 1) ? 1 : 0);

        if ($object->specimen) {
            $dir = empty($conf->facture->multidir_output[$object->entity ?? $conf->entity]) ? $conf->facture->dir_output : $conf->facture->multidir_output[$object->entity ?? $conf->entity];
            $file = $dir.'/SPECIMEN.pdf';
        } else {
            $objectref = dol_sanitizeFileName($object->ref);
            $dir = (empty($conf->facture->multidir_output[$object->entity ?? $conf->entity]) ? $conf->facture->dir_output : $conf->facture->multidir_output[$object->entity ?? $conf->entity]).'/'.$objectref;
            $file = $dir.'/'.$objectref.'.pdf';
        }

        if (!file_exists($dir) && dol_mkdir($dir) < 0) {
            $this->error = $langs->transnoentities('ErrorCanNotCreateDir', $dir);
            return 0;
        }

        if (!file_exists($dir)) {
            $this->error = $langs->transnoentities('ErrorCanNotCreateDir', $dir);
            return 0;
        }

        if (!is_object($hookmanager)) {
            include_once DOL_DOCUMENT_ROOT.'/core/class/hookmanager.class.php';
            $hookmanager = new HookManager($this->db);
        }
        $hookmanager->initHooks(array('pdfgeneration'));
        $hookmanager->executeHooks('beforePDFCreation', array('file' => $file, 'object' => $object, 'outputlangs' => $outputlangs), $object, $action);

        $pdf = pdf_getInstance($this->format);
        $default_font_size = pdf_getPDFFontSize($outputlangs);
        $pdf->setAutoPageBreak(false, 0);

        if (class_exists('TCPDF')) {
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);
        }

        $pdf->SetFont(pdf_getPDFFont($outputlangs));
        $pdf->Open();
        $pdf->SetDrawColor(128, 128, 128);
        $pdf->SetMargins($this->marge_gauche, $this->marge_haute, $this->marge_droite);

        $this->atleastonediscount = 0;
        $this->situationinvoice = false;

        $categoryOfOperation = 0;
        $nbProduct = 0;
        $nbService = 0;
        for ($i = 0; $i < $nblines; $i++) {
            if (!empty($object->lines[$i]->remise_percent)) $this->atleastonediscount++;
            if ($object->lines[$i]->product_type == Product::TYPE_PRODUCT) $nbProduct++;
            elseif ($object->lines[$i]->product_type == Product::TYPE_SERVICE) $nbService++;
        }
        if ($nbProduct > 0 && $nbService > 0) $categoryOfOperation = 2;
        elseif ($nbProduct == 0 && $nbService > 0) $categoryOfOperation = 1;
        $this->categoryOfOperation = $categoryOfOperation;

        if (empty($this->atleastonediscount)) {
            $delta = ($this->posxprogress - $this->posxdiscount);
            $this->posxpicture += $delta;
            $this->posxtva += $delta;
            $this->posxup += $delta;
            $this->posxqty += $delta;
            $this->posxunit += $delta;
            $this->posxdiscount += $delta;
        }

        if ($object->situation_cycle_ref && !getDolGlobalString('MAIN_PDF_HIDE_SITUATION')) {
            $this->situationinvoice = true;
            $shift = 6;
            $this->posxpicture -= $shift;
            $this->posxtva -= $shift;
            $this->posxup -= $shift;
            $this->posxqty -= $shift;
            $this->posxunit -= $shift;
            $this->posxdiscount -= $shift;
            $this->posxprogress -= $shift;
        }

        $pdf->AddPage();
        $top_shift = $this->_pagehead($pdf, $object, 1, $outputlangs, $outputlangsbis);
        $pdf->SetFont('', '', $default_font_size - 2);

        $tab_top = 23 + $top_shift;
        $tab_top_newpage = 8;

        $iniY = $tab_top + 4;
        $curY = $iniY;
        $nexY = $iniY;

        for ($i = 0; $i < $nblines; $i++) {
            $curY = $nexY;
            $pdf->SetFont('', '', $default_font_size - 6);
            $pdf->SetTextColor(0, 0, 0);
            $pdf->setTopMargin($tab_top_newpage);

            pdf_writelinedesc($pdf, $object, $i, $outputlangs, 9, 3, $this->posxdesc - 1, $curY, $hideref, $hidedesc);

            $pdf->SetXY($this->postotalht, $curY);
            $pdf->MultiCell($this->page_largeur - $this->marge_droite - $this->postotalht, 3, pdf_getlinetotalexcltax($object, $i, $outputlangs, $hidedetails), 0, 'R', false);

            $nexY = max($pdf->GetY(), $curY + 4);

            if (!empty($object->lines[$i]->remise_percent)) {
                $pdf->SetXY($this->posxdiscount - 2, $curY);
                $pdf->MultiCell(4, 3, pdf_getlineremisepercent($object, $i, $outputlangs, $hidedetails), 0, 'R');
            }

            if ($this->situationinvoice) {
                $pdf->SetXY($this->posxprogress, $curY);
                $pdf->MultiCell(4, 3, pdf_getlineprogress($object, $i, $outputlangs, $hidedetails), 0, 'R');
            }

            $nexY += 1;
        }

        $bottomlasttab = 50;
        $posy = $this->_tableau_info($pdf, $object, $bottomlasttab, $outputlangs, $outputlangsbis);
        $posy = $this->_tableau_tot($pdf, $object, $deja_regle, $posy + 1, $outputlangs, $outputlangsbis);

        $this->_pagefoot($pdf, $object, $outputlangs, 0, $this->getHeightForQRInvoice($pdf->getPage(), $object, $langs));

        if (method_exists($pdf, 'AliasNbPages')) {
            $pdf->AliasNbPages();
        }

        $pdf->Close();
        $pdf->Output($file, 'F');
        $hookmanager->executeHooks('afterPDFCreation', array('file' => $file, 'object' => $object, 'outputlangs' => $outputlangs), $this, $action);

        dolChmod($file);
        $this->result = array('fullpath' => $file);
        return 1;
    }

    protected function _tableau_info(&$pdf, $object, $posy, $outputlangs, $outputlangsbis)
    {
        $default_font_size = pdf_getPDFFontSize($outputlangs);
        $pdf->SetFont('', '', $default_font_size - 7);
        $pdf->SetTextColor(0, 0, 0);

        $x = $this->marge_gauche;
        $w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;
        $y = $posy;

        if (!empty($object->cond_reglement_label) || !empty($object->cond_reglement)) {
            $pdf->SetXY($x, $y);
            $pdf->MultiCell($w, 2.2, 'Condition de règlement : '.($object->cond_reglement_label ?: $object->cond_reglement), 0, 'L', false);
            $y = $pdf->GetY();
        }

        if (!empty($object->mode_reglement_label) || !empty($object->mode_reglement_code)) {
            $pdf->SetXY($x, $y);
            $pdf->MultiCell($w, 2.2, 'Mode de règlement : '.($object->mode_reglement_label ?: $object->mode_reglement_code), 0, 'L', false);
            $y = $pdf->GetY();
        }

        if (!empty($object->date_lim_reglement)) {
            $pdf->SetXY($x, $y);
            $pdf->MultiCell($w, 2.2, 'Date limite : '.dol_print_date($object->date_lim_reglement, 'day', false, $outputlangs, true), 0, 'L', false);
            $y = $pdf->GetY();
        }

        if (!empty($object->note_public)) {
            $pdf->SetXY($x, $y);
            $pdf->MultiCell($w, 2.2, $object->note_public, 0, 'L', false);
            $y = $pdf->GetY();
        }

        return $y;
    }

    protected function _tableau_tot(&$pdf, $object, $deja_regle, $posy, $outputlangs, $outputlangsbis)
    {
        $default_font_size = pdf_getPDFFontSize($outputlangs);
        $pdf->SetFont('', 'B', $default_font_size - 6);

        $x = $this->marge_gauche;
        $w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;
        $y = $posy + 1;

        $total_ttc = (isModEnabled('multicurrency') && $object->multicurrency_tx != 1) ? $object->multicurrency_total_ttc : $object->total_ttc;
        $resteapayer = price2num($total_ttc - $deja_regle - $object->getSumCreditNotesUsed((isModEnabled('multicurrency') && $object->multicurrency_tx != 1) ? 1 : 0) - $object->getSumDepositsUsed((isModEnabled('multicurrency') && $object->multicurrency_tx != 1) ? 1 : 0), 'MT');

        $pdf->SetXY($x, $y);
        $pdf->MultiCell($w, 2.2, 'Total TTC : '.price($total_ttc, 0, $outputlangs), 0, 'L', false);
        $y = $pdf->GetY();

        $pdf->SetXY($x, $y);
        $pdf->MultiCell($w, 2.2, 'Reste à payer : '.price($resteapayer, 0, $outputlangs), 0, 'L', false);
        $y = $pdf->GetY();

        return $y;
    }

    protected function _tableau(&$pdf, $tab_top, $tab_height, $nobottom, $outputlangs, $newpage = 0, $hideprogress = 0, $multicurrency_code = '')
    {
        $default_font_size = pdf_getPDFFontSize($outputlangs);
        $x = $this->marge_gauche;
        $w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;
        $y = $tab_top;
        $header_h = 3;

        $pdf->SetFillColor(240, 240, 240);
        $pdf->SetDrawColor(180, 180, 180);
        $pdf->SetFont('', 'B', $default_font_size - 7);
        $pdf->RoundedRect($x, $y, $w, $header_h, 0, '1234', 'D');

        $pdf->SetXY($x + 0.5, $y + 0.4);
        $pdf->MultiCell(12, 2.2, 'Désignation', 0, 'L', false);
        $pdf->SetXY($x + 18, $y + 0.4);
        $pdf->MultiCell(5, 2.2, 'P.U', 0, 'R', false);
        $pdf->SetXY($x + 23, $y + 0.4);
        $pdf->MultiCell(4, 2.2, 'Qté', 0, 'R', false);
        $pdf->SetXY($x + 28, $y + 0.4);
        $pdf->MultiCell($w - 28, 2.2, 'Total', 0, 'R', false);

        $pdf->SetFont('', '', $default_font_size - 7);
        return $y + $header_h;
    }

    protected function _pagehead(&$pdf, $object, $showaddress, $outputlangs, $outputlangsbis = null)
    {
        global $conf, $langs;

        $default_font_size = pdf_getPDFFontSize($outputlangs);
        pdf_pagehead($pdf, $outputlangs, $this->page_hauteur);

        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('', 'B', $default_font_size - 6);

        $posy = 1;
        $w = $this->page_largeur - $this->marge_gauche - $this->marge_droite;

        if (!getDolGlobalInt('PDF_DISABLE_MYCOMPANY_LOGO') && !empty($this->emetteur->logo)) {
            $logodir = $conf->mycompany->dir_output;
            if (!empty($conf->mycompany->multidir_output[$object->entity ?? $conf->entity])) {
                $logodir = $conf->mycompany->multidir_output[$object->entity ?? $conf->entity];
            }
            $logo = $logodir.'/logos/thumbs/'.$this->emetteur->logo_small;
            if (is_readable($logo)) {
                $pdf->Image($logo, 0.5, $posy, 0, 6);
            }
        }

        $pdf->SetXY(0, 7);
        $pdf->MultiCell($w, 2.2, $outputlangs->convToOutputCharset($this->emetteur->name), 0, 'C', false);

        $pdf->SetXY(0, 9.5);
        $addr = trim($this->emetteur->address."\n".$this->emetteur->zip.' '.$this->emetteur->town);
        $pdf->MultiCell($w, 2.0, $outputlangs->convToOutputCharset($addr), 0, 'C', false);

        $pdf->SetFont('', 'B', $default_font_size - 4);
        $pdf->SetXY(0, 13);
        $pdf->MultiCell($w, 2.2, 'TICKET DE CAISSE', 0, 'C', false);

        $pdf->SetFont('', '', $default_font_size - 7);
        $pdf->SetXY(0, 16);
        $pdf->MultiCell($w, 2.0, 'FACTURE : '.$object->ref, 0, 'C', false);

        $pdf->SetXY(0.5, 18.5);
        $pdf->MultiCell($w - 1, 2.0, 'Date : '.dol_print_date($object->date, 'day', false, $outputlangs, true), 0, 'L', false);

        return 17;
    }

    protected function _pagefoot(&$pdf, $object, $outputlangs, $hidefreetext = 0, $heightforqrinvoice = 0)
    {
        $showdetails = getDolGlobalInt('MAIN_GENERATE_DOCUMENTS_SHOW_FOOT_DETAILS', 0);
        return pdf_pagefoot($pdf, $outputlangs, 'INVOICE_FREE_TEXT', $this->emetteur, $heightforqrinvoice + $this->marge_basse, $this->marge_gauche, $this->page_hauteur, $object, $showdetails, $hidefreetext, $this->page_largeur, $this->watermark);
    }
}