<?php
// Pas de code PHP nécessaire, juste du CSS
?>
/* Icône pour le menu TOP "Depot" */
div.mainmenu.depot::before {
    content: "\f0b1";           /* Font Awesome: fa-box */
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    margin-right: 8px;
    display: inline-block;
}
