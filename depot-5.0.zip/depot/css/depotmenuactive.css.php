<?php
// Pas de code PHP nécessaire, juste du CSS
?>
/* Couleur pour le menu LEFT actif */
div#mainmenu ul.tmenu li.active a {
    background-color: #e3f2fd;  /* bleu clair simple */
    color: #1976d2;             /* bleu plus foncé */
    font-weight: bold;
}