<?php
ini_set('display_errors', 0);
error_reporting(0);

require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';
require_once DOL_DOCUMENT_ROOT.'/user/class/user.class.php';

if (!$user->id) accessforbidden();


$fk_product = GETPOST('fk_product', 'int');
$note = GETPOST('note', 'restricthtml');
$contact_name = GETPOST('contact_name', 'alphanohtml');
$fullscreen = (int) GETPOST('fullscreen', 'int');

function depotProductLink($product)
{
    if (empty($product->id)) return '';
    $url = DOL_URL_ROOT.'/product/card.php?id='.(int) $product->id;
    return '<a href="'.$url.'" target="_blank" rel="noopener">'.dol_escape_htmltag($product->ref).'</a>';
}

function depotInvoiceLink($facture)
{
    if (empty($facture->id)) return '';
    $url = DOL_URL_ROOT.'/compta/facture/card.php?id='.(int) $facture->id;
    return '<a href="'.$url.'" target="_blank" rel="noopener">'.dol_escape_htmltag($facture->ref).'</a>';
}

function depotGetInvoiceAuthorName($db, $facture)
{
    if (empty($facture) || empty($facture->fk_user_author)) {
        return '';
    }

    $author = new User($db);

    if ($author->fetch((int) $facture->fk_user_author) <= 0) {
        return '';
    }

    $name = trim($author->firstname.' '.$author->lastname);

    if (empty($name)) {
        $name = $author->login;
    }

    return $name;
}

/**
 * Retourne la date facture formatée (jour/mois/année).
 *
 * @param  int|null $timestampFacture  Timestamp de la date facture ($facture->date)
 * @return string
 */
/**
 * Retourne la date facture formatée (jour/mois/année) avec l'heure.
 * Pour avoir une heure significative, on utilise la date de création
 * de la facture (datec) plutôt que la date de facture (datef).
 *
 * @param  Facture  $facture  Objet facture Dolibarr
 * @return string
 */
function depotGetFactureDateLabel($db, $facture)
{
    if (empty($facture) || empty($facture->id)) {
        return 'Date inconnue';
    }

    /*
     * Date affichée :
     * la date facture existante, qui affichait déjà correctement
     * le jour/mois/année dans votre module.
     */
    $dateFacture = !empty($facture->date) ? $facture->date : 0;

    /*
     * Heure réelle :
     * lecture directe de datec dans la table llx_facture.
     */
    $dateCreation = 0;

    $sql = "SELECT datec
            FROM ".MAIN_DB_PREFIX."facture
            WHERE rowid = ".((int) $facture->id)."
            LIMIT 1";

    $resql = $db->query($sql);

    if ($resql && ($obj = $db->fetch_object($resql))) {
        if (!empty($obj->datec)) {
            $dateCreation = strtotime($obj->datec);
        }
    }

    /*
     * Sécurité :
     * Si la date facture n'existe pas, on utilise la date de création.
     */
    if (empty($dateFacture) && !empty($dateCreation)) {
        $dateFacture = $dateCreation;
    }

    if (empty($dateFacture)) {
        return 'Date inconnue';
    }

    /*
     * La date provient de datef (comme avant).
     * L'heure provient de datec (heure réelle de création).
     */
    $label = date('d/m/Y', $dateFacture);

    if (!empty($dateCreation)) {
        // Fuseau horaire de Madagascar (EAT, UTC+3)
        $timezone = new DateTimeZone('Indian/Antananarivo');

        $dt = new DateTime();
        $dt->setTimestamp($dateCreation);
        $dt->setTimezone($timezone);

        $label .= ' à '.$dt->format('H:i');
    }

    return $label;
}

function depotFormatQty($qty)
{
    $qty = (float) $qty;

    if (abs($qty - round($qty)) < 0.0001) {
        return number_format($qty, 0, ',', ' ');
    }

    return number_format($qty, 3, ',', ' ');
}

$action = GETPOST('action', 'alpha');
$id = GETPOST('id', 'int');
$view = GETPOST('view', 'alpha');
if (empty($view)) $view = 'preparation';
$phpSelf = $_SERVER['PHP_SELF'];
$tranche = GETPOST('tranche', 'alpha');

// Limite configurable du nombre de commandes affichées en préparation
$preparation_limit = (int) getDolGlobalInt('DEPOT_PREPARATION_LIMIT');

if ($preparation_limit <= 0) {
    $preparation_limit = 2;
}

$cache = array(
    'stocks' => array(),
    'locations' => array(),
    'works' => array(),
    'products' => array(),
);

function depotDurationPretty($sec) {
    $sec = (int) $sec;
    $h = floor($sec / 3600);
    $m = floor(($sec % 3600) / 60);
    $s = $sec % 60;
    if ($h > 0) return $h.'h '.$m.'min '.$s.'s';
    if ($m > 0) return $m.'min '.$s.'s';
    return $s.'s';
}

function depotGetWorkRow($db, $fid, &$cache) {
    $fid = (int) $fid;
    if (isset($cache['works'][$fid])) return $cache['works'][$fid];

    $sql = "SELECT rowid, fk_facture, status, start_time, finish_time, duration, validated_on, delivered_on, archived, archived_on, tms
            FROM ".MAIN_DB_PREFIX."depot_work
            WHERE fk_facture = ".$fid."
            LIMIT 1";
    $res = $db->query($sql);
    if ($res && ($obj = $db->fetch_object($res))) {
        $cache['works'][$fid] = $obj;
        return $obj;
    }
    return null;
}

function depotUpsertWorkRow($db, $fid, $fields = array()) {
    $fid = (int) $fid;
    $check_sql = "SELECT rowid, status, duration
                  FROM ".MAIN_DB_PREFIX."depot_work
                  WHERE fk_facture = ".$fid."
                  LIMIT 1";
    $check_res = $db->query($check_sql);
    $existing = ($check_res && ($obj = $db->fetch_object($check_res)));

    if ($existing && empty($fields['status'])) $fields['status'] = $obj->status;
    if ($existing && empty($fields['duration'])) $fields['duration'] = $obj->duration;

    $status = $fields['status'] ?? 'a_preparer';
    $start_time = !empty($fields['start_time']) ? "'".$db->idate($fields['start_time'])."'" : "NULL";
    $finish_time = !empty($fields['finish_time']) ? "'".$db->idate($fields['finish_time'])."'" : "NULL";
    $validated_on = !empty($fields['validated_on']) ? "'".$db->idate($fields['validated_on'])."'" : "NULL";
    $delivered_on = !empty($fields['delivered_on']) ? "'".$db->idate($fields['delivered_on'])."'" : "NULL";
    $duration = (int)($fields['duration'] ?? 0);
    $archived = !empty($fields['archived']) ? 1 : 0;
    $archived_on = !empty($fields['archived_on']) ? "'".$db->idate($fields['archived_on'])."'" : "NULL";

    if ($existing) {
        $sql = "UPDATE ".MAIN_DB_PREFIX."depot_work SET
            status = '".$db->escape($status)."',
            start_time = $start_time,
            finish_time = $finish_time,
            duration = ".$duration.",
            validated_on = $validated_on,
            delivered_on = $delivered_on,
            archived = ".$archived.",
            archived_on = $archived_on,
            tms = NOW()
            WHERE fk_facture = ".$fid;
    } else {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_work
            (fk_facture, status, start_time, finish_time, duration, validated_on, delivered_on, archived, archived_on, date_creation, tms)
            VALUES
            (".$fid.", '".$db->escape($status)."', $start_time, $finish_time, ".$duration.", $validated_on, $delivered_on, ".$archived.", $archived_on, NOW(), NOW())";
    }

    return $db->query($sql);
}

function depotBatchLoadStocks($db, $ids, &$cache) {
    if (empty($ids)) return;
    $ids = array_values(array_unique(array_map('intval', $ids)));
    if (empty($ids)) return;

    $sql = "SELECT ps.fk_product, ps.reel, e.ref as warehouse_ref
            FROM ".MAIN_DB_PREFIX."product_stock ps
            LEFT JOIN ".MAIN_DB_PREFIX."entrepot e ON e.rowid = ps.fk_entrepot
            WHERE ps.fk_product IN (".implode(',', $ids).")
            ORDER BY ps.fk_product ASC, e.ref ASC";
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $cache['stocks'][$obj->fk_product][] = array(
                'warehouse' => !empty($obj->warehouse_ref) ? $obj->warehouse_ref : 'N/A',
                'qty' => (float) $obj->reel,
            );
        }
    }
}

function depotBatchLoadLocations($db, $ids, &$cache) {
    if (empty($ids)) return;
    $ids = array_values(array_unique(array_map('intval', $ids)));
    if (empty($ids)) return;

    $sql = "SELECT fk_object, salle_depot, etagere, localisation
            FROM ".MAIN_DB_PREFIX."product_extrafields
            WHERE fk_object IN (".implode(',', $ids).")";
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $cache['locations'][$obj->fk_object] = array(
                'salle_depot' => !empty($obj->salle_depot) ? $obj->salle_depot : '',
                'etagere' => !empty($obj->etagere) ? $obj->etagere : '',
                'localisation' => !empty($obj->localisation) ? $obj->localisation : '',
            );
        }
    }
}

function depotGetProductStockByWarehouse_cached($db, $fk_product, &$cache) {
    $fk_product = (int) $fk_product;

    if (isset($cache['stocks'][$fk_product])) {
        $stocks = $cache['stocks'][$fk_product];
        $total = 0;
        foreach ($stocks as $s) $total += $s['qty'];
        return array('total' => $total, 'details' => $stocks);
    }

    $stocks = array();
    $total = 0;
    $sql = "SELECT ps.reel, e.ref as warehouse_ref
            FROM ".MAIN_DB_PREFIX."product_stock ps
            LEFT JOIN ".MAIN_DB_PREFIX."entrepot e ON e.rowid = ps.fk_entrepot
            WHERE ps.fk_product = ".$fk_product."
            ORDER BY e.ref ASC";
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $qty = (float) $obj->reel;
            $total += $qty;
            $stocks[] = array(
                'warehouse' => !empty($obj->warehouse_ref) ? $obj->warehouse_ref : 'N/A',
                'qty' => $qty,
            );
        }
        $cache['stocks'][$fk_product] = $stocks;
    }

    return array('total' => $total, 'details' => $stocks);
}

function depotGetDetailedLocation_cached($db, $fk_product, &$cache) {
    $fk_product = (int) $fk_product;

    // Si déjà en cache, on recompose à partir des valeurs en cache
    if (isset($cache['locations'][$fk_product])) {
        $loc = $cache['locations'][$fk_product];

        $salle = !empty($loc['salle_depot']) ? $loc['salle_depot'] : '';
        $etagere = !empty($loc['etagere']) ? $loc['etagere'] : '';
        $localisation = !empty($loc['localisation']) ? $loc['localisation'] : '';
    } else {
        // Lecture directe des extrafields (phase de test : colonnes présentes mais pas forcément remplies)
        $salle = '';
        $etagere = '';
        $localisation = '';

        $sql2 = 'SELECT salle_depot, etagere, localisation
                 FROM '.MAIN_DB_PREFIX.'product_extrafields
                 WHERE fk_object = '.$fk_product.'
                 LIMIT 1';
        $res2 = $db->query($sql2);
        if ($res2 && $db->num_rows($res2) > 0) {
            $tmp2 = $db->fetch_object($res2);
            if ($tmp2) {
                $salle = !empty($tmp2->salle_depot) ? $tmp2->salle_depot : '';
                $etagere = !empty($tmp2->etagere) ? $tmp2->etagere : '';
                $localisation = !empty($tmp2->localisation) ? $tmp2->localisation : '';
            }
        }
    }

    // Paramètres globaux du module (configuration Dépôt)
    $defaultSalle   = getDolGlobalString('DEPOT_DEFAULT_SALLE');
    $defaultEtagere = getDolGlobalString('DEPOT_DEFAULT_ETAGERE');
    $defaultZone    = getDolGlobalString('DEPOT_DEFAULT_ZONE');

    $parts = array();

    // Salle : extrafield si présent, sinon valeur globale si configurée
    if (!empty($salle) || !empty($defaultSalle)) {
        $parts[] = 'Salle: '.dol_escape_htmltag($salle ?: $defaultSalle);
    }

    // Étagère : extrafield ou valeur globale
    if (!empty($etagere) || !empty($defaultEtagere)) {
        $parts[] = 'Étagère: '.dol_escape_htmltag($etagere ?: $defaultEtagere);
    }

    // Localisation / Zone : extrafield ou valeur globale
    if (!empty($localisation) || !empty($defaultZone)) {
        $parts[] = 'Localisation: '.dol_escape_htmltag($localisation ?: $defaultZone);
    }

    return implode('<br>', $parts);
}

function depotComputeRestes($db, $facture, &$cache) {
    $restes = array();
    if (empty($facture->lines) || !is_array($facture->lines)) return $restes;

    foreach ($facture->lines as $line) {
        if (empty($line->fk_product)) continue;

        $stockData = depotGetProductStockByWarehouse_cached($db, (int) $line->fk_product, $cache);
        $totalStock = (float) $stockData['total'];
        $qty_cmd = (float) $line->qty;

        if ($qty_cmd > $totalStock) {
            if (!isset($cache['products'][$line->fk_product])) {
                $product = new Product($db);
                if ($product->fetch($line->fk_product) <= 0) continue;
                $cache['products'][$line->fk_product] = $product;
            }

            $product = $cache['products'][$line->fk_product];
            $restes[] = array(
                'fk_product' => (int) $product->id,
                'facture_ref' => $facture->ref,
                'ref' => $product->ref,
                'label' => $product->label,
                'qty' => max(0, $qty_cmd - $totalStock),
            );
        }
    }

    return $restes;
}

function depotSyncRestes($db, $fid, $facture, &$cache) {
    $work = depotGetWorkRow($db, $fid, $cache);
    if (!$work) return false;

    $work_id = (int) $work->rowid;
    $sql = "UPDATE ".MAIN_DB_PREFIX."depot_restes SET archived = 1, archived_on = NOW() WHERE fk_depot_work = ".((int)$work_id)." AND resolved = 0";
    $db->query($sql);

    $restes = depotComputeRestes($db, $facture, $cache);
    foreach ($restes as $r) {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_restes
            (fk_depot_work, fk_facture, fk_product, facture_ref, product_ref, product_label, qty_manquante, detected_on, resolved, archived)
            VALUES
            (".$work_id.", ".((int)$fid).", ".((int)$r['fk_product']).", '".$db->escape($r['facture_ref'])."', '".$db->escape($r['ref'])."', '".$db->escape($r['label'])."', ".((float)$r['qty']).", NOW(), 0, 0)
            ON DUPLICATE KEY UPDATE
            qty_manquante = VALUES(qty_manquante),
            archived = 0,
            archived_on = NULL";
        $db->query($sql);
    }

    return true;
}

function depotGetRestes($db, $work_id) {
    $sql = "SELECT fk_product, facture_ref, product_ref, product_label, qty_manquante, detected_on
            FROM ".MAIN_DB_PREFIX."depot_restes
            WHERE fk_depot_work = ".((int)$work_id)." AND resolved = 0 AND archived = 0
            ORDER BY detected_on DESC";
    $restes = array();
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $restes[] = array(
                'fk_product' => (int) $obj->fk_product,
                'facture_ref' => $obj->facture_ref,
                'ref' => $obj->product_ref,
                'label' => $obj->product_label,
                'qty' => $obj->qty_manquante,
                'time' => date('H:i', strtotime($obj->detected_on)),
            );
        }
    }

    return $restes;
}


function depotGetLivraison($db, $fk_facture)
{
    $fk_facture = (int) $fk_facture;

    $sql = "SELECT rowid, fk_facture, telephone, note, date_prevue_livraison
            FROM ".MAIN_DB_PREFIX."depot_livraisons
            WHERE fk_facture = ".$fk_facture."
            LIMIT 1";

    $resql = $db->query($sql);

    if ($resql && ($obj = $db->fetch_object($resql))) {
        return $obj;
    }

    return null;
}


function depotSaveLivraison($db, $fk_facture, $telephone, $note, $date_prevue_livraison)
{
    $fk_facture = (int) $fk_facture;
    $telephone = trim($telephone);
    $note = trim($note);
    $date_prevue_livraison = trim($date_prevue_livraison);

    $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_livraisons (
                fk_facture,
                telephone,
                note,
                date_prevue_livraison,
                date_creation
            ) VALUES (
                ".$fk_facture.",
                '".$db->escape($telephone)."',
                '".$db->escape($note)."',
                ".(!empty($date_prevue_livraison)
                    ? "'".$db->escape($date_prevue_livraison)."'"
                    : "NULL").",
                NOW()
            )
            ON DUPLICATE KEY UPDATE
                telephone = VALUES(telephone),
                note = VALUES(note),
                date_prevue_livraison = VALUES(date_prevue_livraison),
                tms = NOW()";

    return $db->query($sql);
}

function depotCheckProductStock($db, $fk_product, $qty_needed, &$cache) {
    $stockData = depotGetProductStockByWarehouse_cached($db, $fk_product, $cache);
    return ((float) $stockData['total'] >= (float) $qty_needed);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['token'])) accessforbidden();

    // Variable pour le message de notification
    $notification_message = '';
    $notification_type    = 'success';

    $telephone_livraison = GETPOST('telephone_livraison', 'alphanohtml');
    $note_livraison = GETPOST('note_livraison', 'restricthtml');
    $date_prevue_livraison = GETPOST('date_prevue_livraison', 'alpha');

    // Actions liées à une facture (id > 0)
    if ($id > 0) {
        $facture = new Facture($db);

        if ($facture->fetch($id) <= 0) {
            header('Location: '.$phpSelf.'?view='.$view);
            exit;
        }

        if ((int) $facture->entity !== (int) $conf->entity) {
            accessforbidden();
        }

        /*
        * fk_statut Dolibarr :
        * 0 = brouillon
        * 1 = validée, non payée
        * 2 = payée
        * 3 = abandonnée
        */
        $invoice_status = (int) $facture->statut;

        $is_validated = (
            $invoice_status >= 1
            && $invoice_status !== 3
        );
       if ($action === 'save_livraison') {
            $todayDeliveryMin = date('Y-m-d');

            if (
                !empty($date_prevue_livraison)
                && $date_prevue_livraison < $todayDeliveryMin
            ) {
                $_SESSION['depot_notification_message'] = 'La date prévue de livraison ne peut pas être antérieure à aujourd’hui';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view=reste');
                exit;
            }

            $resultSaveLivraison = depotSaveLivraison(
                $db,
                $id,
                $telephone_livraison,
                $note_livraison,
                $date_prevue_livraison
            );

            if ($resultSaveLivraison > 0) {
                $_SESSION['depot_notification_message'] = 'Informations de livraison enregistrées';
                $_SESSION['depot_notification_type'] = 'success';
            } else {
                $_SESSION['depot_notification_message'] = 'Erreur : informations de livraison non enregistrées - '.$db->lasterror();
                $_SESSION['depot_notification_type'] = 'error';
            }

            header('Location: '.$phpSelf.'?view=reste');
            exit;
        }

        if ($action === 'start') {

            $stockCheckTotal = 0.0;

            if (!empty($facture->lines) && is_array($facture->lines)) {
                foreach ($facture->lines as $line) {
                    if (empty($line->fk_product)) {
                        continue;
                    }

                    $stockData = depotGetProductStockByWarehouse_cached(
                        $db,
                        (int) $line->fk_product,
                        $cache
                    );

                    $stockCheckTotal += (float) $stockData['total'];
                }
            }

            if ($stockCheckTotal <= 0) {
                $_SESSION['depot_notification_message'] = 'Impossible de démarrer la préparation : aucun stock disponible.';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view=preparation');
                exit;
            }

           $resultStart = depotUpsertWorkRow($db, $id, array(
                'status' => 'en_cours',
                'start_time' => time(),
                'validated_on' => $isvalidated ? time() : null,
                'archived' => 0,
            ));

            if (!$resultStart) {
                $_SESSION['depot_notification_message'] = 'Impossible de commencer la préparation.';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view='.
                    ($view === 'sans_stock' ? 'sans_stock' : 'preparation'));
                exit;
            }

            $_SESSION['depot_notification_message'] = 'Préparation démarrée.';
            $_SESSION['depot_notification_type'] = 'success';

            header('Location: '.$phpSelf.'?view=preparation');
            exit;


        } elseif ($action === 'move_no_stock') {
            $moveError = '';

            if ((int) $facture->entity !== (int) $conf->entity) {
                accessforbidden();
            }

            unset($cache['works'][(int) $id]);
            $workNoStock = depotGetWorkRow($db, $id, $cache);

            $currentNoStockStatus = $workNoStock
                ? $workNoStock->status
                : 'a_preparer';

            if (
                ($workNoStock && (int) $workNoStock->archived === 1)
                || $currentNoStockStatus !== 'a_preparer'
            ) {
                $moveError = 'Cette commande ne peut plus être déplacée vers Aucun stock.';
            }

            /*
            * Vérification côté serveur :
            * au moins un produit commandé doit avoir un stock positif
            * pour pouvoir commencer une préparation partielle.
            */
            $hasRequestedProduct = false;
            $hasAvailableProduct = false;

            if ($moveError === '' && !empty($facture->lines)) {
                foreach ($facture->lines as $stockLine) {
                    $productId = (int) $stockLine->fk_product;

                    if ($productId <= 0 || (float) $stockLine->qty <= 0) {
                        continue;
                    }

                    $hasRequestedProduct = true;
                    unset($cache['stocks'][$productId]);

                    $stockDataCheck = depotGetProductStockByWarehouse_cached(
                        $db,
                        $productId,
                        $cache
                    );

                    if ((float) $stockDataCheck['total'] > 0) {
                        $hasAvailableProduct = true;
                    }
                }

                if (!$hasRequestedProduct) {
                    $moveError = 'Cette facture ne contient aucun produit à préparer.';
                } elseif ($hasAvailableProduct) {
                    $moveError = 'Du stock est maintenant disponible. Actualisez la page pour commencer la préparation.';
                }
            }

            if ($moveError === '') {
                $resultMove = depotUpsertWorkRow($db, $id, array(
                    'status' => 'sans_stock',
                    'archived' => 0,
                ));

                if (!$resultMove) {
                    $moveError = 'Impossible de déplacer la commande vers Aucun stock.';
                }
            }

            $_SESSION['depot_notification_message'] = $moveError !== ''
                ? $moveError
                : 'Commande déplacée vers Aucun stock.';

            $_SESSION['depot_notification_type'] = $moveError !== ''
                ? 'error'
                : 'success';

            header('Location: '.$phpSelf.'?view='.
                ($moveError !== '' ? 'preparation' : 'sans_stock'));
            exit;


        } elseif ($action === 'finish') {
            $work = depotGetWorkRow($db, $id, $cache);
            $start = !empty($work->start_time) ? strtotime($work->start_time) : time();
            $duration = time() - $start;

            if ($is_validated) {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'livre',
                    'duration' => $duration,
                    'finish_time' => time(),
                    'delivered_on' => time(),
                    'validated_on' => $work->validated_on ?? null,
                ));
                $notification_message = 'Commande préparée';
            } else {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'prepare',
                    'duration' => $duration,
                    'finish_time' => time(),
                    'validated_on' => $work->validated_on ?? null,
                ));
                $notification_message = 'Commande préparée';
            }

            depotSyncRestes($db, $id, $facture, $cache);

        } elseif ($action === 'deliver') {
            $work = depotGetWorkRow($db, $id, $cache);

            $sqlActiveRestes = "SELECT COUNT(*) as nb
                                FROM ".MAIN_DB_PREFIX."depot_restes
                                WHERE fk_facture = ".((int) $id)."
                                AND resolved = 0
                                AND archived = 0";

            $resActiveRestes = $db->query($sqlActiveRestes);
            $hasActiveRestes = false;

            if ($resActiveRestes && ($objActiveRestes = $db->fetch_object($resActiveRestes))) {
                $hasActiveRestes = ((int) $objActiveRestes->nb > 0);
            }

            if ($hasActiveRestes && empty($fk_product)) {
                $_SESSION['depot_notification_message'] = 'Impossible de livrer complètement : il reste des produits à livrer.';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view=reste');
                exit;
            }

            if (!empty($fk_product)) {
                $sql = "UPDATE ".MAIN_DB_PREFIX."depot_restes
                        SET resolved = 1, resolved_on = NOW(), archived = 1, archived_on = NOW()
                        WHERE fk_facture = ".((int)$id)."
                          AND fk_product = ".((int)$fk_product)."
                          AND resolved = 0
                        LIMIT 1";
                $db->query($sql);

                $remaining_sql = "SELECT COUNT(*) as nb
                                  FROM ".MAIN_DB_PREFIX."depot_restes
                                  WHERE fk_facture = ".((int)$id)."
                                    AND resolved = 0
                                    AND archived = 0";
                $res_rem = $db->query($remaining_sql);
                $nb_remaining = 0;
                if ($res_rem && ($obj_rem = $db->fetch_object($res_rem))) {
                    $nb_remaining = (int) $obj_rem->nb;
                }

                if ($nb_remaining == 0) {
                    /*
                    * Dernier reste livré :
                    * la facture réapparaît dans "livre" avec la quantité totale.
                    * Elle n'est pas encore archivée.
                    */
                    depotUpsertWorkRow($db, $id, array(
                        'status' => 'livre',
                        'duration' => (int)($work->duration ?? 0),
                        'finish_time' => time(),
                        'delivered_on' => time(),
                    ));

                    $sqlReactivateWork = "UPDATE ".MAIN_DB_PREFIX."depot_work
                                        SET archived = 0,
                                            archived_on = NULL,
                                            status = 'livre'
                                        WHERE fk_facture = ".((int) $id);

                    $resReactivateWork = $db->query($sqlReactivateWork);

                    if (!$resReactivateWork) {
                        $_SESSION['depot_notification_message'] = 'Erreur lors de la réactivation de la facture.';
                        $_SESSION['depot_notification_type'] = 'error';

                        header('Location: '.$phpSelf.'?view=reste');
                        exit;
                    }

                    $notification_message = 'Commande ajoutée comme livrable';
                } else {
                    /*
                    * Il reste encore d'autres produits à livrer.
                    * La facture reste dans "Reste à livrer".
                    */
                    $notification_message = 'Ligne ajoutée comme livrable';
                }
            } else {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'livre',
                    'duration' => (int)($work->duration ?? 0),
                    'finish_time' => time(),
                    'delivered_on' => time(),
                ));
                depotSyncRestes($db, $id, $facture, $cache);
                $notification_message = 'Commande ajoutée comme livrable';
            }

       } elseif ($action === 'deliver_partial' || $action === 'deliver_partial_archive') {
            $factureId = (int) GETPOST('id', 'int');

            if ($factureId <= 0) {
                setEventMessages('Facture invalide.', null, 'errors');
                header('Location: '.$_SERVER['PHP_SELF'].'?view='.$view);
                exit;
            }

            $factureToDeliver = new Facture($db);

            if ($factureToDeliver->fetch($factureId) <= 0) {
                setEventMessages('Facture introuvable.', null, 'errors');
                header('Location: '.$_SERVER['PHP_SELF'].'?view='.$view);
                exit;
            }

            /*
            * Vérifie qu'il reste au moins une quantité disponible.
            */
            $partialAvailable = false;

            if (!empty($factureToDeliver->lines) && is_array($factureToDeliver->lines)) {
                foreach ($factureToDeliver->lines as $line) {
                    if (empty($line->fk_product)) {
                        continue;
                    }

                    $stockData = depotGetProductStockByWarehouse_cached(
                        $db,
                        (int) $line->fk_product,
                        $cache
                    );

                    if ((float) $stockData['total'] > 0) {
                        $partialAvailable = true;
                        break;
                    }
                }
            }

            if (!$partialAvailable) {
                setEventMessages('Aucune quantité disponible pour une livraison partielle.', null, 'errors');
                header('Location: '.$_SERVER['PHP_SELF'].'?view='.$view);
                exit;
            }

            /*
            * Récupère la préparation existante de la facture.
            */
            $workToPartialDeliver = depotGetWorkRow($db, $factureId, $cache);

            if (!$workToPartialDeliver) {
                setEventMessages('Préparation introuvable pour cette facture.', null, 'errors');
                header('Location: '.$_SERVER['PHP_SELF'].'?view='.$view);
                exit;
            }

            /*
            * Règle importante :
            * une livraison partielle n'archive jamais la facture.
            *
            * - Facture provisoire : elle reste dans "prepare".
            * - Facture validée : elle passe dans "livre".
            *
            * Les restes actifs ne sont ni résolus ni archivés.
            */
            $invoiceStatusPartial = (int) $factureToDeliver->statut;

            if ($invoiceStatusPartial === 0) {
                $partialNewStatus = 'prepare';
            } else {
                $partialNewStatus = 'livre';
            }

            $now = date('Y-m-d H:i:s');

            /*
            * La facture quitte prepare et livre,
            * mais elle n'est PAS archivée.
            *
            * Elle passe dans le statut intermédiaire "en_reste".
            * Elle n'apparaîtra donc ni dans prepare, ni dans livre,
            * ni dans Livré / archives.
            */
            $sqlPartialDeliver = "UPDATE ".MAIN_DB_PREFIX."depot_work
                                SET status = 'en_reste',
                                    archived = 0,
                                    archived_on = NULL,
                                    delivered_on = '".$db->escape($now)."'
                                WHERE rowid = ".((int) $workToPartialDeliver->rowid);

            $resPartialDeliver = $db->query($sqlPartialDeliver);

           if (!$resPartialDeliver) {
                setEventMessages('Erreur lors du déplacement vers Reste à livrer.', null, 'errors');
                header('Location: '.$_SERVER['PHP_SELF'].'?view='.$view);
                exit;
            }

            setEventMessages('Facture ajoutée dans Reste à livrer.', null, 'mesgs');

            header('Location: '.$_SERVER['PHP_SELF'].'?view=reste');
            exit;
        } elseif ($action === 'send_to_reste') {
            $factureId = (int) GETPOST('id', 'int');

            if ($factureId <= 0) {
                $_SESSION['depot_notification_message'] = 'Facture invalide.';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view='.$view);
                exit;
            }

            $factureToSend = new Facture($db);

            if ($factureToSend->fetch($factureId) <= 0) {
                $_SESSION['depot_notification_message'] = 'Facture introuvable.';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view='.$view);
                exit;
            }

            $workToSend = depotGetWorkRow($db, $factureId, $cache);

            if (!$workToSend) {
                $_SESSION['depot_notification_message'] = 'Aucune préparation trouvée pour cette facture.';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view='.$view);
                exit;
            }

            /*
            * Enregistre ou met à jour les restes.
            */
            depotSyncRestes($db, $factureId, $factureToSend, $cache);

            /*
            * La facture quitte prepare et livre,
            * sans aller dans Livré / archives.
            */
            $sqlMoveToReste = "UPDATE ".MAIN_DB_PREFIX."depot_work
                            SET status = 'en_reste',
                                archived = 0,
                                archived_on = NULL
                            WHERE rowid = ".((int) $workToSend->rowid);

            $resMoveToReste = $db->query($sqlMoveToReste);

            if (!$resMoveToReste) {
                $_SESSION['depot_notification_message'] = 'Erreur lors du déplacement vers Reste à livrer.';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view='.$view);
                exit;
            }

            $_SESSION['depot_notification_message'] = 'Facture ajoutée dans Reste à livrer.';
            $_SESSION['depot_notification_type'] = 'success';

            header('Location: '.$phpSelf.'?view=reste');
            exit;
        } elseif ($action === 'archive') {
            $work = depotGetWorkRow($db, $id, $cache);
            $current_status = $work ? $work->status : 'a_preparer';
            depotUpsertWorkRow($db, $id, array(
                'status' => $current_status,
                'archived' => 1,
                'archived_on' => time(),
            ));
            $notification_message = 'Commande livrée';
        }

        // Sauvegarder la notification en session
        if (!empty($notification_message)) {
            $_SESSION['depot_notification_message'] = $notification_message;
            $_SESSION['depot_notification_type']    = $notification_type;
        }

        header('Location: '.$phpSelf.'?view='.$view);
        exit;
    }

    // Action globale (sans id) : TOUT ARCHIVER
    if ($action === 'archive_all') {
        $sql = "UPDATE ".MAIN_DB_PREFIX."depot_work
                SET archived = 1, archived_on = NOW()
                WHERE status = 'livre' AND archived = 0";
        $db->query($sql);

        $_SESSION['depot_notification_message'] = 'Toutes les commandes ont été livrées';
        $_SESSION['depot_notification_type']    = 'success';

        header('Location: '.$phpSelf.'?view=livre');
        exit;
    }

    // Action globale (sans id) : EXPEDIABLE pour toutes les factures totalement disponibles
    if ($action === 'deliver_all') {
        $expediable_ids_str = GETPOST('expediable_ids', 'alpha');
        $expediable_ids = array();

        if (!empty($expediable_ids_str)) {
            foreach (explode(',', $expediable_ids_str) as $fid) {
                $fid = (int) trim($fid);
                if ($fid > 0) $expediable_ids[] = $fid;
            }
        }

        if (!empty($expediable_ids)) {
            foreach ($expediable_ids as $fid) {
                $facture = new Facture($db);
                $facture->fetch($fid);

                if ((int) $facture->entity !== (int) $conf->entity) {
                    continue;
                }

                $work = depotGetWorkRow($db, $fid, $cache);
                depotUpsertWorkRow($db, $fid, array(
                    'status' => 'livre',
                    'duration' => (int)($work && $work->duration ? $work->duration : 0),
                    'finish_time' => time(),
                    'delivered_on' => time(),
                ));

                $sql = "UPDATE ".MAIN_DB_PREFIX."depot_restes
                        SET resolved = 1, resolved_on = NOW(), archived = 1, archived_on = NOW()
                        WHERE fk_facture = ".$fid." AND resolved = 0 AND archived = 0";
                $db->query($sql);
            }
        }

        $_SESSION['depot_notification_message'] = 'Toutes les commandes disponibles ont été livrées';
        $_SESSION['depot_notification_type']    = 'success';

        header('Location: '.$phpSelf.'?view=reste');
        exit;
    }

    elseif ($action === 'send_to_reste') {
    $factureId = (int) GETPOST('id', 'int');

    if ($factureId <= 0) {
        setEventMessages('Facture invalide.', null, 'errors');
        header('Location: '.$_SERVER['PHP_SELF'].'?view='.$view);
        exit;
    }

    $factureToSend = new Facture($db);

    if ($factureToSend->fetch($factureId) <= 0) {
        setEventMessages('Facture introuvable.', null, 'errors');
        header('Location: '.$_SERVER['PHP_SELF'].'?view='.$view);
        exit;
    }

    /*
     * Enregistre ou met à jour les produits manquants
     * dans "Reste à livrer".
     */
    depotSyncRestes($db, $factureId, $factureToSend, $cache);

    setEventMessages('Produits manquants ajoutés dans Reste à livrer.', null, 'mesgs');

    header('Location: '.$_SERVER['PHP_SELF'].'?view=reste');
    exit;
}
}

    llxHeader('', 'Espace Responsable Dépôt');

    // Notification popup (flash)
$notifMessage = '';
$notifType = '';

if (!empty($_SESSION['depot_notification_message'])) {
    $notifMessage = $_SESSION['depot_notification_message'];
    $notifType = !empty($_SESSION['depot_notification_type']) ? $_SESSION['depot_notification_type'] : 'success';
    unset($_SESSION['depot_notification_message'], $_SESSION['depot_notification_type']);
}

if (!empty($notifMessage)) {
    print '<div id="depot-notif" class="depot-notif depot-notif-'.$notifType.'">';
    print dol_escape_htmltag($notifMessage);
    print '</div>';
}

print '<style>

.depot-notif {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    padding: 10px 16px;
    border-radius: 4px;
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}
.depot-notif-success {
    background: #27ae60;
}
.depot-notif-error {
    background: #c0392b;
}

.depot-wrap { margin-top: 20px; }
.depot-toolbar { margin-top: 20px; padding: 10px 12px; background: #fff; border: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center; gap: 10px; }
.depot-title { margin: 0; font-size: 18px; color: #333; }
.depot-btn { padding: 8px 12px; border: 1px solid #999; background: #f7f7f7; color: #222; cursor: pointer; font-weight: bold; text-decoration: none; display: inline-block; }
.depot-btn:hover { background: #efefef; }
.depot-panel { background: #fff; padding: 12px; margin-bottom: 15px; border: 1px solid #ddd; }
.depot-note { background: #f8fbff; border: 1px solid #d6e6f7; padding: 12px; margin-bottom: 16px; }
.depot-table { width: 100%; border-collapse: collapse; background: #fff; border: 1px solid #ddd; font-size: 14px; }
.depot-table th, .depot-table td { border: 1px solid #e3e3e3; padding: 8px 10px; vertical-align: top; }
.depot-table th { background: #f2f2f2; text-align: left; }
.depot-table tr:nth-child(even) td { background: #fafafa; }
.depot-status-ok { background: #eaf7ee; color: #1f7a39; padding: 10px; margin-bottom: 10px; }
.depot-status-warn { background: #fff4db; color: #8a5a00; padding: 10px; margin-bottom: 10px; }
.depot-status-blue { background: #eef6ff; color: #1457a6; padding: 10px; margin-bottom: 10px; }
.depot-status-muted { background: #f3f4f6; color: #333; padding: 10px; margin-bottom: 10px; }
.depot-form { margin-top: 12px; }
.depot-form-btn { padding: 8px 14px; border: 1px solid #888; background: #f7f7f7; cursor: pointer; font-weight: bold; }
.depot-form-btn-success { background: #27ae60; color: #fff; border-color: #27ae60; }
.depot-form-btn-primary { background: #2980b9; color: #fff; border-color: #2980b9; }
.depot-arch-btn { background: #fff; color: #1f7a39; border: 1px solid #1f7a39; padding: 5px 10px; cursor: pointer; font-weight: bold; }

.depot-reste-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin: 8px 0 16px;
}

.depot-reste-card {
    border: 1px solid #e2e8f0;
    border-left: 5px solid #dc2626;
    border-radius: 8px;
    background: #fff;
    padding: 0;
    margin-bottom: 16px;
    overflow: hidden;
}

.depot-reste-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 16px;
    padding: 14px 16px;
    background: #fff7f7;
    border-bottom: 1px solid #fee2e2;
}

.depot-reste-facture {
    font-size: 17px;
    font-weight: bold;
    color: #991b1b;
}

.depot-reste-client {
    margin-top: 4px;
    color: #475569;
    font-size: 14px;
}

.depot-reste-status {
    white-space: nowrap;
    display: inline-block;
    padding: 6px 10px;
    border-radius: 999px;
    background: #fee2e2;
    color: #b91c1c;
    font-size: 12px;
    font-weight: bold;
}

.depot-livraison-summary {
    display: grid;
    grid-template-columns: repeat(3, minmax(170px, 1fr));
    gap: 10px;
    padding: 12px 16px;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
}

.depot-livraison-item {
    padding: 9px 10px;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: #fff;
    font-size: 13px;
    color: #334155;
}

.depot-livraison-label {
    display: block;
    margin-bottom: 4px;
    font-size: 11px;
    font-weight: bold;
    color: #64748b;
    text-transform: uppercase;
}

.depot-livraison-form {
    margin: 12px 16px;
    padding: 12px;
    border: 1px solid #bfdbfe;
    border-radius: 6px;
    background: #f8fbff;
}

.depot-livraison-form-title {
    margin-bottom: 10px;
    font-size: 14px;
    font-weight: bold;
    color: #1457a6;
}

.depot-livraison-grid {
    display: grid;
    grid-template-columns: minmax(220px, 1fr) minmax(190px, 250px);
    gap: 10px;
}

.depot-livraison-field label {
    display: block;
    margin-bottom: 4px;
    font-size: 12px;
    font-weight: bold;
    color: #475569;
}

.depot-livraison-field input,
.depot-livraison-field textarea {
    width: 100%;
    box-sizing: border-box;
    padding: 8px;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    background: #fff;
}

.depot-livraison-note {
    margin-top: 10px;
}

.depot-livraison-actions {
    margin-top: 10px;
    text-align: right;
}

.depot-reste-products {
    padding: 0 16px 16px;
}

.depot-reste-products-title {
    margin: 14px 0 8px;
    font-size: 13px;
    font-weight: bold;
    color: #475569;
}

.depot-reste-product {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    padding: 12px;
    margin-bottom: 8px;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: #fff;
}

.depot-reste-product-main {
    min-width: 0;
    flex: 1;
}

.depot-reste-product-name {
    margin-bottom: 7px;
    font-weight: bold;
    color: #1e293b;
}

.depot-reste-product-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 7px 14px;
    color: #475569;
    font-size: 13px;
}

.depot-reste-product-meta strong {
    color: #334155;
}

.depot-reste-product-actions {
    flex: 0 0 auto;
    text-align: right;
}

.depot-reste-global-action {
    margin: 4px 16px 16px;
    padding: 12px;
    border: 1px solid #86efac;
    border-radius: 6px;
    background: #f0fdf4;
    text-align: right;
}

@media screen and (max-width: 800px) {
    .depot-reste-card-header,
    .depot-reste-product {
        display: block;
    }

    .depot-reste-status,
    .depot-reste-product-actions {
        margin-top: 10px;
        text-align: left;
    }

    .depot-livraison-summary,
    .depot-livraison-grid {
        grid-template-columns: 1fr;
    }
}


.depot-order-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
}

.depot-order-header h3 {
    margin: 0;
}


.depot-toggle-detail {
    padding: 6px 10px;
    border: 1px solid #999;
    background: #f7f7f7;
    color: #222;
    cursor: pointer;
    font-weight: bold;
    white-space: nowrap;
}

.depot-toggle-detail:hover {
    background: #efefef;
}

/* Zone qui contient client, date, produits, stock et actions */
.depot-order-detail {
    margin-top: 12px;
}

.depot-order-detail.is-hidden {
    display: none;
}

@media screen and (max-width: 600px) {
    .depot-order-header {
        flex-direction: column;
        align-items: flex-start;
    }
}

.depot-form-btn-warning {
    background: #f39c12;
    color: #fff;
    border-color: #f39c12;
}
</style>';

$sql_check = "SELECT count(rowid) as nb FROM ".MAIN_DB_PREFIX."facture WHERE fk_statut IN (0,1,2) AND entity = ".((int) $conf->entity);
$res_check = $db->query($sql_check);
$nb_actuel = 0;
if ($res_check && ($obj_check = $db->fetch_object($res_check))) {
    $nb_actuel = (int) $obj_check->nb;
}

print '<script>

document.addEventListener("DOMContentLoaded", function() {
    var notif = document.getElementById("depot-notif");
    if (notif) {
        setTimeout(function() {
            notif.style.transition = "opacity 0.5s ease, transform 0.5s ease";
            notif.style.opacity = "0";
            notif.style.transform = "translateY(-10px)";
            setTimeout(function() {
                if (notif && notif.parentNode) {
                    notif.parentNode.removeChild(notif);
                }
            }, 600);
        }, 3000); // 3 secondes avant disparition
    }
});

let currentCount = '.$nb_actuel.';
let lastCount = localStorage.getItem("last_depot_count") || 0;
localStorage.setItem("last_depot_count", currentCount);


function depotFormatHMS(sec) {
    sec = Math.max(0, Math.floor(sec));

    let h = Math.floor(sec / 3600);
    let m = Math.floor((sec % 3600) / 60);
    let s = sec % 60;

    return String(h).padStart(2, "0")
        + ":"
        + String(m).padStart(2, "0")
        + ":"
        + String(s).padStart(2, "0");
}

function depotStartTimers() {
    document.querySelectorAll("[data-depot-start]").forEach(function(el) {
        let start = parseInt(el.getAttribute("data-depot-start"), 10);
        let target = el.querySelector(".depot-elapsed");

        if (!start || !target) {
            return;
        }

        function tick() {
            target.textContent = depotFormatHMS(
                (Date.now() - (start * 1000)) / 1000
            );
        }

        tick();
        setInterval(tick, 1000);
    });
}


var depotOpenDetailsStorageKey = "depot_preparation_open_details";


function depotGetOpenDetails() {
    try {
        var stored = localStorage.getItem(depotOpenDetailsStorageKey);

        if (!stored) {
            return [];
        }

        var details = JSON.parse(stored);

        return Array.isArray(details) ? details : [];
    } catch (error) {
        return [];
    }
}


function depotSaveOpenDetails(details) {
    try {
        localStorage.setItem(
            depotOpenDetailsStorageKey,
            JSON.stringify(details)
        );
    } catch (error) {
        
    }
}


function depotSetDetailOpen(detailId, shouldBeOpen) {
    var details = depotGetOpenDetails();

    if (shouldBeOpen) {
        if (details.indexOf(detailId) === -1) {
            details.push(detailId);
        }
    } else {
        details = details.filter(function(id) {
            return id !== detailId;
        });
    }

    depotSaveOpenDetails(details);
}


function depotUpdateDetailDisplay(button, detail, shouldBeOpen) {
    if (shouldBeOpen) {
        detail.classList.remove("is-hidden");
        button.textContent = "Masquer le détail";
        button.setAttribute("aria-expanded", "true");
    } else {
        detail.classList.add("is-hidden");
        button.textContent = "Afficher le détail";
        button.setAttribute("aria-expanded", "false");
    }
}


function depotInitOrderDetails() {
    var buttons = document.querySelectorAll(".depot-toggle-detail");

    if (!buttons.length) {
        return;
    }

    var openDetails = depotGetOpenDetails();
    var visibleDetailIds = [];

    buttons.forEach(function(button) {
        var detailId = button.getAttribute("data-target");
        var detail = document.getElementById(detailId);

        if (!detailId || !detail) {
            return;
        }

        visibleDetailIds.push(detailId);

       
        var shouldBeOpen = openDetails.indexOf(detailId) !== -1;
        depotUpdateDetailDisplay(button, detail, shouldBeOpen);

       
        button.addEventListener("click", function() {
            var currentlyOpen = !detail.classList.contains("is-hidden");
            var shouldOpenNow = !currentlyOpen;

            depotUpdateDetailDisplay(button, detail, shouldOpenNow);
            depotSetDetailOpen(detailId, shouldOpenNow);
        });
    });

    
    openDetails = openDetails.filter(function(detailId) {
        return visibleDetailIds.indexOf(detailId) !== -1;
    });

    depotSaveOpenDetails(openDetails);
}

document.addEventListener("DOMContentLoaded", depotStartTimers);
document.addEventListener("DOMContentLoaded", depotInitOrderDetails);
</script>';

if ($view === 'preparation') {
    print '<script>
        setTimeout(function(){
            location.reload();
        }, 10000);
    </script>';
}

if ($view === 'preparation') {
    print '<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Aucun rafraîchissement automatique partiel de la liste.
        // La liste reste stable jusqu’au clic sur le bouton Actualiser.
    });
    </script>';
}
print '<div class="depot-toolbar">';
print '<h2 class="depot-title">📦 Gestion de commande</h2>';
print '<div style="display:flex; gap:10px; align-items:center;">';
print '<button type="button" class="depot-btn" onclick="location.reload()">🔄 Actualiser</button>';

if ($view === 'preparation') {
$screenClientUrl = dol_buildpath('/custom/depot/screen_client.php', 1);
print '<a href="'.$screenClientUrl.'" target="_blank" class="depot-btn" style="text-decoration:none;color:#222;">';
print 'Écran client';
print '</a>';

}


if ($view === 'livre') {
    print '<form method="POST" style="margin:0;">';
    print '<input type="hidden" name="token" value="'.newToken().'">';
    print '<input type="hidden" name="view" value="livre">';
    print '<button type="submit" name="action" value="archive_all" class="depot-btn">🗂️ Tout livrer</button>';
    print '</form>';
}


   
print '</div>';
print '</div>';

print '<style>
.depot-float-refresh{
    position:fixed;
    right:18px;
    bottom:18px;
    z-index:9999;
    box-shadow:0 8px 18px rgba(0,0,0,0.15);
    border-radius:999px;
}
</style>';


if ($view === 'archives') {
    print '<form method="GET" style="margin:0 0 20px 0; padding:12px; background:#fff; border:1px solid #ddd; display:flex; gap:10px; align-items:center;">';
    print '<input type="hidden" name="view" value="archives">';
    print '<label for="tranche" style="font-weight:bold;">Filtrer par durée :</label>';
    print '<select name="tranche" id="tranche" style="padding:6px; border:1px solid #ccc;">';
    print '<option value="">-- Toutes les durées --</option>';
    print '<option value="<5min" '.($tranche === '<5min' ? 'selected' : '').'>Moins de 5 min</option>';
    print '<option value="5-15min" '.($tranche === '5-15min' ? 'selected' : '').'>5 à 15 min</option>';
    print '<option value="15-30min" '.($tranche === '15-30min' ? 'selected' : '').'>15 à 30 min</option>';
    print '<option value="30-60min" '.($tranche === '30-60min' ? 'selected' : '').'>30 à 60 min</option>';
    print '<option value=">1h" '.($tranche === '>1h' ? 'selected' : '').'>Plus de 1 h</option>';
    print '</select>';
    print '<button type="submit" class="depot-btn">Filtrer</button>';
    print '<a href="'.$phpSelf.'?view=archives" class="depot-btn" style="text-decoration:none;">Réinitialiser</a>';
    print '</form>';
}

if ($view === 'reste') {
    print '<div class="depot-wrap">';

    $sql = "SELECT DISTINCT w.fk_facture
        FROM ".MAIN_DB_PREFIX."depot_work w
        INNER JOIN ".MAIN_DB_PREFIX."facture f ON f.rowid = w.fk_facture
        INNER JOIN ".MAIN_DB_PREFIX."depot_restes r ON r.fk_depot_work = w.rowid
        WHERE r.resolved = 0
          AND r.archived = 0
          AND f.entity = ".((int) $conf->entity);
    $res = $db->query($sql);

    $allRestes = array();

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $fid = (int) $obj->fk_facture;

            $work = depotGetWorkRow($db, $fid, $cache);

            if ($work) {
                $allRestes[$fid] = depotGetRestes(
                    $db,
                    (int) $work->rowid
                );
            }
        }
    }

    if (!empty($allRestes)) {
        print '<div class="depot-reste-title">';
        print '<h2 style="color:#666; margin:0;">⚠️ Restes à livrer</h2>';
        print '</div>';

        /*
         * 1. Construire la liste des factures totalement expédiables.
         * Logique métier inchangée.
         */
        $expediableIds = array();

        foreach ($allRestes as $factid => $lesrestes) {
            $livraisonCheck = depotGetLivraison($db, $factid);

            $hasLivraisonInfoCheck = (
                $livraisonCheck
                && !empty(trim($livraisonCheck->telephone))
                && !empty(trim($livraisonCheck->note))
                && !empty($livraisonCheck->date_prevue_livraison)
            );

            $allAvailableForFacture = true;

            foreach ($lesrestes as $rcheck) {
                if (!depotCheckProductStock(
                    $db,
                    $rcheck['fk_product'],
                    $rcheck['qty'],
                    $cache
                )) {
                    $allAvailableForFacture = false;
                    break;
                }
            }

            if ($allAvailableForFacture && $hasLivraisonInfoCheck) {
                $expediableIds[] = (int) $factid;
            }
        }

        $lastExpediableId = null;

        if (!empty($expediableIds)) {
            $lastExpediableId = end($expediableIds);
            reset($expediableIds);
        }

        /*
         * Trier : A commander d’abord, expédiable ensuite.
         * Logique métier inchangée.
         */
        $sortedRestes = array();

        foreach ($allRestes as $factid => $lesrestes) {
            if (!in_array((int) $factid, $expediableIds, true)) {
                $sortedRestes[$factid] = $lesrestes;
            }
        }

        foreach ($expediableIds as $expid) {
            if (isset($allRestes[$expid])) {
                $sortedRestes[$expid] = $allRestes[$expid];
            }
        }

        $allRestes = $sortedRestes;

        // Date minimale autorisée pour une livraison : aujourd'hui
        $todayDeliveryMin = date('Y-m-d');

        /*
         * 2. Affichage des factures.
         */
        foreach ($allRestes as $fact_id => $les_restes) {
            $facturetmp = new Facture($db);
            $facturetmp->fetch($fact_id);

            $soctmp = new Societe($db);
            $soctmp->fetch($facturetmp->socid);

            $invoiceAuthorName = depotGetInvoiceAuthorName($db, $facturetmp);

            $livraison = depotGetLivraison($db, (int) $fact_id);

            $telephoneLivraison = '';
            $noteLivraison = '';
            $datePrevueLivraison = '';

            if ($livraison) {
                $telephoneLivraison = !empty($livraison->telephone)
                    ? $livraison->telephone
                    : '';

                $noteLivraison = !empty($livraison->note)
                    ? $livraison->note
                    : '';

                $datePrevueLivraison = !empty($livraison->date_prevue_livraison)
                    ? $livraison->date_prevue_livraison
                    : '';
            }

            /*
            * Si aucune note de livraison n'a encore été enregistrée,
            * préremplir avec la note de la facture.
            *
            * Priorité :
            * 1. note publique de la facture ;
            * 2. note privée de la facture.
            */
            if (empty(trim($noteLivraison))) {
                if (!empty(trim($facturetmp->note_public))) {
                    $noteLivraison = $facturetmp->note_public;
                } elseif (!empty(trim($facturetmp->note_private))) {
                    $noteLivraison = $facturetmp->note_private;
                }
            }

            $hasLivraisonInfo = (
                !empty(trim($telephoneLivraison))
                && !empty(trim($noteLivraison))
                && !empty($datePrevueLivraison)
            );

            print '<div class="depot-reste-card">';

            /*
             * En-tête facture.
             */
            print '<div class="depot-reste-card-header">';

            print '<div>';
            print '<div class="depot-reste-facture">';
            print 'Facture '.dol_escape_htmltag($facturetmp->ref);
            print '</div>';
            /* Date facture */
            $dateFactureLabel = depotGetFactureDateLabel($db, $facturetmp);
            print '<div style="margin-top:4px; color:#666; font-size:13px;">';
            print '<b>Date facture :</b> '.$dateFactureLabel;
            print '</div>';

            print '<div class="depot-reste-client">';
            print dol_escape_htmltag($soctmp->name);
            print '</div>';

            if (!empty($invoiceAuthorName)) {
                print '<div class="depot-reste-client" style="margin-top:3px;">';
                print 'Facture créée par : '.dol_escape_htmltag($invoiceAuthorName);
                print '</div>';
            }
            print '</div>';

            print '<span class="depot-reste-status">Reste à livrer</span>';

            print '</div>';

            /*
             * Résumé informations de livraison.
             */
            print '<div class="depot-livraison-summary">';

            print '<div class="depot-livraison-item">';
            print '<span class="depot-livraison-label">Téléphone</span>';
            print dol_escape_htmltag(
                !empty($telephoneLivraison)
                    ? $telephoneLivraison
                    : 'Non renseigné'
            );
            print '</div>';

            print '<div class="depot-livraison-item">';
            print '<span class="depot-livraison-label">Date prévue</span>';
            print dol_escape_htmltag(
                !empty($datePrevueLivraison)
                    ? $datePrevueLivraison
                    : 'Non renseignée'
            );
            print '</div>';

            print '<div class="depot-livraison-item">';
            print '<span class="depot-livraison-label">Note</span>';
            print dol_escape_htmltag(
                !empty($noteLivraison)
                    ? $noteLivraison
                    : 'Aucune note'
            );
            print '</div>';

            print '</div>';

            /*
             * Formulaire informations de livraison.
             */
            print '<form method="POST" class="depot-livraison-form">';

            print '<input type="hidden" name="token" value="'.newToken().'">';
            print '<input type="hidden" name="view" value="reste">';
            print '<input type="hidden" name="id" value="'.((int) $fact_id).'">';
            print '<input type="hidden" name="action" value="save_livraison">';

            print '<div class="depot-livraison-form-title">';
            print 'Informations de livraison';
            print '</div>';

            print '<div class="depot-livraison-grid">';

            print '<div class="depot-livraison-field">';
            print '<label>Téléphone de livraison</label>';
            print '<input type="text" name="telephone_livraison" value="'.dol_escape_htmltag($telephoneLivraison).'">';
            print '</div>';

            print '<div class="depot-livraison-field">';
            print '<label>Date prévue de livraison</label>';
            print '<input type="date" name="date_prevue_livraison" min="'.dol_escape_htmltag($todayDeliveryMin).'" value="'.dol_escape_htmltag($datePrevueLivraison).'">';
            print '</div>';

            print '</div>';

            print '<div class="depot-livraison-field depot-livraison-note">';
            print '<label>Note de livraison</label>';
            print '<textarea name="note_livraison" rows="2">'.dol_escape_htmltag($noteLivraison).'</textarea>';
            print '</div>';

            print '<div class="depot-livraison-actions">';
            print '<button type="submit" class="depot-form-btn depot-form-btn-primary">Enregistrer</button>';
            print '</div>';

            print '</form>';

            /*
             * Produits manquants.
             */
            print '<div class="depot-reste-products">';
            print '<div class="depot-reste-products-title">Produits restant à livrer</div>';

            foreach ($les_restes as $r) {
                $isAvailable = depotCheckProductStock(
                    $db,
                    $r['fk_product'],
                    $r['qty'],
                    $cache
                );

                $product = new Product($db);
                $currentStock = 0;
                $detailedLoc = '';

                if ($product->fetch($r['fk_product']) > 0) {
                    $currentStock = (int) ($product->stock_reel ?? 0);

                    $detailedLoc = depotGetDetailedLocation_cached(
                        $db,
                        $r['fk_product'],
                        $cache
                    );
                }

                print '<div class="depot-reste-product">';

                print '<div class="depot-reste-product-main">';

                print '<div class="depot-reste-product-name">';
                print '<a href="'.DOL_URL_ROOT.'/product/card.php?id='.((int) $r['fk_product']).'" target="_blank" rel="noopener">';
                print dol_escape_htmltag($r['ref']);
                print '</a>';
                print ' — '.dol_escape_htmltag($r['label']);
                print '</div>';

                print '<div class="depot-reste-product-meta">';

                print '<span><strong>Manquant :</strong> ';
                print depotFormatQty($r['qty']);
                print '</span>';

                print '<span><strong>Stock :</strong> ';
                print depotFormatQty($currentStock);
                print '</span>';

                print '<span><strong>Emplacement :</strong> ';
                print $detailedLoc;
                print '</span>';

                print '<span><strong>Signalé :</strong> ';
                print dol_escape_htmltag($r['time']);
                print '</span>';

                print '</div>';
                print '</div>';

                /*
                 * Action de ligne.
                 */
                print '<div class="depot-reste-product-actions">';
                print '<form method="POST" class="depot-form" style="margin:0;">';

                print '<input type="hidden" name="token" value="'.newToken().'">';
                print '<input type="hidden" name="view" value="reste">';
                print '<input type="hidden" name="id" value="'.((int) $fact_id).'">';
                print '<input type="hidden" name="fk_product" value="'.((int) $r['fk_product']).'">';

                if (!$hasLivraisonInfo) {
                    print '<button type="button" class="depot-form-btn" disabled style="color:#666; background:#ddd; border-color:#ddd; cursor:not-allowed;">';
                    print 'Informations livraison requises';
                    print '</button>';

                } elseif (!$isAvailable) {
                    print '<button type="button" class="depot-form-btn" disabled style="color:#666; background:#ddd; border-color:#ddd; cursor:not-allowed;">';
                    print 'A commander';
                    print '</button>';

                } else {
                    print '<button type="submit" name="action" value="deliver" class="depot-form-btn depot-form-btn-success">';
                    print 'Ligne livrable';
                    print '</button>';
                }

                print '</form>';
                print '</div>';

                print '</div>';
            }

            print '</div>';

            /*
             * Bouton global.
             */
            if (
                !empty($expediableIds)
                && $lastExpediableId !== null
                && (int) $fact_id === (int) $lastExpediableId
            ) {
                print '<div class="depot-reste-global-action">';

                print '<form method="POST" class="depot-form" style="margin:0;">';

                print '<input type="hidden" name="token" value="'.newToken().'">';
                print '<input type="hidden" name="view" value="reste">';
                print '<input type="hidden" name="action" value="deliver_all">';
                print '<input type="hidden" name="expediable_ids" value="'.dol_escape_htmltag(implode(',', $expediableIds)).'">';

                print '<button type="submit" class="depot-form-btn depot-form-btn-success">';
                print '🚚 Toutes commandes livrables';
                print '</button>';

                print '</form>';

                print '</div>';
            }

            print '</div>';
        }

    } else {
        print '<p style="color:#666;">⚠️ Aucun reste à livrer.</p>';
    }

    print '</div>';
    llxFooter();
    exit;
}

if ($view === 'archives') {
    print '<div class="depot-wrap">';
    print '<h2 style="color:#666;">📚  Commandes Livrées</h2>';

    $duration_filter = '';
    if (!empty($tranche)) {
        if ($tranche === '<5min') $duration_filter = ' AND w.duration < 300';
        elseif ($tranche === '5-15min') $duration_filter = ' AND w.duration >= 300 AND w.duration < 900';
        elseif ($tranche === '15-30min') $duration_filter = ' AND w.duration >= 900 AND w.duration < 1800';
        elseif ($tranche === '30-60min') $duration_filter = ' AND w.duration >= 1800 AND w.duration < 3600';
        elseif ($tranche === '>1h') $duration_filter = ' AND w.duration >= 3600';
    }

    $sql = "SELECT w.rowid, w.fk_facture, w.status, w.duration, w.archived, w.archived_on
        FROM ".MAIN_DB_PREFIX."depot_work w
        INNER JOIN ".MAIN_DB_PREFIX."facture f ON f.rowid = w.fk_facture
        WHERE w.archived = 1
          AND w.status = 'livre'
          AND f.entity = ".((int) $conf->entity).$duration_filter."
        ORDER BY w.archived_on DESC, w.tms DESC";
    $resql = $db->query($sql);

    $archives = array();
    if ($resql && $db->num_rows($resql) > 0) {
        while ($w = $db->fetch_object($resql)) {
            $facture = new Facture($db);
            if ($facture->fetch((int) $w->fk_facture) <= 0) continue;
            $archives[] = array('facture' => $facture, 'work' => $w, 'duration' => (int) $w->duration);
        }
    }

    if (!empty($archives)) {
        print '<table class="depot-table">';
        print '<tr><th>Facture</th><th>Produit</th><th>Libellé</th><th>Qté</th><th>Emplacement</th><th>Durée</th></tr>';
        foreach ($archives as $arch) {
            $facture = $arch['facture'];
            $dur = $arch['duration'];
            $soc = new Societe($db);
            $soc->fetch($facture->socid);
            $invoiceAuthorName = depotGetInvoiceAuthorName($db, $facture);

            foreach ($facture->lines as $line) {
                if (empty($line->fk_product)) continue;
                $product = new Product($db);
                $product->fetch($line->fk_product);
                $detailedLoc = depotGetDetailedLocation_cached($db, $product->id, $cache);

                print '<tr>';
                print '<td>';
                print dol_escape_htmltag($facture->ref).' '.dol_escape_htmltag($soc->name);

                                /* Date facture */
                $dateFactureLabel = depotGetFactureDateLabel($db, $facture);
                print '<br><span style="color:#666; font-size:12px;">';
                print '<b>Date facture :</b> '.$dateFactureLabel;
                print '</span>';

                if (!empty($invoiceAuthorName)) {
                    print '<br><span style="color:#666; font-size:12px;">';
                    print 'Créée par : '.dol_escape_htmltag($invoiceAuthorName);
                    print '</span>';
                }

                print '</td>';

                print '<td><a href="'.DOL_URL_ROOT.'/product/card.php?id='.(int)$product->id.'" target="_blank" rel="noopener">'.dol_escape_htmltag($product->ref).'</a></td>';
                print '<td>'.dol_escape_htmltag($product->label).'</td>';
                print '<td align="center">'.dol_escape_htmltag(depotFormatQty($line->qty)).'</td>';
                print '<td align="center">'.$detailedLoc.'</td>';
                print '<td align="center" style="font-weight:bold; color:#1f7a39;">'.depotDurationPretty($dur).'</td>';
                print '</tr>';
            }
        }
        print '</table>';
    } else {
        print '<p style="color:#666; font-size:16px;">📭 Aucune commande livrée.</p>';
        print '<p style="color:#999; font-size:13px;">Aucune commande livrée correspondante au filtre sélectionné.</p>';
    }

    print '</div>';
    llxFooter();
    exit;
}
if ($view === 'preparation') {
    $sql = "SELECT f.rowid
            FROM ".MAIN_DB_PREFIX."facture f
            INNER JOIN ".MAIN_DB_PREFIX."facturedet fd
                ON fd.fk_facture = f.rowid
               AND fd.fk_product > 0
            LEFT JOIN ".MAIN_DB_PREFIX."depot_work w
                ON w.fk_facture = f.rowid
            WHERE f.entity = ".((int) $conf->entity)."
              AND f.fk_statut IN (0,1,2)
              AND f.datec >= CURDATE()
              AND f.datec < CURDATE() + INTERVAL 1 DAY
              AND (w.rowid IS NULL OR (w.status IN ('a_preparer','en_cours') AND w.archived = 0))
            GROUP BY f.rowid
            ORDER BY f.datec ASC
            LIMIT ".((int) $preparation_limit);

 } elseif ($view === 'sans_stock') {
    $sql = "SELECT w.fk_facture AS rowid
            FROM ".MAIN_DB_PREFIX."depot_work w
            INNER JOIN ".MAIN_DB_PREFIX."facture f
                ON f.rowid = w.fk_facture
            WHERE w.status = 'sans_stock'
              AND w.archived = 0
              AND f.entity = ".((int) $conf->entity)."
              AND f.fk_statut IN (0,1,2)
            ORDER BY f.datec ASC, f.rowid ASC";           
} elseif ($view === 'prepare') {
    $sql = "SELECT w.fk_facture AS rowid
            FROM ".MAIN_DB_PREFIX."depot_work w
            INNER JOIN ".MAIN_DB_PREFIX."facture f ON f.rowid = w.fk_facture
            WHERE w.status = 'prepare'
              AND w.archived = 0
              AND f.entity = ".((int) $conf->entity)."
            ORDER BY w.tms DESC";
} elseif ($view === 'livre') {
    $sql = "SELECT w.fk_facture AS rowid
            FROM ".MAIN_DB_PREFIX."depot_work w
            INNER JOIN ".MAIN_DB_PREFIX."facture f ON f.rowid = w.fk_facture
            WHERE w.status = 'livre'
              AND w.archived = 0
              AND f.entity = ".((int) $conf->entity)."
            ORDER BY w.delivered_on DESC";
} else {
    $sql = "SELECT rowid
            FROM ".MAIN_DB_PREFIX."facture
            WHERE fk_statut IN (0,1,2)
              AND entity = ".((int) $conf->entity)."
            ORDER BY datec DESC";
}

$resql = $db->query($sql);

if ($resql && $db->num_rows($resql) > 0) {

    /*
    * Caches locaux à cet affichage.
    * Ne remplacent pas votre tableau $cache existant.
    */
    $depotSocietesAffichage = array();
    $depotAuteursAffichage = array();

    while ($obj = $db->fetch_object($resql)) {
        $fid = (int) $obj->rowid;
        $facture = new Facture($db);
        if ($facture->fetch($fid) <= 0) continue;

                /*
        * Réinitialisation locale du cache produits/stocks/emplacements
        * pour cette facture.
        *
        * On réutilise volontairement les fonctions existantes et déjà
        * compatibles avec votre affichage, afin d'éviter toute régression.
        */
        if (!empty($facture->lines) && is_array($facture->lines)) {
            foreach ($facture->lines as $depotLine) {
                $depotProductId = (int) $depotLine->fk_product;

                if ($depotProductId <= 0) {
                    continue;
                }

                /*
                * Force le rechargement du stock et de l'emplacement
                * pour les produits de la facture courante.
                */
                unset($cache['stocks'][$depotProductId]);
                unset($cache['locations'][$depotProductId]);

                depotGetProductStockByWarehouse_cached(
                    $db,
                    $depotProductId,
                    $cache
                );

                depotGetDetailedLocation_cached(
                    $db,
                    $depotProductId,
                    $cache
                );
            }
        }

        $work = depotGetWorkRow($db, $fid, $cache);
        if ($work && (int)$work->archived === 1) continue;

        $status = $work ? $work->status : 'a_preparer';
        $invoiceStatus = (int) $facture->statut;

        $isValidated = (
            $invoiceStatus >= 1
            && $invoiceStatus !== 3
        );

        $isProv = ($invoiceStatus === 0);

        if ($view === 'preparation') {
            if ($status === 'livre') continue;
            if ($status === 'prepare') continue;
            if (!($status === 'a_preparer' || $status === 'en_cours')) {
                continue;
            }
            
        } elseif ($view === 'prepare') {
            if ($status !== 'prepare') continue;

        } elseif ($view === 'sans_stock') {
            if ($status !== 'sans_stock') continue;    
        } elseif ($view === 'livre') {
            if ($status !== 'livre') continue;
        } else {
            
        }

                    /*
        * Une seule lecture des restes actifs pour cette facture.
        * En cas d'erreur SQL, la livraison complète reste bloquée.
        */
        $computedRestes = array();
        $hasRestes = false;
        $hasActiveRestes = true;
        $activeRestesReadOk = false;

        $sqlActiveRestes = "SELECT COUNT(*) as nb
                        FROM ".MAIN_DB_PREFIX."depot_restes
                        WHERE fk_facture = ".((int) $fid)."
                            AND resolved = 0
                            AND archived = 0";

        $resActiveRestes = $db->query($sqlActiveRestes);

        if ($resActiveRestes) {
            $objActiveRestes = $db->fetch_object($resActiveRestes);

            if ($objActiveRestes) {
                $hasActiveRestes = ((int) $objActiveRestes->nb > 0);
                $activeRestesReadOk = true;
            }

            $db->free($resActiveRestes);
        }

        /*
        * Conserve votre comportement actuel :
        * - preparation / prepare : calcul des manquants ;
        * - livre : calcul seulement si des restes actifs existent.
        */
        if ($view !== 'livre' || ($activeRestesReadOk && $hasActiveRestes)) {
            $computedRestes = depotComputeRestes($db, $facture, $cache);
            $hasRestes = !empty($computedRestes);
        }

        $canDeliverCompletely = (
            $activeRestesReadOk
            && !$hasActiveRestes
            && !$hasRestes
        );

        /*
        * Une facture avec reste peut quand même être livrée
        * partiellement si une partie du stock est disponible.
        */
        $canDeliverPartially = $activeRestesReadOk;

        $deliveryState = 'none';

        if ($canDeliverCompletely) {
            $deliveryState = 'complete';
        } elseif ($canDeliverPartially) {
            $deliveryState = 'partial';
        }

        /*
        * Calcul du stock total de tous les produits de la facture.
        * Si le total est inférieur ou égal à zéro,
        * le bouton "COMMENCER LA PRÉPARATION" est désactivé.
        */
        $hasProductLines = false;
        $hasAvailableProduct = false;

        if (!empty($facture->lines) && is_array($facture->lines)) {
            foreach ($facture->lines as $line) {
                $productId = (int) $line->fk_product;

                if ($productId <= 0 || (float) $line->qty <= 0) {
                    continue;
                }

                $hasProductLines = true;

                $stockData = depotGetProductStockByWarehouse_cached(
                    $db,
                    $productId,
                    $cache
                );

                if ((float) $stockData['total'] > 0) {
                    $hasAvailableProduct = true;
                }
            }
        }

        $canStartPreparation = (
            $hasProductLines && $hasAvailableProduct
        );
        /*
        * Société : réutilise l'objet si ce tiers a déjà été chargé
        * pour une autre facture de cette page.
        */
        $depotSocId = (int) $facture->socid;

        if (!array_key_exists($depotSocId, $depotSocietesAffichage)) {
            $depotSocObjet = new Societe($db);

            if ($depotSocObjet->fetch($depotSocId) > 0) {
                $depotSocietesAffichage[$depotSocId] = $depotSocObjet;
            } else {
                $depotSocietesAffichage[$depotSocId] = null;
            }
        }

        $soc = $depotSocietesAffichage[$depotSocId];

        /*
        * Garde un objet utilisable par vos affichages $soc->name,
        * même si la fiche tiers n'a pas pu être chargée.
        */
        if ($soc === null) {
            $soc = new stdClass();
            $soc->name = 'Tiers indisponible';
        }

        /*
        * Auteur : réutilise le nom si cet utilisateur a déjà
        * été rencontré sur une autre facture de cette page.
        */
        $depotAuthorId = !empty($facture->fk_user_author)
            ? (int) $facture->fk_user_author
            : 0;

        if (!array_key_exists($depotAuthorId, $depotAuteursAffichage)) {
            $depotAuteursAffichage[$depotAuthorId] =
                depotGetInvoiceAuthorName($db, $facture);
        }

        $invoiceAuthorName = $depotAuteursAffichage[$depotAuthorId];
        if ($view === 'prepare') {
            print '<div class="depot-note">';
            print '<strong style="color:#1457a6; font-size:16px;">Commande préparée</strong>';
            print '<p style="color:#444; margin:5px 0 0 0; font-size:14px;">';
            if ($isValidated) {
                print "La facture est validée, vous pouvez livrer la commande maintenant.";
            } else {
                print "La facture est en attente de validation, livrez quand validée.";
            }
            print '</p></div>';
        }

       $startTs = (!empty($work) && !empty($work->start_time))
        ? strtotime($work->start_time)
        : 0;


        $detailId = 'depot-order-detail-'.((int) $fid);

    
        $isPreparationView = ($view === 'preparation');

        print '<div class="depot-panel" data-depot-card="'.$fid.'" data-depot-start="'.$startTs.'">';

        if ($isPreparationView) {
            print '<div class="depot-order-header">';
            print '<h3>'.dol_escape_htmltag($facture->ref).' | '.dol_escape_htmltag($soc->name).'</h3>';

            print '<button type="button" class="depot-toggle-detail"';
            print ' data-target="'.dol_escape_htmltag($detailId).'"';
            print ' aria-expanded="false">';
            print 'Afficher le détail';
            print '</button>';

            print '</div>';

            /*
            * Tout ce qui suit jusqu'à la fermeture ajoutée plus bas
            * sera caché au départ.
            */
            print '<div id="'.dol_escape_htmltag($detailId).'" class="depot-order-detail is-hidden">';
        } else {
            /*
            * Les vues prepare et livre ne changent pas.
            */
            print '<h3>'.dol_escape_htmltag($facture->ref).' | '.dol_escape_htmltag($soc->name).'</h3>';
        }

            /*
        * Affichage de la date facture avec heure (via datec).
        */
        $dateFactureLabel = depotGetFactureDateLabel($db, $facture);

        print '<div style="margin:-6px 0 10px; color:#666; font-size:13px;">';
        print '<b>Date facture :</b> '.$dateFactureLabel;
        print '</div>';

        if (!empty($invoiceAuthorName)) {
            print '<div style="margin:-8px 0 10px; color:#666; font-size:13px;">';
            print '<b>Créée par :</b> '.dol_escape_htmltag($invoiceAuthorName);
            print '</div>';
        }

        if ($status === 'livre') {
            $dur = (int)($work ? $work->duration : 0);
            $durationTxt = 'Durée de préparation '.depotDurationPretty($dur);

            print "<div class='depot-status-ok' style='display:flex; justify-content:space-between; align-items:center;'>";
            print "<span>✅ LIVRABLE ($durationTxt)</span>";
            print "<form method='POST' class='depot-form' style='margin:0;'>";
            print "<input type='hidden' name='token' value='".newToken()."'>";
            print "<input type='hidden' name='view' value='".dol_escape_htmltag($view)."'>";
            print "<input type='hidden' name='id' value='".$fid."'>";

            if ($deliveryState === 'complete') {
                /*
                * Commande complète :
                * comportement inchangé, archivage dans "Livré".
                */
               if ($deliveryState === 'complete') {
                    print "<button type='submit' name='action' value='archive' class='depot-arch-btn'>";
                    print "Livrer";
                    print "</button>";
                } else {
                    print "<button type='submit' name='action' value='send_to_reste' class='depot-arch-btn'>";
                    print "Reste à livrer";
                    print "</button>";
                }
            } elseif ($deliveryState === 'partial') {
                /*
                * Commande avec reste :
                * le bouton envoie vers "Reste à livrer".
                */
                print "<button type='submit' name='action' value='send_to_reste' class='depot-arch-btn'>";
                print "Reste à livrer";
                print "</button>";
            } else {
                print "<button type='button' class='depot-arch-btn' disabled ";
                print "style='color:#666; background:#ddd; border-color:#ddd; cursor:not-allowed;'>";
                print "Reste à livrer";
                print "</button>";
            }

            print "</form>";
            print "</div>";
        } elseif ($status === 'en_cours') {
            print "<div class='depot-status-warn'>⏳ EN COURS... (⏱ <span class='depot-elapsed'>00:00:00</span>)</div>";
        } elseif ($status === 'prepare') {
            $dur = (int) ($work ? $work->duration : 0);
            $durationTxt = depotDurationPretty($dur);

            print "<div class='depot-status-blue' style='display:flex; justify-content:space-between; align-items:center;'>";

            if ($isValidated && $deliveryState === 'complete') {
                /*
                * Commande complète :
                * comportement inchangé, passage vers "livre".
                */
                print "<form method='POST' class='depot-form' style='margin:0;'>";
                print "<input type='hidden' name='token' value='".newToken()."'>";
                print "<input type='hidden' name='view' value='prepare'>";
                print "<input type='hidden' name='id' value='".$fid."'>";
               if ($deliveryState === 'complete') {
                    print "<button type='submit' name='action' value='deliver' class='depot-form-btn depot-form-btn-success'>";
                    print "Livrable";
                    print "</button>";
                } else {
                    print "<button type='submit' name='action' value='send_to_reste' class='depot-form-btn depot-form-btn-warning'>";
                    print "Reste à livrer";
                    print "</button>";
                }
                    print "</form>";
            } elseif ($isValidated && $deliveryState === 'partial') {
                /*
                * Commande avec reste :
                * le bouton envoie vers "Reste à livrer".
                */
                print "<form method='POST' class='depot-form' style='margin:0;'>";
                print "<input type='hidden' name='token' value='".newToken()."'>";
                print "<input type='hidden' name='view' value='prepare'>";
                print "<input type='hidden' name='id' value='".$fid."'>";
                print "<button type='submit' name='action' value='send_to_reste' class='depot-form-btn depot-form-btn-warning'>";
                print "Reste à livrer";
                print "</button>";
                print "</form>";
            } elseif ($isValidated) {
                print "<span style='color:#b91c1c; font-weight:bold;'>";
                print "⚠️ Reste à livrer";
                print "</span>";
            } else {
                print "<span style='color:#b91c1c; font-weight:bold;'>";
                print "⚠️ En attente de validation";
                print "</span>";
            }

            print "</div>";
        }else {
                            print "<div class='depot-status-muted'>🕒 En attente de préparation</div>";
        }

        print '<table class="depot-table">';
        print '<tr><th>Réf</th><th>Libellé</th><th>Qté</th><th>Stock/Entrepot</th><th>Emplacement</th><th>Etat</th></tr>';

        if (!empty($facture->lines)) {
            foreach ($facture->lines as $line) {
                if (empty($line->fk_product)) continue;

                if (!isset($cache['products'][$line->fk_product])) {
                    $product = new Product($db);
                    $product->fetch($line->fk_product);
                    $cache['products'][$line->fk_product] = $product;
                }
                $product = $cache['products'][$line->fk_product];

                $qty_cmd = (float) $line->qty;
                $stockData = depotGetProductStockByWarehouse_cached($db, $product->id, $cache);
                $totalStock = (float) $stockData['total'];
                $detailedLoc = depotGetDetailedLocation_cached($db, $product->id, $cache);
                $manquant = max(0, $qty_cmd - $totalStock);

                print '<tr>';
                print '<td><a href="'.DOL_URL_ROOT.'/product/card.php?id='.(int)$product->id.'" target="_blank" rel="noopener">'.dol_escape_htmltag($product->ref).'</a></td>';
                print '<td>'.dol_escape_htmltag($product->label).'</td>';
                print '<td align="center">'.dol_escape_htmltag(depotFormatQty($qty_cmd)).'</td>';
                print '<td align="left">';
                if (!empty($stockData['details'])) {
                    foreach ($stockData['details'] as $s) {
                        if ((float) $s['qty'] > 0) {
                            print dol_escape_htmltag($s['warehouse']).': '
                              .depotFormatQty($s['qty']).'<br>';
                        }
                    }
                   print '<strong>Total: '.depotFormatQty($totalStock).'</strong>';
                } else {
                    print 'Aucun stock';
                }
                print '</td>';
                print '<td align="center">'.$detailedLoc.'</td>';
                print '<td align="center">';
                if ($hasRestes && $manquant > 0) {
                    print '⚠️';
                } elseif ($totalStock < $qty_cmd && $status !== 'livre') {
                    print "<span style='color:#e74c3c; font-weight:bold;'>⚠️</span>";
                } else {
                    print '✅';
                }
                print '</td>';
                print '</tr>';
            }
        }
        print '</table>';

       if ($hasRestes) {
            print "<div class='depot-panel' style='border:1px solid #ef4444; background:#fff8f8; margin-top:10px; color:#b91c1c;'>";
            print "⚠️ <b>Produit non disponible :</b><br>";
            foreach ($computedRestes as $r) {
               print "• <b>".dol_escape_htmltag($r['facture_ref'])."</b> | "
                .dol_escape_htmltag($r['ref'])." (".dol_escape_htmltag($r['label']).")"
                ." | Manquant : ".depotFormatQty($r['qty'])."<br>";
            }
            print "</div>";
        }
       if (
        ($view === 'preparation'
            && in_array($status, array('a_preparer', 'en_cours'), true))
        || ($view === 'sans_stock' && $status === 'sans_stock')
    ) {
        print "<form method='POST' class='depot-form'>";
        print "<input type='hidden' name='token' value='".newToken()."'>";
        print "<input type='hidden' name='view' value='".dol_escape_htmltag($view)."'>";
        print "<input type='hidden' name='id' value='".$fid."'>";

        if ($status === 'en_cours') {
            print "<button type='submit' name='action' value='finish' class='depot-form-btn depot-form-btn-success'>";
            print "✅ PRÊT";
            print "</button>";

        } elseif ($canStartPreparation) {
            print "<button type='submit' name='action' value='start' class='depot-form-btn depot-form-btn-primary'>";
            print "▶ COMMENCER LA PRÉPARATION";
            print "</button>";

        } elseif ($view === 'preparation' && $hasProductLines) {
            print "<button type='submit' name='action' value='move_no_stock' class='depot-form-btn'>";
            print "Aucun stock";
            print "</button>";

        } else {
            print "<button type='button' class='depot-form-btn' disabled ";
            print "style='color:#666; background:#ddd; border-color:#ddd; cursor:not-allowed;'>";
            print "En attente de stock";
            print "</button>";
        }

        print '</form>';
    }

/*
 * Ferme seulement la zone de détail cachée en vue preparation.
 */
if ($isPreparationView) {
    print '</div>'; // ferme .depot-order-detail
}

print '</div>'; // ferme .depot-panel
    }
} else {
    if($view === 'preparation') {
      print '<p>Aucune commande à préparer.</p>';
    } elseif($view === 'prepare'){
        print '<p>Aucune commande n\'a été préparée.</p>';
    } elseif($view === 'livre'){
        print '<p>Aucune commande ni prête ni livrable.</p>';
   } elseif ($view === 'sans_stock') {
    print '<p>Aucune commande en attente de stock.</p>';
    
   }
}

llxFooter();
?>

