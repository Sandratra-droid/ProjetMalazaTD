<?php
/* Copyright (C) 2004-2018  Laurent Destailleur          <eldy@users.sourceforge.net>
 * Copyright (C) 2018-2019  Nicolas ZABOURI             <info@inovea-conseil.com>
 * Copyright (C) 2019-2024  Frédéric France             <frederic.france@free.fr>
 * Copyright (C) 2026       SuperAdmin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 */


include_once DOL_DOCUMENT_ROOT.'/core/modules/DolibarrModules.class.php';

class modDepot extends DolibarrModules
{
    public function __construct($db)
    {
        global $conf, $langs;

        $this->db = $db;
        $this->numero = 500000;
        $this->rights_class = 'depot';
        $this->family = "other";
        $this->module_position = '90';
        $this->name = preg_replace('/^mod/i', '', get_class($this));
        $this->description = "DepotDescription";
        $this->descriptionlong = "DepotDescription";
        $this->editor_name = 'Malaza-TD Test';
        $this->editor_url = '';
        $this->editor_squarred_logo = '';
        $this->version = '1.0';
        $this->const_name = 'MAIN_MODULE_'.strtoupper($this->name);
        $this->picto = 'fa-file';

        $this->tables = array(
            MAIN_DB_PREFIX.'depot_work',
            MAIN_DB_PREFIX.'depot_restes',
            MAIN_DB_PREFIX.'depot_livraisons_lignes',
            MAIN_DB_PREFIX.'depot_livraisons',
        );
        $this->module_parts = array(
            'triggers' => 0,
            'login' => 0,
            'substitutions' => 0,
            'menus' => 0,
            'tpl' => 0,
            'barcode' => 0,
            'models' => 0,
            'printing' => 0,
            'theme' => 0,
            'css' => array(),
            'js' => array(),
            'hooks' => array(),
            'moduleforexternal' => 0,
            'websitetemplates' => 0,
            'captcha' => 0
        );

        $this->dirs = array("/depot/temp");
        $this->config_page_url = array("setup.php@depot");
        $this->hidden = getDolGlobalInt('MODULE_DEPOT_DISABLED');
        $this->depends = array();
        $this->requiredby = array();
        $this->conflictwith = array();
        $this->langfiles = array("depot@depot");
        $this->phpmin = array(7, 2);
        $this->need_dolibarr_version = array(19, -3);
        $this->need_javascript_ajax = 0;
        $this->warnings_activation = array();
        $this->warnings_activation_ext = array();

        if (!isModEnabled("depot")) {
            $conf->depot = new stdClass();
            $conf->depot->enabled = 0;
        }

        $this->tabs = array();
        $this->dictionaries = array();
        $this->boxes = array();
        $this->cronjobs = array();

        $this->rights = array();
        $r = 0;

        $this->menu = array();
        $r = 0;

        // TOP MENU : Bouton "Depot" dans le menu haut
        $this->menu[$r++] = array(
            'fk_menu' => '',
            'type' => 'top',
            'titre' => 'Préparation',
            'prefix' => img_picto('', 'fa-clipboard', 'class="paddingright pictofixedwidth valignmiddle"'),
            'mainmenu' => 'depot',
            'leftmenu' => '',
            'url' => '/custom/depot/depotindex.php?view=preparation',
            'langs' => 'depot@depot',
            'position' => 1000 + $r,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => '',
            'target' => '',
            'user' => 2,
        );

                // LEFT MENU : En préparation
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'En préparation',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_preparation',
            'url' => '/custom/depot/depotindex.php?view=preparation',
            'langs' => 'depot@depot',
            'position' => 1001,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-clock-o',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Prêt non livré
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Prét non livrable',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_prepare',
            'url' => '/custom/depot/depotindex.php?view=prepare',
            'langs' => 'depot@depot',
            'position' => 1002,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-check',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Livrable & Facturé
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Pret & livrable',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_livre',
            'url' => '/custom/depot/depotindex.php?view=livre',
            'langs' => 'depot@depot',
            'position' => 1003,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-truck',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Livrés
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Livré',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_archives',
            'url' => '/custom/depot/depotindex.php?view=archives',
            'langs' => 'depot@depot',
            'position' => 1004,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-archive',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Reste à livrer
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Reste à livrer',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_reste',
            'url' => '/custom/depot/depotindex.php?view=reste',
            'langs' => 'depot@depot',
            'position' => 1005,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-exclamation-triangle',
            'target' => '',
            'user' => 2,
        );

                // LEFT MENU : Aucun stock
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Aucun Stock',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_sans_stock',
            'url' => '/custom/depot/depotindex.php?view=sans_stock',
            'langs' => 'depot@depot',
            'position' => 1006,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-clock-o',
            'target' => '',
            'user' => 2,
        );
    }

    public function init($options = '')
    {
        /*
        * Création/contrôle des tables SQL du module :
        * custom/depot/sql/
        */
        $result = $this->_load_tables('/depot/sql/');
        if ($result < 0) {
            return -1;
        }

        /*
        * Logique existante du module.
        * Votre méthode remove() actuelle ne contient pas de SQL de suppression.
        */
        $this->remove($options);

        $sql = array();

        /*
        * ============================================================
        * CREATION AUTOMATIQUE DES EXTRAFIELDS D'EMPLACEMENT PRODUIT
        * ============================================================
        *
        * Ces champs sont créés à l'activation du module Depot :
        *
        * - salle_depot  : Salle dépôt
        * - etagere      : Étagère
        * - localisation : Localisation
        *
        * Ils sont attachés à l'objet Dolibarr "product".
        *
        * Ils ne sont pas recréés s'ils existent déjà :
        * aucune duplication et aucune suppression de valeurs existantes.
        */
        require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';

        $extrafields = new ExtraFields($this->db);

        /*
        * Chargement des extrafields déjà existants pour Produits/Services.
        */
        $extrafields->fetch_name_optionals_label('product');

        /*
        * 1. Salle dépôt
        * Stockage dans llx_product_extrafields.salle_depot
        */
        if (empty($extrafields->attributes['product']['label']['salle_depot'])) {
            $result = $extrafields->addExtraField(
                'salle_depot',
                'Salle dépôt',
                'varchar',
                100,
                255,
                'product',
                0,
                0,
                '',
                '',
                1,
                '',
                0,
                0,
                '',
                '',
                '',
                0,
                0
            );

            if ($result < 0) {
                $this->error = $extrafields->error;
                return -1;
            }
        }

        /*
        * 2. Étagère
        * Stockage dans llx_product_extrafields.etagere
        */
        if (empty($extrafields->attributes['product']['label']['etagere'])) {
            $result = $extrafields->addExtraField(
                'etagere',
                'Étagère',
                'varchar',
                101,
                255,
                'product',
                0,
                0,
                '',
                '',
                1,
                '',
                0,
                0,
                '',
                '',
                '',
                0,
                0
            );

            if ($result < 0) {
                $this->error = $extrafields->error;
                return -1;
            }
        }

        /*
        * 3. Localisation
        * Stockage dans llx_product_extrafields.localisation
        */
        if (empty($extrafields->attributes['product']['label']['localisation'])) {
            $result = $extrafields->addExtraField(
                'localisation',
                'Localisation',
                'varchar',
                102,
                255,
                'product',
                0,
                0,
                '',
                '',
                1,
                '',
                0,
                0,
                '',
                '',
                '',
                0,
                0
            );

            if ($result < 0) {
                $this->error = $extrafields->error;
                return -1;
            }
        }

        /*
        * Partie d'origine générée par ModuleBuilder :
        * elle est conservée sans changement.
        */
        $moduledir = dol_sanitizeFileName('depot');

        $myTmpObjects = array();
        $myTmpObjects['MyObject'] = array(
            'includerefgeneration' => 0,
            'includedocgeneration' => 0
        );

        foreach ($myTmpObjects as $myTmpObjectKey => $myTmpObjectArray) {
            if ($myTmpObjectArray['includerefgeneration']) {
                $src = DOL_DOCUMENT_ROOT.'/install/doctemplates/'.$moduledir.'/template_myobjects.odt';
                $dirodt = DOL_DATA_ROOT.($conf->entity > 1 ? '/'.$conf->entity : '').'/doctemplates/'.$moduledir;
                $dest = $dirodt.'/template_myobjects.odt';

                if (file_exists($src) && !file_exists($dest)) {
                    require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

                    dol_mkdir($dirodt);
                    $result = dol_copy($src, $dest, '0', 0);

                    if ($result < 0) {
                        $langs->load("errors");
                        $this->error = $langs->trans('ErrorFailToCopyFile', $src, $dest);
                        return 0;
                    }
                }

                $sql = array_merge($sql, array(
                    '/depot/sql/llx_depot.sql',

                    "DELETE FROM ".$this->db->prefix()."document_model
                    WHERE nom = 'standard_".strtolower($myTmpObjectKey)."'
                    AND type = '".$this->db->escape(strtolower($myTmpObjectKey))."'
                    AND entity = ".((int) $conf->entity),

                    "INSERT INTO ".$this->db->prefix()."document_model
                    (nom, type, entity)
                    VALUES(
                        'standard_".strtolower($myTmpObjectKey)."',
                        '".$this->db->escape(strtolower($myTmpObjectKey))."',
                        ".((int) $conf->entity)."
                    )",

                    "DELETE FROM ".$this->db->prefix()."document_model
                    WHERE nom = 'generic_".strtolower($myTmpObjectKey)."_odt'
                    AND type = '".$this->db->escape(strtolower($myTmpObjectKey))."'
                    AND entity = ".((int) $conf->entity),

                    "INSERT INTO ".$this->db->prefix()."document_model
                    (nom, type, entity)
                    VALUES(
                        'generic_".strtolower($myTmpObjectKey)."_odt',
                        '".$this->db->escape(strtolower($myTmpObjectKey))."',
                        ".((int) $conf->entity)."
                    )"
                ));
            }
        }

        return $this->_init($sql, $options);
    }

    public function remove($options = '')
    {
        $sql = array();
        return $this->_remove($sql, $options);
    }
}
?>