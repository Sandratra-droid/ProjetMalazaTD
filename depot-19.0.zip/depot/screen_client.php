<?php
// custom/depot/screen_client.php
// Écran public : état de préparation des commandes (module Dépôt)
// N'affiche que les commandes du jour (date du jour)
// Les lignes "Livré" disparaissent après 35 secondes et ne réapparaissent plus


// Charger Dolibarr
require_once '../../main.inc.php';


// Date du jour au format SQL
$today = date('Y-m-d');

// Message d'accueil configurable depuis les paramètres du module Dépôt
$screenClientMessage = getDolGlobalString('DEPOT_SCREEN_CLIENT_MESSAGE');

if (empty(trim($screenClientMessage))) {
    $screenClientMessage = 'Veuillez optimiser l’état de préparation de vos commandes';
}

// On affiche :
// - a_preparer, en_cours, prepare : normalement si date_creation = aujourd'hui
// - livre : uniquement si la ligne a été mise à jour il y a moins de 35 secondes
$sql = "SELECT w.rowid,
               w.fk_facture,
               w.status,
               w.archived,
               w.date_creation,
               w.start_time,
               w.tms,
               f.ref AS facture_ref,
               s.nom AS societe_nom
        FROM ".MAIN_DB_PREFIX."depot_work AS w
        LEFT JOIN ".MAIN_DB_PREFIX."facture AS f ON f.rowid = w.fk_facture
        LEFT JOIN ".MAIN_DB_PREFIX."societe AS s ON s.rowid = f.fk_soc
        WHERE w.archived = 0
          AND w.status IN ('a_preparer','en_cours','prepare','livre')
          AND DATE(w.date_creation) = '".$db->escape($today)."'
          AND (
                w.status <> 'livre'
                OR (w.status = 'livre' AND w.tms >= DATE_SUB(NOW(), INTERVAL 35 SECOND))
              )
        ORDER BY w.date_creation DESC";


// print '<!-- SQL : '.$sql.' -->';


$resql = $db->query($sql);


if (!$resql) {
    print "Erreur SQL : ".$db->lasterror();
    exit;
}


$works = array();

while ($obj = $db->fetch_object($resql)) {
    $works[] = $obj;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>État de préparation des commandes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 0;
            width: 100%;
            overflow-x: hidden;
        }

        .screen-wrap {
            width: 100%;
            max-width: none;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-size: 28px;
        }

        .commande {
            width: 100%;
            box-sizing: border-box;
            border-radius: 6px;
            padding: 15px 20px;
            margin: 0 0 15px 0;
            font-size: 20px;
            transition: opacity 0.5s ease, transform 0.5s ease;
            border: 1px solid #ddd;
            background: #fff;
        }

        /* Couleurs de fond selon l'état */
        .commande-a_preparer,
        .commande-en_cours {
            background: #fef3c7;
            border-color: #f59e0b;
        }

        .commande-prepare {
            background: #dcfce7;
            border-color: #22c55e;
        }

        .commande-livre {
            background: #bbf7d0;
            border-color: #16a34a;
        }

        .commande-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .ref-client {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .ref {
            font-weight: bold;
            font-size: 22px;
            color: #222;
        }

        .client {
            color: #555;
            font-size: 16px;
        }

        /* Badge d'état */
        .status {
            padding: 8px 14px;
            border-radius: 4px;
            color: #fff;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 15px;
            min-width: 140px;
            text-align: center;
        }

        /* Couleurs du badge selon l'état */
        .status-a_preparer,
        .status-en_cours {
            background: #f59e0b;
        }

        .status-prepare {
            background: #22c55e;
        }

        .status-livre {
            background: #16a34a;
        }

        .no-commande {
            text-align: center;
            color: #777;
            font-size: 18px;
            padding: 40px;
        }

        /* Classe pour faire disparaître en douceur */
        .fade-out {
            opacity: 0;
            transform: translateY(-10px);
            pointer-events: none;
        }

        /* Bandeau de texte défilant */
        .marquee-wrap {
            overflow: hidden;
            white-space: nowrap;
            border-radius: 6px;
            margin-bottom: 30px;
            padding: 10px 0;
            background: #1f2937;
        }

        .marquee-text {
            display: inline-block;
            padding-left: 100%;
            color: #facc15;
            font-size: 22px;
            font-weight: bold;
            animation: marquee 20s linear infinite;
        }
        
        .screen-topbar {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            margin-bottom: 10px;
        }

        .btn-retour-preparation {
            display: inline-block;
            padding: 9px 14px;
            border: 1px solid #1f2937;
            border-radius: 5px;
            background: #1f2937;
            color: #fff;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            transition: background 0.2s ease, border-color 0.2s ease;
        }

        .btn-retour-preparation:hover {
            background: #374151;
            border-color: #374151;
            color: #fff;
        }
        @keyframes marquee {
            0% {
                transform: translateX(0%);
            }

            100% {
                transform: translateX(-100%);
            }
        }
    </style>

    <!-- Actualisation silencieuse de l'état des commandes -->
    <script>
        (function() {
            var screenUrl = window.location.href;
            var refreshDelay = 1000;
            var refreshInProgress = false;

            function actualiserCommandes() {
                if (refreshInProgress) {
                    return;
                }

                refreshInProgress = true;

                fetch(screenUrl, {
                    method: 'GET',
                    cache: 'no-store',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('Erreur HTTP');
                    }

                    return response.text();
                })
                .then(function(html) {
                    var parser = new DOMParser();
                    var nouveauDocument = parser.parseFromString(html, 'text/html');

                    var nouvelleZone = nouveauDocument.querySelector('#commandes-zone');
                    var zoneActuelle = document.querySelector('#commandes-zone');

                    if (nouvelleZone && zoneActuelle) {
                        zoneActuelle.innerHTML = nouvelleZone.innerHTML;
                        initialiserCommandesLivrees();
                    }
                })
                .catch(function(error) {
                    console.log('Actualisation écran client impossible :', error);
                })
                .finally(function() {
                    refreshInProgress = false;

                    setTimeout(function() {
                        actualiserCommandes();
                    }, refreshDelay);
                });
            }

            function faireDisparaitre(row) {
                if (!row || !row.parentNode) {
                    return;
                }

                row.classList.add('fade-out');

                setTimeout(function() {
                    if (row && row.parentNode) {
                        row.remove();
                    }
                }, 600);
            }

            function initialiserCommandesLivrees() {
                document.querySelectorAll('#commandes-zone .commande[data-status="livre"]').forEach(function(row) {
                    var tms = parseInt(row.getAttribute('data-tms'), 10);

                    if (!tms) {
                        return;
                    }

                    var tempsEcoule = Date.now() - (tms * 1000);
                    var tempsRestant = 35000 - tempsEcoule;

                    if (tempsRestant <= 0) {
                        faireDisparaitre(row);
                        return;
                    }

                    setTimeout(function() {
                        faireDisparaitre(row);
                    }, tempsRestant);
                });
            }

            document.addEventListener('DOMContentLoaded', function() {
                initialiserCommandesLivrees();

                setTimeout(function() {
                    actualiserCommandes();
                }, refreshDelay);
            });
        })();
    </script>
</head>

<body>

<div class="screen-wrap">

    <div class="marquee-wrap">
        <a href="depotindex.php?view=preparation" class="btn-retour-preparation">
            ← Retour
        </a>

        <div class="marquee-text">
            <?php echo dol_escape_htmltag($screenClientMessage); ?>
        </div>
    </div>

    <div id="commandes-zone">
        <?php if (empty($works)): ?>

            <div class="no-commande">
                Aucune commande en préparation.
            </div>

        <?php else: ?>

            <?php foreach ($works as $w): ?>
                <?php
                    // Classe CSS selon le statut
                    $classe_statut = 'commande-' . $w->status;

                    // Timestamp de la dernière modification
                    $timestamp_modification = !empty($w->tms)
                        ? strtotime($w->tms)
                        : 0;
                ?>

                <div
                    class="commande <?php echo dol_escape_htmltag($classe_statut); ?>"
                    data-status="<?php echo dol_escape_htmltag($w->status); ?>"
                    data-tms="<?php echo (int) $timestamp_modification; ?>"
                >
                    <div class="commande-inner">
                        <div class="ref-client">
                            <div class="ref">
                                <?php echo dol_escape_htmltag($w->facture_ref); ?>
                            </div>

                            <?php if (!empty($w->societe_nom)): ?>
                                <div class="client">
                                    <?php echo dol_escape_htmltag($w->societe_nom); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="status status-<?php echo dol_escape_htmltag($w->status); ?>">
                            <?php
                            switch ($w->status) {
                                case 'a_preparer':
                                case 'en_cours':
                                    echo 'En cours...';
                                    break;

                                case 'prepare':
                                    echo 'Prêt';
                                    break;

                                case 'livre':
                                    echo 'Livré';
                                    break;

                                default:
                                    echo dol_escape_htmltag($w->status);
                            }
                            ?>
                        </div>
                    </div>
                </div>

            <?php endforeach; ?>

        <?php endif; ?>
    </div>
</div>

</body>
</html>