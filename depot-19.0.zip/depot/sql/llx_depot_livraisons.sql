CREATE TABLE llx_depot_livraisons (
    rowid INTEGER AUTO_INCREMENT PRIMARY KEY,
    fk_facture INTEGER NOT NULL,
    telephone VARCHAR(50) NULL,
    note TEXT NULL,
    date_prevue_livraison DATE NULL,
    date_creation DATETIME NOT NULL,
    tms TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_depot_livraisons_facture (fk_facture),
    KEY idx_depot_livraisons_facture (fk_facture)
) ENGINE=innodb;