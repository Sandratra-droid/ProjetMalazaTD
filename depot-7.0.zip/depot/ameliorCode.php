<?php
ini_set('display_errors', 0);
error_reporting(0);

require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';

if (!$user->id) accessforbidden();

$action = GETPOST('action', 'alpha');
$id = GETPOST('id', 'int');
$view = GETPOST('view', 'alpha');
if (empty($view)) $view = 'preparation';
$phpSelf = $_SERVER['PHP_SELF'];
$tranche = GETPOST('tranche', 'alpha');

$cache = array();
$cache['stocks'] = array();
$cache['locations'] = array();
$cache['works'] = array();
$cache['products'] = array();

function depotDurationPretty($sec) {
    $sec = (int) $sec;
    $h = floor($sec / 3600);
    $m = floor(($sec % 3600) / 60);
    $s = $sec % 60;
    if ($h > 0) return $h.'h '.$m.'min '.$s.'s';
    if ($m > 0) return $m.'min '.$s.'s';
    return $s.'s';
}

function depotGetWorkRow($db, $fid, &$cache) {
    if (isset($cache['works'][$fid])) {
        return $cache['works'][$fid];
    }

    $sql = "SELECT * FROM ".MAIN_DB_PREFIX."depot_work WHERE fk_facture = ".((int) $fid)."";
    $res = $db->query($sql);
    if ($res && ($obj = $db->fetch_object($res))) {
        $cache['works'][$fid] = $obj;
        return $obj;
    }
    return null;
}

function depotUpsertWorkRow($db, $fid, $fields = array()) {
    $check_sql = "SELECT * FROM ".MAIN_DB_PREFIX."depot_work WHERE fk_facture = ".((int)$fid)."";
    $check_res = $db->query($check_sql);
    $existing = ($check_res && ($obj = $db->fetch_object($check_res)));

    if ($existing && empty($fields['status'])) {
        $fields['status'] = $obj->status;
    }
    if ($existing && empty($fields['duration'])) {
        $fields['duration'] = $obj->duration;
    }

    $status = $fields['status'] ?? 'a_preparer';
    $start_time = !empty($fields['start_time']) ? "'".$db->idate($fields['start_time'])."'" : "NULL";
    $finish_time = !empty($fields['finish_time']) ? "'".$db->idate($fields['finish_time'])."'" : "NULL";
    $validated_on = !empty($fields['validated_on']) ? "'".$db->idate($fields['validated_on'])."'" : "NULL";
    $delivered_on = !empty($fields['delivered_on']) ? "'".$db->idate($fields['delivered_on'])."'" : "NULL";
    $duration = (int)($fields['duration'] ?? 0);
    $archived = !empty($fields['archived']) ? 1 : 0;
    $archived_on = !empty($fields['archived_on']) ? "'".$db->idate($fields['archived_on'])."'" : "NULL";

    if ($existing) {
        $sql = "UPDATE ".MAIN_DB_PREFIX."depot_work SET
            status = '".$db->escape($status)."',
            start_time = $start_time,
            finish_time = $finish_time,
            duration = ".$duration.",
            validated_on = $validated_on,
            delivered_on = $delivered_on,
            archived = ".$archived.",
            archived_on = $archived_on,
            tms = NOW()
            WHERE fk_facture = ".((int)$fid);
    } else {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_work
            (fk_facture, status, start_time, finish_time, duration, validated_on, delivered_on, archived, archived_on, date_creation, tms)
            VALUES
            (".((int)$fid).", '".$db->escape($status)."', $start_time, $finish_time, ".$duration.", $validated_on, $delivered_on, ".$archived.", $archived_on, NOW(), NOW())";
    }

    return $db->query($sql);
}

function depotBatchLoadStocks($db, $ids, &$cache) {
    if (empty($ids)) return;

    $sql = "SELECT ps.fk_product, ps.reel, e.ref as warehouse_ref
            FROM ".MAIN_DB_PREFIX."product_stock ps
            LEFT JOIN ".MAIN_DB_PREFIX."entrepot e ON e.rowid = ps.fk_entrepot
            WHERE ps.fk_product IN (" . implode(',', array_map('intval', $ids)) . ")
            ORDER BY ps.fk_product ASC, e.ref ASC";
    $res = $db->query($sql);

    while ($obj = $db->fetch_object($res)) {
        $cache['stocks'][$obj->fk_product][] = array(
            'warehouse' => !empty($obj->warehouse_ref) ? $obj->warehouse_ref : 'N/A',
            'qty' => (float) $obj->reel,
        );
    }
}

function depotBatchLoadLocations($db, $ids, &$cache) {
    if (empty($ids)) return;

    $sql = "SELECT fk_object, salle_depot, etagere, localisation
            FROM ".MAIN_DB_PREFIX."product_extrafields
            WHERE fk_object IN (" . implode(',', array_map('intval', $ids)) . ")";
    $res = $db->query($sql);

    while ($obj = $db->fetch_object($res)) {
        $cache['locations'][$obj->fk_object] = array(
            'salle_depot' => !empty($obj->salle_depot) ? $obj->salle_depot : '',
            'etagere' => !empty($obj->etagere) ? $obj->etagere : '',
            'localisation' => !empty($obj->localisation) ? $obj->localisation : '',
        );
    }
}

function depotGetProductStockByWarehouse_cached($db, $fk_product, &$cache) {
    if (isset($cache['stocks'][$fk_product])) {
        $stocks = $cache['stocks'][$fk_product];
        $total = 0;
        foreach ($stocks as $s) $total += $s['qty'];
        return array('total' => $total, 'details' => $stocks);
    }

    $stocks = array();
    $total = 0;
    $sql = "SELECT ps.reel, e.ref as warehouse_ref
            FROM ".MAIN_DB_PREFIX."product_stock ps
            LEFT JOIN ".MAIN_DB_PREFIX."entrepot e ON e.rowid = ps.fk_entrepot
            WHERE ps.fk_product = ".((int) $fk_product)."
            ORDER BY e.ref ASC";
    $res = $db->query($sql);
    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $qty = (float) $obj->reel;
            $total += $qty;
            $stocks[] = array(
                'warehouse' => !empty($obj->warehouse_ref) ? $obj->warehouse_ref : 'N/A',
                'qty' => $qty,
            );
        }
        $cache['stocks'][$fk_product] = $stocks;
    }
    return array('total' => $total, 'details' => $stocks);
}

function depotGetDetailedLocation_cached($db, $fk_product, &$cache) {
    if (isset($cache['locations'][$fk_product])) {
        $loc = $cache['locations'][$fk_product];
        $parts = array();
        if (!empty($loc['salle_depot'])) $parts[] = 'Salle: '.dol_escape_htmltag($loc['salle_depot']);
        if (!empty($loc['etagere'])) $parts[] = 'Étagère: '.dol_escape_htmltag($loc['etagere']);
        if (!empty($loc['localisation'])) $parts[] = 'Localisation: '.dol_escape_htmltag($loc['localisation']);
        return implode('<br>', $parts);
    }

    $salle = '';
    $etagere = '';
    $localisation = '';
    $sql2 = 'SELECT salle_depot, etagere, localisation
             FROM '.MAIN_DB_PREFIX.'product_extrafields
             WHERE fk_object = '.((int) $fk_product).'
             LIMIT 1';
    $res2 = $db->query($sql2);
    if ($res2 && $db->num_rows($res2) > 0) {
        $tmp2 = $db->fetch_object($res2);
        if ($tmp2) {
            $salle = !empty($tmp2->salle_depot) ? $tmp2->salle_depot : '';
            $etagere = !empty($tmp2->etagere) ? $tmp2->etagere : '';
            $localisation = !empty($tmp2->localisation) ? $tmp2->localisation : '';
        }
    }
    $parts = array();
    if (!empty($salle)) $parts[] = 'Salle: '.dol_escape_htmltag($salle);
    if (!empty($etagere)) $parts[] = 'Étagère: '.dol_escape_htmltag($etagere);
    if (!empty($localisation)) $parts[] = 'Localisation: '.dol_escape_htmltag($localisation);
    return implode('<br>', $parts);
}

function depotComputeRestes($db, $facture, &$cache) {
    $restes = array();
    if (empty($facture->lines) || !is_array($facture->lines)) return $restes;

    foreach ($facture->lines as $line) {
        if (empty($line->fk_product)) continue;
        $stockData = depotGetProductStockByWarehouse_cached($db, (int) $line->fk_product, $cache);
        $totalStock = (float) $stockData['total'];
        $qty_cmd = (float) $line->qty;

        if ($qty_cmd > $totalStock) {
            if (!isset($cache['products'][$line->fk_product])) {
                $product = new Product($db);
                if ($product->fetch($line->fk_product) <= 0) continue;
                $cache['products'][$line->fk_product] = $product;
            }
            $product = $cache['products'][$line->fk_product];

            $restes[] = array(
                'fk_product' => (int) $product->id,
                'facture_ref' => $facture->ref,
                'ref' => $product->ref,
                'label' => $product->label,
                'qty' => max(0, $qty_cmd - $totalStock),
            );
        }
    }
    return $restes;
}

function depotSyncRestes($db, $fid, $facture, &$cache) {
    $work = depotGetWorkRow($db, $fid, $cache);
    if (!$work) return false;
    $work_id = (int) $work->rowid;

    $sql = "UPDATE ".MAIN_DB_PREFIX."depot_restes SET archived = 1, archived_on = NOW() WHERE fk_depot_work = ".((int)$work_id)." AND resolved = 0";
    $db->query($sql);

    $restes = depotComputeRestes($db, $facture, $cache);
    foreach ($restes as $r) {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_restes
            (fk_depot_work, fk_facture, fk_product, facture_ref, product_ref, product_label, qty_manquante, detected_on, resolved, archived)
            VALUES
            (".$work_id.", ".((int)$fid).", ".((int)$r['fk_product']).", '".$db->escape($r['facture_ref'])."', '".$db->escape($r['ref'])."', '".$db->escape($r['label'])."', ".((float)$r['qty']).", NOW(), 0, 0)
            ON DUPLICATE KEY UPDATE
            qty_manquante = VALUES(qty_manquante),
            archived = 0,
            archived_on = NULL";
        $db->query($sql);
    }
    return true;
}

function depotGetRestes($db, $work_id) {
    $sql = "SELECT * FROM ".MAIN_DB_PREFIX."depot_restes WHERE fk_depot_work = ".((int)$work_id)." AND resolved = 0 AND archived = 0 ORDER BY detected_on DESC";
    $restes = array();
    $res = $db->query($sql);
    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $restes[] = array(
                'fk_product' => (int) $obj->fk_product,
                'facture_ref' => $obj->facture_ref,
                'ref' => $obj->product_ref,
                'label' => $obj->product_label,
                'qty' => $obj->qty_manquante,
                'time' => date('H:i', strtotime($obj->detected_on)),
            );
        }
    }
    return $restes;
}

function depotCheckProductStock($db, $fk_product, $qty_needed, &$cache) {
    $stockData = depotGetProductStockByWarehouse_cached($db, $fk_product, $cache);
    return ((float) $stockData['total'] >= (float) $qty_needed);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['token'])) accessforbidden();

    if ($id > 0) {
        $facture = new Facture($db);
        $facture->fetch($id);
        $is_validated = ((int) $facture->statut === 1);

        if ($action === 'start') {
            depotUpsertWorkRow($db, $id, array(
                'status' => 'en_cours',
                'start_time' => time(),
                'validated_on' => $is_validated ? time() : null,
            ));
        } elseif ($action === 'finish') {
            $work = depotGetWorkRow($db, $id, $cache);
            $start = !empty($work->start_time) ? strtotime($work->start_time) : time();
            $duration = time() - $start;

            if ($is_validated) {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'livre',
                    'duration' => $duration,
                    'finish_time' => time(),
                    'delivered_on' => time(),
                    'validated_on' => $work->validated_on ?? null,
                ));
            } else {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'prepare',
                    'duration' => $duration,
                    'finish_time' => time(),
                    'validated_on' => $work->validated_on ?? null,
                ));
            }

            depotSyncRestes($db, $id, $facture, $cache);
        } elseif ($action === 'deliver') {
            $work = depotGetWorkRow($db, $id, $cache);
            depotUpsertWorkRow($db, $id, array(
                'status' => 'livre',
                'duration' => (int)($work->duration ?? 0),
                'finish_time' => time(),
                'delivered_on' => time(),
            ));
            depotSyncRestes($db, $id, $facture, $cache);
        } elseif ($action === 'archive') {
            $work = depotGetWorkRow($db, $id, $cache);
            $current_status = $work ? $work->status : 'a_preparer';

            depotUpsertWorkRow($db, $id, array(
                'status' => $current_status,
                'archived' => 1,
                'archived_on' => time(),
            ));
        }

        header('Location: '.$phpSelf.'?view='.$view);
        exit;
    }
}

llxHeader('', 'Espace Responsable Dépôt');

print '<style>
.depot-page{margin-top:20px;font-family:Arial,Helvetica,sans-serif;color:#333}
.depot-toolbar{padding:12px 14px;background:#f8f9fa;border:1px solid #ddd;border-radius:8px;display:flex;justify-content:space-between;align-items:center;gap:12px}
.depot-title{margin:0;font-size:20px}
.depot-btn{padding:10px 14px;border:0;border-radius:6px;font-weight:700;cursor:pointer}
.depot-btn-primary{background:#3498db;color:#fff}
.depot-btn-success{background:#27ae60;color:#fff}
.depot-btn-muted{background:#ccc;color:#666;cursor:not-allowed}
.depot-card{border:1px solid #d9dee4;padding:15px;margin-bottom:20px;border-radius:10px;background:#fff}
.depot-card h3{margin-top:0}
.depot-info{background:#e3f2fd;border:1px solid #90caf9;padding:15px;margin-bottom:20px;border-radius:8px}
.depot-info strong{color:#1565c0;font-size:16px}
.depot-table{width:100%;border-collapse:collapse;background:#fff}
.depot-table th,.depot-table td{border:1px solid #e6e6e6;padding:8px;vertical-align:top}
.depot-table th{background:#ecf0f1}
.depot-status-ok{background:#27ae60;color:#fff;padding:10px;border-radius:5px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:10px}
.depot-status-warn{background:#f39c12;color:#fff;padding:10px;border-radius:5px;margin-bottom:10px}
.depot-status-blue{background:#3498db;color:#fff;padding:10px;border-radius:5px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:10px}
.depot-status-gray{background:#ecf0f1;color:#333;padding:10px;border-radius:5px;margin-bottom:10px}
.depot-block-danger{color:#b91c1c;margin-top:10px;border:1px solid #ef4444;padding:10px;background:#fef2f2;border-radius:8px}
.depot-restes-card{background:#fff;padding:15px;margin-bottom:15px;border-radius:8px;border:2px solid #e74c3c}
.depot-restes-item{background:#fef2f2;padding:10px;margin-bottom:8px;border-radius:5px;border-left:4px solid #e74c3c}
.depot-filter{margin:0 0 20px 0;padding:12px;background:#f8f9fa;border:1px solid #ddd;border-radius:8px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.depot-archive-table{border-collapse:collapse;background:#fff}
.depot-archive-table th,.depot-archive-table td{border:1px solid #ddd;padding:8px}
.depot-pill-green{font-weight:700;color:#27ae60}
</style>';

$sql_check = "SELECT count(rowid) as nb FROM ".MAIN_DB_PREFIX."facture WHERE fk_statut IN (0,1) AND entity = ".((int) $conf->entity);
$res_check = $db->query($sql_check);
$nb_actuel = 0;
if ($res_check && ($obj_check = $db->fetch_object($res_check))) {
    $nb_actuel = (int) $obj_check->nb;
}

print '<script>
let currentCount = '.$nb_actuel.';
let lastCount = localStorage.getItem("last_depot_count") || 0;
localStorage.setItem("last_depot_count", currentCount);
setTimeout(function(){ location.reload(); }, 300000);

function depotFormatHMS(sec) {
    sec = Math.max(0, Math.floor(sec));
    let h = Math.floor(sec / 3600);
    let m = Math.floor((sec % 3600) / 60);
    let s = sec % 60;
    return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
}

function depotStartTimers() {
    document.querySelectorAll("[data-depot-start]").forEach(function(el) {
        let start = parseInt(el.getAttribute("data-depot-start"), 10);
        let target = el.querySelector(".depot-elapsed");
        if (!start || !target) return;
        function tick() {
            target.textContent = depotFormatHMS((Date.now() - (start * 1000)) / 1000);
        }
        tick();
        setInterval(tick, 1000);
    });
}
document.addEventListener("DOMContentLoaded", depotStartTimers);
</script>';

print '<div class="depot-page">';
print '<div class="depot-toolbar">';
print '<h2 class="depot-title">📦 Gestion de commande</h2>';
print '<button onclick="location.reload()" class="depot-btn depot-btn-primary">🔄 Actualiser</button>';
print '</div>';

if ($view === 'archives') {
    print '<form method="GET" class="depot-filter">';
    print '<input type="hidden" name="view" value="archives">';
    print '<label for="tranche" style="font-weight:bold;">Filtrer par durée :</label>';
    print '<select name="tranche" id="tranche" style="padding:6px;border-radius:4px;border:1px solid #ccc;">';
    print '<option value="">-- Toutes les durées --</option>';
    print '<option value="<5min" '.($tranche === '<5min' ? 'selected' : '').'>Moins de 5 min</option>';
    print '<option value="5-15min" '.($tranche === '5-15min' ? 'selected' : '').'>5 à 15 min</option>';
    print '<option value="15-30min" '.($tranche === '15-30min' ? 'selected' : '').'>15 à 30 min</option>';
    print '<option value="30-60min" '.($tranche === '30-60min' ? 'selected' : '').'>30 à 60 min</option>';
    print '<option value=">1h" '.($tranche === '>1h' ? 'selected' : '').'>Plus de 1 h</option>';
    print '</select>';
    print '<button type="submit" class="depot-btn depot-btn-primary">Filtrer</button>';
    print '<a href="'.$phpSelf.'?view=archives" style="padding:8px 14px;border-radius:4px;text-decoration:none;background:#ecf0f1;color:#333;font-weight:bold;">Réinitialiser</a>';
    print '</form>';
}

if ($view === 'reste') {
    print '<div style="margin-top:20px;">';

    $sql = "SELECT DISTINCT w.fk_facture FROM ".MAIN_DB_PREFIX."depot_work w
            INNER JOIN ".MAIN_DB_PREFIX."depot_restes r ON r.fk_depot_work = w.rowid
            WHERE r.resolved = 0 AND r.archived = 0 AND w.archived = 0";
    $res = $db->query($sql);

    $allRestes = array();
    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $fid = (int) $obj->fk_facture;
            $work = depotGetWorkRow($db, $fid, $cache);
            if ($work) {
                $allRestes[$fid] = depotGetRestes($db, (int) $work->rowid);
            }
        }
    }

    if (!empty($allRestes)) {
        print '<h2 style="color:#666;">⚠️ Restes à Livrer</h2>';
        foreach ($allRestes as $fact_id => $les_restes) {
            $facture_tmp = new Facture($db);
            $facture_tmp->fetch($fact_id);
            $soc_tmp = new Societe($db);
            $soc_tmp->fetch($facture_tmp->socid);

            print '<div class="depot-restes-card">';
            print '<div style="font-weight:bold;color:#e74c3c;margin-bottom:10px;">';
            print '📦 Facture: '.dol_escape_htmltag($facture_tmp->ref).' | '.dol_escape_htmltag($soc_tmp->name);
            print '</div>';

            $allAvailable = true;
            foreach ($les_restes as $r) {
                if (!depotCheckProductStock($db, $r['fk_product'], $r['qty'], $cache)) {
                    $allAvailable = false;
                    break;
                }
            }

            foreach ($les_restes as $r) {
                print '<div class="depot-restes-item">';
                print '🚩 <b>Produit :</b> '.dol_escape_htmltag($r['ref']).' ('.dol_escape_htmltag($r['label']).')<br>';
                print '📏 <b>Manquant :</b> '.number_format($r['qty'], 0, ',', ' ').'<br>';
                print '🕐 <b>Heure :</b> '.dol_escape_htmltag($r['time']).'<br>';

                $product = new Product($db);
                if ($product->fetch($r['fk_product']) > 0) {
                    $currentStock = (int) ($product->stock_reel ?? 0);
                    print '📊 <b>Stock actuel :</b> '.number_format($currentStock, 0, ',', ' ').'<br>';
                    $detailedLoc = depotGetDetailedLocation_cached($db, $r['fk_product'], $cache);
                    print '🗂️ <b>Emplacement :</b> '.$detailedLoc.' <br>';
                }

                print '</div>';
            }

            print "<form method='POST' style='margin-top:12px;'>";
            print "<input type='hidden' name='token' value='".newToken()."'>";
            print "<input type='hidden' name='view' value='reste'>";
            print "<input type='hidden' name='id' value='".$fact_id."'>";

            if ($allAvailable) {
                print "<button name='action' value='deliver' class='depot-btn depot-btn-success'>✅ Livré</button>";
            } else {
                print "<button name='action' value='deliver' disabled class='depot-btn depot-btn-muted'>✅ Livré (Stock insuffisant)</button>";
            }
            print "</form>";

            print '</div>';
        }
    } else {
        print '<p style="color:#666;">⚠️ Aucun reste à livrer.</p>';
    }

    print '</div>';
    print '</div>';
    llxFooter();
    exit;
}

if ($view === 'archives') {
    print '<div style="margin-top:20px;">';
    print '<h2 style="color:#666;">📚 Archives des Commandes Livrées</h2>';

    $duration_filter = '';
    if (!empty($tranche)) {
        if ($tranche === '<5min') {
            $duration_filter = ' AND w.duration < 300';
        } elseif ($tranche === '5-15min') {
            $duration_filter = ' AND w.duration >= 300 AND w.duration < 900';
        } elseif ($tranche === '15-30min') {
            $duration_filter = ' AND w.duration >= 900 AND w.duration < 1800';
        } elseif ($tranche === '30-60min') {
            $duration_filter = ' AND w.duration >= 1800 AND w.duration < 3600';
        } elseif ($tranche === '>1h') {
            $duration_filter = ' AND w.duration >= 3600';
        }
    }

    $sql = "SELECT w.rowid, w.fk_facture, w.status, w.duration, w.archived, w.archived_on
            FROM ".MAIN_DB_PREFIX."depot_work w
            WHERE w.archived = 1 AND w.status = 'livre'"
            . $duration_filter
            . " ORDER BY w.archived_on DESC, w.tms DESC";
    $resql = $db->query($sql);

    $archives = array();
    if ($resql && $db->num_rows($resql) > 0) {
        while ($w = $db->fetch_object($resql)) {
            $facture = new Facture($db);
            if ($facture->fetch((int) $w->fk_facture) <= 0) continue;

            $archives[] = array(
                'facture' => $facture,
                'work' => $w,
                'duration' => (int) $w->duration,
            );
        }
    }

    if (!empty($archives)) {
        print '<table class="depot-archive-table" width="100%">';
        print '<tr style="background:#6c757d;color:white;">';
        print '<th>Facture</th>';
        print '<th>Produit</th>';
        print '<th>Libellé</th>';
        print '<th>Qté</th>';
        print '<th>Emplacement</th>';
        print '<th>Durée</th>';
        print '</tr>';

        foreach ($archives as $arch) {
            $facture = $arch['facture'];
            $dur = $arch['duration'];

            $soc = new Societe($db);
            $soc->fetch($facture->socid);

            foreach ($facture->lines as $line) {
                $product = new Product($db);
                if (!empty($line->fk_product)) {
                    $product->fetch($line->fk_product);
                }

                $detailedLoc = depotGetDetailedLocation_cached($db, $product->id, $cache);

                print '<tr>';
                print '<td>'.dol_escape_htmltag($facture->ref).' | '.dol_escape_htmltag($soc->name).'</td>';
                print '<td>'.dol_escape_htmltag($product->ref).'</td>';
                print '<td>'.dol_escape_htmltag($product->label).'</td>';
                print '<td align="center">'.dol_escape_htmltag($line->qty).'</td>';
                print '<td align="center">'.$detailedLoc.'</td>';
                print '<td align="center" class="depot-pill-green">'.depotDurationPretty($dur).'</td>';
                print '</tr>';
            }
        }

        print '</table>';
    } else {
        print '<p style="color:#666;font-size:16px;">📭 Aucune archive disponible.</p>';
        print '<p style="color:#999;font-size:13px;">Aucune archive correspondante au filtre sélectionné.</p>';
    }

    print '</div>';
    print '</div>';
    llxFooter();
    exit;
}

$sql = 'SELECT rowid FROM '.MAIN_DB_PREFIX.'facture WHERE fk_statut IN (0,1) AND entity = '.((int) $conf->entity).' ORDER BY datec DESC';
$resql = $db->query($sql);

$ids_factures = array();
$ids_products = array();
if ($resql && $db->num_rows($resql) > 0) {
    while ($obj = $db->fetch_object($resql)) {
        $ids_factures[] = (int) $obj->rowid;
    }

    if (!empty($ids_factures)) {
        $sql_works = "SELECT * FROM ".MAIN_DB_PREFIX."depot_work WHERE fk_facture IN (" . implode(',', $ids_factures) . ")";
        $res_works = $db->query($sql_works);
        while ($w = $db->fetch_object($res_works)) {
            $cache['works'][$w->fk_facture] = $w;
        }
    }
}

if ($resql && $db->num_rows($resql) > 0) {
    while ($obj = $db->fetch_object($resql)) {
        $fid = (int) $obj->rowid;

        $facture = new Facture($db);
        $facture->fetch($fid);

        $work = depotGetWorkRow($db, $fid, $cache);
        if ($work && $work->archived) continue;

        $status = $work ? $work->status : 'a_preparer';

        $isValidated = ((int) $facture->statut === 1);
        $isProv = ((int) $facture->statut === 0);

        if ($isValidated && !$work) {
            $today = date('Y-m-d');
            $fact_date = !empty($facture->date) ? date('Y-m-d', $facture->date) : '';
            if ($fact_date !== $today) continue;
        }

        $computedRestes = depotComputeRestes($db, $facture, $cache);
        $hasRestes = !empty($computedRestes);

        if ($view === 'preparation') {
            if ($status === 'livre') continue;
            if ($status === 'prepare') continue;
            if ($status === 'a_preparer' || $status === 'en_cours') {
            } elseif ($isValidated && $work) {
            } elseif ($isProv) {
            } else {
                continue;
            }
        } elseif ($view === 'livre') {
            if ($status !== 'livre') continue;
        } elseif ($view === 'prepare') {
            if ($status !== 'prepare') continue;
        } else {
            continue;
        }

        $soc = new Societe($db);
        $soc->fetch($facture->socid);

        if ($view === 'prepare') {
            print '<div class="depot-info">';
            print '<div style="display:flex;align-items:center;gap:10px;">';
            print '<span style="font-size:24px;color:#1976d2;">ℹ️</span>';
            print '<div>';
            print '<strong>Commande préparée</strong>';
            print '<p style="color:#424242;margin:5px 0 0 0;font-size:14px;">';
            if ($isValidated) {
                print "La facture est validée, vous pouvez livrer la commande maintenant.";
            } else {
                print "La facture est en attente de validation, livrez quand validée.";
            }
            print '</p>';
            print '</div>';
            print '</div>';
            print '</div>';
        }

        print '<div class="depot-card" data-depot-start="'.(!empty($work->start_time) ? strtotime($work->start_time) : '').'">';
        print '<h3>'.dol_escape_htmltag($facture->ref).' | '.dol_escape_htmltag($soc->name).'</h3>';

        if ($status === 'livre') {
            $dur = (int)($work ? $work->duration : 0);
            $durationTxt = 'Durée de préparation '.depotDurationPretty($dur);
            print "<div class='depot-status-ok'>";
            print "<span>✅ LIVRÉE ($durationTxt)</span>";
            print "<form method='POST'><input type='hidden' name='token' value='".newToken()."'><input type='hidden' name='view' value='".dol_escape_htmltag($view)."'><input type='hidden' name='id' value='".$fid."'><button name='action' value='archive' class='depot-btn' style='background:#fff;color:#27ae60;'>Archiver</button></form>";
            print "</div>";
        } elseif ($status === 'en_cours') {
            print "<div class='depot-status-warn'>⏳ EN COURS... (⏱ <span class='depot-elapsed'>00:00:00</span>)</div>";
        } elseif ($status === 'prepare') {
            $dur = (int)($work ? $work->duration : 0);
            $durationTxt = depotDurationPretty($dur);
            print "<div class='depot-status-blue'>";
            print "<span>✅ PRÉPARÉE (Durée : $durationTxt)</span>";
            if ($isValidated) {
                print "<form method='POST'><input type='hidden' name='token' value='".newToken()."'><input type='hidden' name='view' value='prepare'><input type='hidden' name='id' value='".$fid."'><button name='action' value='deliver' class='depot-btn' style='background:#fff;color:#3498db;'>Livré</button></form>";
            }
            print "</div>";
        } else {
            print "<div class='depot-status-gray'>🕒 En attente de préparation</div>";
        }

        print '<table class="depot-table">';
        print '<tr><th>Réf</th><th>Libellé</th><th>Qté</th><th>Stock/Entrepot</th><th>Emplacement</th><th>Etat</th></tr>';

        foreach ($facture->lines as $line) {
            if (empty($line->fk_product)) continue;

            if (!isset($cache['products'][$line->fk_product])) {
                $product = new Product($db);
                $product->fetch($line->fk_product);
                $cache['products'][$line->fk_product] = $product;
            }
            $product = $cache['products'][$line->fk_product];

            $qty_cmd = (int) $line->qty;
            $stockData = depotGetProductStockByWarehouse_cached($db, $product->id, $cache);
            $totalStock = (float) $stockData['total'];
            $detailedLoc = depotGetDetailedLocation_cached($db, $product->id, $cache);
            $manquant = max(0, $qty_cmd - $totalStock);

            print '<tr>';
            print '<td>'.dol_escape_htmltag($product->ref).'</td>';
            print '<td>'.dol_escape_htmltag($product->label).'</td>';
            print '<td align="center">'.dol_escape_htmltag($qty_cmd).'</td>';

            print '<td align="left">';
            if (!empty($stockData['details'])) {
                foreach ($stockData['details'] as $s) {
                    if ((float) $s['qty'] > 0) {
                        print dol_escape_htmltag($s['warehouse']).': '.number_format($s['qty'], 0, ',', ' ').'<br>';
                    }
                }
                print '<strong>Total: '.number_format($totalStock, 0, ',', ' ').'</strong>';
            } else {
                print 'Aucun stock';
            }
            print '</td>';

            print '<td align="center">'.$detailedLoc.'</td>';
            print '<td align="center">';
            if ($hasRestes && $manquant > 0) {
                print '⚠️';
            } elseif ($totalStock < $qty_cmd && $status !== 'livre') {
                print "<span style='color:#e74c3c;font-weight:bold;'>⚠️</span>";
            } else {
                print '✅';
            }
            print '</td>';
            print '</tr>';
        }
        print '</table>';

        if ($hasRestes) {
            print "<div class='depot-block-danger'>⚠️ <b>Produit non disponible :</b><br>";
            foreach ($computedRestes as $r) {
                print "• <b>".dol_escape_htmltag($r['facture_ref'])."</b> | ".dol_escape_htmltag($r['ref'])." (".dol_escape_htmltag($r['label']).") | Manquant : ".number_format($r['qty'], 0, ',', ' ')."<br>";
            }
            print "</div>";
        }

        $canStart = true;
        foreach ($facture->lines as $line_check) {
            if (empty($line_check->fk_product)) continue;
            $stockDataChk = depotGetProductStockByWarehouse_cached($db, (int)$line_check->fk_product, $cache);
            $totalChk = (float)$stockDataChk['total'];
            if ($totalChk <= 0 && (int)$line_check->qty > 0) {
                $canStart = false;
                break;
            }
        }

        if ($view === 'preparation' && $status !== 'livre') {
            print "<form method='POST' style='margin-top:20px;'><input type='hidden' name='token' value='".newToken()."'><input type='hidden' name='view' value='preparation'><input type='hidden' name='id' value='".$fid."'>";

            if ($status === 'a_preparer') {
                if ($canStart) {
                    print "<button name='action' value='start' class='depot-btn depot-btn-primary'>▶ COMMENCER LA PRÉPARATION</button>";
                } else {
                    print "<button name='action' value='start' disabled class='depot-btn depot-btn-muted'>▶ COMMENCER LA PRÉPARATION</button>";
                }
            } elseif ($status === 'en_cours') {
                print "<button name='action' value='finish' class='depot-btn depot-btn-success'>✅ FAIT</button>";
            } elseif ($status === 'prepare') {
                if ($isValidated) {
                    print "<button name='action' value='deliver' class='depot-btn depot-btn-success'>🚚 Livré</button>";
                }
            }
            print '</form>';
        }

        print '</div>';
    }
} else {
    print '<p>Aucune facture en attente.</p>';
}

print '</div>';
llxFooter();
?>