<?php
// depot_ajax.php - Traitement AJAX uniquement (renvoie JSON)

@ini_set('display_errors', 0);
@error_reporting(0);
header('Content-Type: application/json; charset=UTF-8');

// Charger Dolibarr minimal
require '../../main.inc.php';

//if (!$user || !$user->id) {
    //echo json_encode(array('success' => false, 'message' => 'Utilisateur non autorisé'));
   // exit;
//}

//$token = GETPOST('token', 'alpha');
//if (!$token || !checkToken($token)) {
   // echo json_encode(array('success' => false, 'message' => 'Token invalide'));
   // exit;
//}

// === Début du code HTML (après POST) ===
if (!$user->id) accessforbidden();


$id = GETPOST('id', 'int');
$action = GETPOST('action', 'alpha');

$result = array('success' => true, 'message' => 'Action réussie');

if ($id > 0 && in_array($action, array('start', 'finish', 'deliver', 'archive'))) {
    require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
    
    $facture = new Facture($db);
    $facture->fetch($id);
    $is_validated = ((int) $facture->statut === 1);

    $cache = array('works' => array());

    function depotDbQuery($db, $sql) {
        return $db->query($sql);
    }

    function depotGetWorkRow($db, $fid, &$cache) {
        $fid = (int) $fid;
        if (isset($cache['works'][$fid])) return $cache['works'][$fid];

        $sql = "SELECT * FROM " . MAIN_DB_PREFIX . "depot_work WHERE fk_facture = " . $fid . " LIMIT 1";
        $res = depotDbQuery($db, $sql);
        if ($res && ($obj = $db->fetch_object($res))) {
            $cache['works'][$fid] = $obj;
            return $obj;
        }
        return null;
    }

    function depotUpsertWorkRow($db, $fid, $fields) {
        $fid = (int) $fid;
        $check_sql = "SELECT * FROM " . MAIN_DB_PREFIX . "depot_work WHERE fk_facture = " . $fid . " LIMIT 1";
        $check_res = depotDbQuery($db, $check_sql);

        $existing = false;
        $obj = null;
        if ($check_res && ($obj = $db->fetch_object($check_res))) {
            $existing = true;
        }

        if ($existing && empty($fields['status'])) $fields['status'] = $obj->status;
        if ($existing && empty($fields['duration'])) $fields['duration'] = $obj->duration;

        $status = $fields['status'] ?? 'a_preparer';
        $start_time = !empty($fields['start_time']) ? "'" . $db->idate($fields['start_time']) . "'" : "NULL";
        $finish_time = !empty($fields['finish_time']) ? "'" . $db->idate($fields['finish_time']) . "'" : "NULL";
        $validated_on = !empty($fields['validated_on']) ? "'" . $db->idate($fields['validated_on']) . "'" : "NULL";
        $delivered_on = !empty($fields['delivered_on']) ? "'" . $db->idate($fields['delivered_on']) . "'" : "NULL";
        $duration = (int) ($fields['duration'] ?? 0);
        $archived = !empty($fields['archived']) ? 1 : 0;
        $archived_on = !empty($fields['archived_on']) ? "'" . $db->idate($fields['archived_on']) . "'" : "NULL";

        if ($existing) {
            $sql = "UPDATE " . MAIN_DB_PREFIX . "depot_work SET
                    status = '" . $db->escape($status) . "',
                    start_time = $start_time,
                    finish_time = $finish_time,
                    duration = " . $duration . ",
                    validated_on = $validated_on,
                    delivered_on = $delivered_on,
                    archived = " . $archived . ",
                    archived_on = $archived_on,
                    tms = NOW()
                    WHERE fk_facture = " . $fid;
        } else {
            $sql = "INSERT INTO " . MAIN_DB_PREFIX . "depot_work
                    (fk_facture, status, start_time, finish_time, duration, validated_on, delivered_on, archived, archived_on, date_creation, tms)
                    VALUES
                    (" . $fid . ", '" . $db->escape($status) . "', $start_time, $finish_time, " . $duration . ", $validated_on, $delivered_on, " . $archived . ", $archived_on, NOW(), NOW())";
        }

        return depotDbQuery($db, $sql);
    }

    if ($action === 'start') {
        depotUpsertWorkRow($db, $id, array(
            'status' => 'en_cours',
            'start_time' => time(),
            'validated_on' => $is_validated ? time() : null,
        ));
        $result['message'] = 'Préparation commencée';
    } elseif ($action === 'finish') {
        $work = depotGetWorkRow($db, $id, $cache);
        $start = !empty($work->start_time) ? strtotime($work->start_time) : time();
        $duration = time() - $start;

        if ($is_validated) {
            depotUpsertWorkRow($db, $id, array(
                'status' => 'livre',
                'duration' => $duration,
                'finish_time' => time(),
                'delivered_on' => time(),
                'validated_on' => $work->validated_on ?? null,
            ));
        } else {
            depotUpsertWorkRow($db, $id, array(
                'status' => 'prepare',
                'duration' => $duration,
                'finish_time' => time(),
                'validated_on' => $work->validated_on ?? null,
            ));
        }
        $result['message'] = 'Préparation terminée';
    } elseif ($action === 'deliver') {
        $work = depotGetWorkRow($db, $id, $cache);
        depotUpsertWorkRow($db, $id, array(
            'status' => 'livre',
            'duration' => (int) ($work->duration ?? 0),
            'finish_time' => time(),
            'delivered_on' => time(),
        ));
        $result['message'] = 'Commande livrée';
    } elseif ($action === 'archive') {
        $work = depotGetWorkRow($db, $id, $cache);
        $current_status = $work ? $work->status : 'a_preparer';
        depotUpsertWorkRow($db, $id, array(
            'status' => $current_status,
            'archived' => 1,
            'archived_on' => time(),
        ));
        $result['message'] = 'Commande archivée';
    }
}

echo json_encode($result);
exit;