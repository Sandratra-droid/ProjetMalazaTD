<?php

/*
 * Point d'entrée mobile.
 *
 * L'authentification, les données et les actions restent traitées
 * par depotindex.php.
 */
define('DEPOT_MOBILE_MODE', true);

require __DIR__.'/depotindex.php';

require_once __DIR__.'/lib/depot_mobile.lib.php';

