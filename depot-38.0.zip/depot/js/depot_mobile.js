document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    const content = document.getElementById('dm-content');

    if (!content) {
        return;
    }

    const mobilePath = window.location.pathname;

    /*
     * Défilement horizontal des tableaux :
     * évite d'élargir toute la page.
     */
    content.querySelectorAll('table').forEach(function (table) {
        if (
            table.parentElement &&
            table.parentElement.classList.contains('dm-table-scroll')
        ) {
            return;
        }

        const wrapper = document.createElement('div');
        wrapper.className = 'dm-table-scroll';

        table.parentNode.insertBefore(wrapper, table);
        wrapper.appendChild(table);
    });

    /*
     * Les liens internes à l'interface mobile sont conservés.
     * Les liens vers les fiches générales Dolibarr deviennent du texte.
     */
    content.querySelectorAll('a[href]').forEach(function (link) {
        let url;

        try {
            url = new URL(
                link.getAttribute('href'),
                window.location.href
            );
        } catch (error) {
            url = null;
        }

        const allowed =
            url &&
            url.origin === window.location.origin &&
            url.pathname === mobilePath;

        if (allowed) {
            return;
        }

        const text = document.createElement('span');

        while (link.firstChild) {
            text.appendChild(link.firstChild);
        }

        link.replaceWith(text);
    });
});