<?php

function depotMobileIsActive()
{
    return defined('DEPOT_MOBILE_MODE')
        && DEPOT_MOBILE_MODE === true;
}

/*
 * Conservé pour compatibilité avec les marqueurs
 * déjà ajoutés aux lignes de produits.
 *
 * La recherche globale ne dépend plus de ces marqueurs.
 */
function depotMobileProductAttributes($ref, $label)
{
    if (!depotMobileIsActive()) {
        return '';
    }

    return ' data-depot-item="1"'
        .' data-product-ref="'.htmlspecialchars(
            (string) $ref,
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        ).'"'
        .' data-product-label="'.htmlspecialchars(
            (string) $label,
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        ).'"';
}

function depotMobileViews()
{
    return array(
        'preparation' => 'En préparation',
        'prepare' => 'Prêt non livrable',
        'livre' => 'Prêt et livrable',
        'archives' => 'Livré',
        'reste' => 'Reste à livrer',
        'sans_stock' => 'A commander'
    );
}

function depotMobileCurrentView()
{
    $views = depotMobileViews();
    $view = GETPOST('view', 'alpha');

    return isset($views[$view]) ? $view : 'preparation';
}

function depotUiHeader()
{
    if (!depotMobileIsActive()) {
        return call_user_func_array('llxHeader', func_get_args());
    }

    $view = depotMobileCurrentView();
    $baseUrl = dol_buildpath('/depot/depotmobile.php', 1);
    $scriptUrl = dol_buildpath('/depot/js/depot_mobile.js', 1);

    header('Content-Type: text/html; charset=UTF-8');
    header('Cache-Control: private, no-store');

    print '<!doctype html>';
    print '<html lang="fr"><head>';
    print '<meta charset="utf-8">';
    print '<meta name="viewport" '
        .'content="width=device-width, initial-scale=1">';
    print '<title>Préparation de commande</title>';

    print <<<'HTML'
<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    color: #172033;
    background: #f1f5f9;
}

.dm-header {
    padding: 16px;
    background: #123b5d;
    color: white;
}

.dm-header h1 {
    margin: 0;
    font-size: 21px;
}

.dm-tabs {
    display: flex;
    gap: 8px;
    overflow-x: auto;
    padding: 10px 12px;
    background: white;
    border-bottom: 1px solid #dbe3ec;
}

.dm-tab {
    flex: 0 0 auto;
    padding: 12px 14px;
    border-radius: 8px;
    background: #e8eef5;
    color: #123b5d;
    font-size: 14px;
    font-weight: bold;
    text-decoration: none;
}

.dm-tab.is-active {
    color: white;
    background: #123b5d;
}

.dm-content {
    padding: 12px;
}

.dm-table-scroll {
    overflow-x: auto;
    margin-bottom: 12px;
}

.dm-content button,
.dm-content input,
.dm-content select,
.dm-content textarea {
    font-size: 16px;
}

.dm-content input,
.dm-content textarea,
.dm-content select {
    max-width: 100%;
}

.dm-content button {
    min-height: 44px;
}

.dm-global-search {
    margin-top: 24px;
    padding: 16px;
    background: white;
    border: 1px solid #dbe3ec;
    border-radius: 10px;
}

.dm-global-search h2 {
    margin: 0 0 10px;
    font-size: 18px;
}

.dm-search-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.dm-global-search label {
    display: block;
    margin-bottom: 6px;
    font-size: 13px;
    font-weight: bold;
}

.dm-global-search input {
    width: 100%;
    padding: 12px;
    border: 1px solid #b9c7d6;
    border-radius: 7px;
}

.dm-search-actions,
.dm-pagination {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
    margin-top: 12px;
}

.dm-button {
    display: inline-block;
    padding: 12px 14px;
    border: 0;
    border-radius: 7px;
    background: #123b5d;
    color: white;
    text-decoration: none;
    font-weight: bold;
    cursor: pointer;
}

.dm-muted {
    color: #526176;
    font-size: 13px;
    line-height: 1.5;
}

.dm-product-result {
    margin-top: 12px;
    padding: 14px;
    border: 1px solid #dbe3ec;
    border-radius: 8px;
    background: #f8fafc;
}

.dm-product-ref {
    color: #123b5d;
    font-weight: bold;
}

.dm-product-label {
    margin-top: 5px;
}

.dm-product-location {
    margin-top: 10px;
    line-height: 1.5;
    font-size: 14px;
}

.dm-error {
    padding: 12px;
    color: #991b1b;
    background: #fee2e2;
    border-radius: 7px;
}

@media (max-width: 540px) {
    .dm-search-grid {
        grid-template-columns: 1fr;
    }
}

.dm-search-shortcut {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 16px;
    padding: 12px 14px;
    border: 1px solid #bfdbfe;
    border-radius: 10px;
    background: #eff6ff;
}

.dm-search-shortcut-title {
    display: block;
    color: #123b5d;
    font-size: 14px;
    font-weight: bold;
}

.dm-search-shortcut-note {
    display: block;
    margin-top: 4px;
    color: #526176;
    font-size: 12px;
    line-height: 1.4;
}

#dm-global-search {
    scroll-margin-top: 12px;
}

.dm-product-prices {
    display: flex;
    flex-wrap: wrap;
    gap: 8px 20px;
    margin-top: 12px;
    padding: 10px;
    background: #eef6ff;
    border-radius: 7px;
    font-size: 14px;
}

.dm-product-stock {
    margin-top: 12px;
    padding-top: 10px;
    border-top: 1px solid #dbe3ec;
    font-size: 14px;
}

.dm-stock-title {
    margin-bottom: 8px;
    color: #123b5d;
    font-weight: bold;
}

.dm-stock-row {
    display: flex;
    justify-content: space-between;
    gap: 16px;
    padding: 5px 0;
}

.dm-stock-total {
    display: flex;
    justify-content: space-between;
    gap: 16px;
    margin-top: 7px;
    padding-top: 9px;
    border-top: 1px solid #cbd5e1;
    font-weight: bold;
}

.dm-stock-negative {
    color: #b91c1c;
}
</style>
HTML;

    print '<script defer src="'
        .dol_escape_htmltag($scriptUrl).'"></script>';

    print '</head><body>';

    print '<header class="dm-header">';
    print '<h1>Depot Malaza</h1>';
    print '</header>';

    print '<nav class="dm-tabs" aria-label="Vues du dépôt">';

    foreach (depotMobileViews() as $key => $label) {
        $class = 'dm-tab';

        if ($key === $view) {
            $class .= ' is-active';
        }

        print '<a class="'.$class.'" href="'
            .dol_escape_htmltag($baseUrl.'?view='.$key).'"';

        if ($key === $view) {
            print ' aria-current="page"';
        }

        print '>'.dol_escape_htmltag($label).'</a>';
    }

    print '</nav>';
    print '<main id="dm-content" class="dm-content">';

    print '<aside class="dm-search-shortcut">';
    print '<div>';
    print '<span class="dm-search-shortcut-title">';
    print 'Vous cherchez un produit ?';
    print '</span>';

    print '<span class="dm-search-shortcut-note">';
    print 'Consultez son emplacement, son prix et son stock.';
    print '</span>';
    print '</div>';

    print '<a class="dm-button" href="#dm-global-search">';
    print 'Rechercher un produit';
    print '</a>';

    print '</aside>';
}

/*
 * Recherche en lecture seule dans le catalogue produit.
 * Ne dépend ni des factures affichées, ni de leur limite.
 */
function depotMobileRenderGlobalSearch()
{
    global $db, $user, $conf;

    $view = depotMobileCurrentView();
    $baseUrl = dol_buildpath('/depot/depotmobile.php', 1);

    $ref = trim((string) GETPOST('dm_ref', 'alphanohtml'));
    $label = trim((string) GETPOST('dm_label', 'alphanohtml'));
    $requested = ((int) GETPOST('dm_search', 'int') === 1);
    $page = max(0, (int) GETPOST('dm_page', 'int'));

    $limit = 20;

    print '<section id="dm-global-search" class="dm-global-search">';
    print '<h2>Recherche globale de produits</h2>';

    print '<p class="dm-muted">';
    print 'Recherche dans le catalogue des produits autorisés, ';
    print 'indépendamment des commandes affichées. ';
    print 'Les résultats ne modifient aucune commande.';
    print '</p>';

    /*
     * Cette permission concerne la recherche catalogue.
     * Elle ne remplace pas les permissions des actions du dépôt.
     */
    $canReadProducts = method_exists($user, 'hasRight')
        ? $user->hasRight('produit', 'lire')
        : !empty($user->rights->produit->lire);

    if (
        empty($user->id)
        || !empty($user->socid)
        || !$canReadProducts
    ) {
        print '<p class="dm-error">';
        print 'Votre compte ne dispose pas du droit de consulter ';
        print 'le catalogue des produits.';
        print '</p></section>';
        return;
    }

    print '<form method="GET" action="'
        .dol_escape_htmltag($baseUrl)
        .'#dm-global-search">';

    print '<input type="hidden" name="view" value="'
        .dol_escape_htmltag($view).'">';

    print '<input type="hidden" name="dm_search" value="1">';

    print '<div class="dm-search-grid">';

    print '<div>';
    print '<label for="dm-ref">Référence produit</label>';
    print '<input id="dm-ref" type="search" name="dm_ref"';
    print ' maxlength="100" value="'.dol_escape_htmltag($ref).'"';
    print ' placeholder="Ex. : FAR">';
    print '</div>';

    print '<div>';
    print '<label for="dm-label">Libellé produit</label>';
    print '<input id="dm-label" type="search" name="dm_label"';
    print ' maxlength="100" value="'.dol_escape_htmltag($label).'"';
    print ' placeholder="Ex. : farine">';
    print '</div>';

    print '</div>';

    print '<div class="dm-search-actions">';
    print '<button type="submit" class="dm-button">';
    print 'Rechercher';
    print '</button>';

    print '<a class="dm-button" href="'
        .dol_escape_htmltag($baseUrl.'?view='.$view)
        .'#dm-global-search">Réinitialiser</a>';

    print '</div>';
    print '</form>';

    if (!$requested) {
        print '</section>';
        return;
    }

    if ($ref === '' && $label === '') {
        print '<p class="dm-muted">';
        print 'Renseignez une référence ou un libellé.';
        print '</p></section>';
        return;
    }

    /*
     * Limites côté serveur, indépendantes du formulaire HTML.
     */
    if (
        strlen($ref) > 400
        || strlen($label) > 400
        || $page > 10000
    ) {
        print '<p class="dm-error">Recherche invalide.</p>';
        print '</section>';
        return;
    }

    /*
     * Entités autorisées pour les produits.
     * Conserve les règles de partage configurées dans Dolibarr.
     */
    $entityList = array_filter(
        array_map('intval', explode(',', getEntity('product'))),
        function ($entityId) {
            return $entityId > 0;
        }
    );

    if (empty($entityList)) {
        print '<p class="dm-error">';
        print 'Aucune entité produit autorisée.';
        print '</p></section>';
        return;
    }

    $sql = 'SELECT p.rowid, p.ref, p.label,';
    $sql .= ' p.price AS sale_price_ht,';
    $sql .= ' p.price_ttc AS sale_price_ttc,';
    $sql .= ' pe.localisation, pe.salle_depot,';
    $sql .= ' pe.etagere, pe.ligne';
    $sql .= ' FROM '.MAIN_DB_PREFIX.'product p';
    $sql .= ' LEFT JOIN '.MAIN_DB_PREFIX.'product_extrafields pe';
    $sql .= ' ON pe.fk_object = p.rowid';
    $sql .= ' WHERE p.entity IN ('.implode(',', $entityList).')';

    // Produits physiques, pas les services.
    $sql .= ' AND p.fk_product_type = 0';

    if ($ref !== '') {
        $sql .= " AND p.ref LIKE '%"
            .$db->escape($db->escapeforlike($ref))
            ."%'";
    }

    if ($label !== '') {
        $sql .= " AND p.label LIKE '%"
            .$db->escape($db->escapeforlike($label))
            ."%'";
    }

    $sql .= ' ORDER BY p.ref ASC, p.rowid ASC';

    // Une ligne supplémentaire indique la présence d'une page suivante.
    $sql .= $db->plimit($limit + 1, $page * $limit);

    $res = $db->query($sql);

    if (!$res) {
        dol_syslog(
            'Depot recherche globale : '.$db->lasterror(),
            LOG_ERR
        );

        print '<p class="dm-error">';
        print 'La recherche est momentanément indisponible. ';
        print 'Consultez le journal serveur.';
        print '</p></section>';
        return;
    }

    $rows = array();

    while ($obj = $db->fetch_object($res)) {
        $rows[] = $obj;
    }

    $hasNext = count($rows) > $limit;

    if ($hasNext) {
        array_pop($rows);
    }

    $canReadStock = method_exists($user, 'hasRight')
    ? $user->hasRight('stock', 'lire')
    : !empty($user->rights->stock->lire);

    $stockByProduct = null;

    if ($canReadStock) {
        $stockByProduct = depotMobileLoadSearchStocks($db, $rows);
    }

    if (empty($rows)) {
        print '<p class="dm-muted">';
        print 'Aucun produit sur cette page ne correspond à la recherche.';
        print '</p>';
    } else {
        print '<p class="dm-muted">';
        print count($rows).' résultat(s) sur cette page.';
        print '</p>';
    }

    $optionCache = array();

    $locationFields = array(
        'localisation' => 'Localisation',
        'salle_depot' => 'Salle',
        'etagere' => 'Étagère',
        'ligne' => 'Ligne'
    );

    foreach ($rows as $product) {
        print '<article class="dm-product-result">';

        print '<div class="dm-product-ref">'
            .dol_escape_htmltag($product->ref).'</div>';

        print '<div class="dm-product-label">'
            .dol_escape_htmltag($product->label).'</div>';

            print '<div class="dm-product-prices">';

        print '<div>';
        print 'Prix standard HT : ';
        print '<strong>'
            .dol_escape_htmltag(price($product->sale_price_ht))
            .' '.dol_escape_htmltag($conf->currency)
            .'</strong>';
        print '</div>';

        print '<div>';
        print 'Prix standard TTC : ';
        print '<strong>'
            .dol_escape_htmltag(price($product->sale_price_ttc))
            .' '.dol_escape_htmltag($conf->currency)
            .'</strong>';
        print '</div>';

        print '</div>';

        $parts = array();

        foreach ($locationFields as $code => $fieldLabel) {
            $value = isset($product->$code)
                ? (string) $product->$code
                : '';

            $valueLabel = depotLocationOptionLabel(
                $db,
                $code,
                $value,
                $optionCache
            );

            if ($valueLabel !== '') {
                $parts[] = dol_escape_htmltag($fieldLabel)
                    .': '.dol_escape_htmltag($valueLabel);
            }
        }

        print '<div class="dm-product-location">';

        print !empty($parts)
            ? implode('<br>', $parts)
            : 'Emplacement produit non renseigné';

        print '</div>';
print '<div class="dm-product-stock">';
print '<div class="dm-stock-title">Stock physique par entrepôt</div>';

if (!$canReadStock) {
    print '<p class="dm-muted">';
    print 'Votre compte ne dispose pas du droit de consulter les stocks.';
    print '</p>';
} elseif ($stockByProduct === false) {
    print '<p class="dm-error">';
    print 'Stock momentanément indisponible.';
    print '</p>';
} else {
    $productId = (int) $product->rowid;

    $productStock = isset($stockByProduct[$productId])
        ? $stockByProduct[$productId]
        : array(
            'total' => 0.0,
            'details' => array()
        );

    if (empty($productStock['details'])) {
        print '<p class="dm-muted">';
        print 'Aucun stock enregistré dans les entrepôts autorisés.';
        print '</p>';
    } else {
        foreach ($productStock['details'] as $stockDetail) {
            $quantity = (float) $stockDetail['quantity'];

            $quantityClass = $quantity < 0
                ? ' class="dm-stock-negative"'
                : '';

            print '<div class="dm-stock-row">';

            print '<span>'
                .dol_escape_htmltag($stockDetail['warehouse'])
                .'</span>';

            print '<span'.$quantityClass.'>'
                .dol_escape_htmltag(
                    depotMobileFormatStockQuantity($quantity)
                )
                .'</span>';

            print '</div>';
        }
    }

        $totalClass = (float) $productStock['total'] < 0
            ? ' class="dm-stock-negative"'
            : '';

        print '<div class="dm-stock-total">';
        print '<span>Total des entrepôts autorisés</span>';

        print '<span'.$totalClass.'>'
            .dol_escape_htmltag(
                depotMobileFormatStockQuantity(
                    $productStock['total']
                )
            )
            .'</span>';

        print '</div>';
 }

    print '</div>';

    print '</article>';
    }

    if ($page > 0 || $hasNext) {
        print '<nav class="dm-pagination" aria-label="Pages de résultats">';

        $params = array(
            'view' => $view,
            'dm_search' => 1,
            'dm_ref' => $ref,
            'dm_label' => $label
        );

        if ($page > 0) {
            $params['dm_page'] = $page - 1;

            $previousUrl = $baseUrl.'?'
                .http_build_query($params, '', '&', PHP_QUERY_RFC3986)
                .'#dm-global-search';

            print '<a class="dm-button" href="'
                .dol_escape_htmltag($previousUrl)
                .'">Précédent</a>';
        }

        print '<span>Page '.($page + 1).'</span>';

        if ($hasNext) {
            $params['dm_page'] = $page + 1;

            $nextUrl = $baseUrl.'?'
                .http_build_query($params, '', '&', PHP_QUERY_RFC3986)
                .'#dm-global-search';

            print '<a class="dm-button" href="'
                .dol_escape_htmltag($nextUrl)
                .'">Suivant</a>';
        }

        print '</nav>';
    }

    print '</section>';
}

function depotUiFooter()
{
    if (!depotMobileIsActive()) {
        return call_user_func_array('llxFooter', func_get_args());
    }

    /*
     * La recherche arrive après le contenu métier,
     * quelle que soit la vue et même avant un exit.
     */
    depotMobileRenderGlobalSearch();

    print '</main></body></html>';
}

/**
 * Formate une quantité sans imposer un affichage entier.
 */
function depotMobileFormatStockQuantity($quantity)
{
    $formatted = number_format(
        (float) $quantity,
        6,
        ',',
        ' '
    );

    return rtrim(rtrim($formatted, '0'), ',');
}

/**
 * Charge en une seule requête les stocks des produits
 * de la page de résultats.
 *
 * Seuls les entrepôts des entités autorisées sont pris en compte.
 *
 * Retourne false en cas d'erreur, et non un stock artificiellement nul.
 */
function depotMobileLoadSearchStocks($db, $products)
{
    $ids = array();

    foreach ($products as $product) {
        $productId = (int) $product->rowid;

        if ($productId > 0) {
            $ids[$productId] = $productId;
        }
    }

    if (empty($ids)) {
        return array();
    }

    $stockEntities = array_filter(
        array_map(
            'intval',
            explode(',', getEntity('stock'))
        ),
        function ($entityId) {
            return $entityId > 0;
        }
    );

    if (empty($stockEntities)) {
        dol_syslog(
            'Depot recherche : aucune entité de stock autorisée.',
            LOG_ERR
        );

        return false;
    }

    $stocks = array();

    foreach ($ids as $productId) {
        $stocks[$productId] = array(
            'total' => 0.0,
            'details' => array()
        );
    }

    $sql = 'SELECT ps.fk_product, ps.fk_entrepot, ps.reel,';
    $sql .= ' e.ref AS warehouse_ref';
    $sql .= ' FROM '.MAIN_DB_PREFIX.'product_stock ps';
    $sql .= ' INNER JOIN '.MAIN_DB_PREFIX.'entrepot e';
    $sql .= ' ON e.rowid = ps.fk_entrepot';
    $sql .= ' WHERE ps.fk_product IN ('.implode(',', $ids).')';
    $sql .= ' AND e.entity IN ('.implode(',', $stockEntities).')';
    $sql .= ' ORDER BY ps.fk_product ASC, e.ref ASC, e.rowid ASC';

    $res = $db->query($sql);

    if (!$res) {
        dol_syslog(
            'Depot recherche stocks : '.$db->lasterror(),
            LOG_ERR
        );

        return false;
    }

    while ($obj = $db->fetch_object($res)) {
        $productId = (int) $obj->fk_product;
        $quantity = (float) $obj->reel;

        if (!isset($stocks[$productId])) {
            continue;
        }

        $stocks[$productId]['details'][] = array(
            'warehouse' => (string) $obj->warehouse_ref,
            'quantity' => $quantity
        );

        $stocks[$productId]['total'] += $quantity;
    }

    return $stocks;
}