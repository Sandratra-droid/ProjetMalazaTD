CREATE TABLE llx_depot_work (
    rowid INT AUTO_INCREMENT PRIMARY KEY,
    fk_facture INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'a_preparer',
    start_time DATETIME NULL,
    finish_time DATETIME NULL,
    duration INT NOT NULL DEFAULT 0,
    validated_on DATETIME NULL,
    delivered_on DATETIME NULL,
    archived TINYINT(1) NOT NULL DEFAULT 0,
    archived_on DATETIME NULL,
    date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    tms TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_depot_work_facture (fk_facture),
    KEY idx_depot_work_status (status),
    KEY idx_depot_work_archived (archived)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE llx_depot_restes (
    rowid INT AUTO_INCREMENT PRIMARY KEY,
    fk_depot_work INT NOT NULL,
    fk_facture INT NOT NULL,
    fk_product INT NOT NULL,
    facture_ref VARCHAR(50) NOT NULL,
    product_ref VARCHAR(50) DEFAULT NULL,
    product_label VARCHAR(255) DEFAULT NULL,
    qty_manquante DECIMAL(24,8) NOT NULL DEFAULT 0,
    detected_on DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved TINYINT(1) NOT NULL DEFAULT 0,
    resolved_on DATETIME NULL,
    archived TINYINT(1) NOT NULL DEFAULT 0,
    archived_on DATETIME NULL,
    KEY idx_depot_restes_work (fk_depot_work),
    KEY idx_depot_restes_facture (fk_facture),
    KEY idx_depot_restes_product (fk_product),
    KEY idx_depot_restes_resolved (resolved),
    KEY idx_depot_restes_archived (archived)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;