<?php
// custom/depot/screen_client.php
// Écran public : état de préparation des commandes (module Dépôt)
// N'affiche que les commandes du jour (date du jour)
// Les lignes "Livré" disparaissent après 5 secondes et ne réapparaissent plus


// Charger Dolibarr
require_once '../../main.inc.php';


// Date du jour au format SQL
$today = date('Y-m-d');


// On affiche :
// - a_preparer, en_cours, prepare : normalement (si date_creation = aujourd'hui)
// - livre : uniquement si la ligne a été mise à jour il y a moins de 8 secondes
$sql = "SELECT w.rowid,
               w.fk_facture,
               w.status,
               w.archived,
               w.date_creation,
               w.start_time,
               w.tms,
               f.ref AS facture_ref,
               s.nom AS societe_nom
        FROM ".MAIN_DB_PREFIX."depot_work AS w
        LEFT JOIN ".MAIN_DB_PREFIX."facture AS f ON f.rowid = w.fk_facture
        LEFT JOIN ".MAIN_DB_PREFIX."societe AS s ON s.rowid = f.fk_soc
        WHERE w.archived = 0
          AND w.status IN ('a_preparer','en_cours','prepare','livre')
          AND DATE(w.date_creation) = '".$db->escape($today)."'
          AND (
                w.status <> 'livre'
                OR (w.status = 'livre' AND w.tms >= DATE_SUB(NOW(), INTERVAL 35 SECOND))
              )
        ORDER BY w.date_creation DESC";


// print '<!-- SQL : '.$sql.' -->';


$resql = $db->query($sql);


if (!$resql) {
    print "Erreur SQL : ".$db->lasterror();
    exit;
}


$works = array();
while ($obj = $db->fetch_object($resql)) {
    $works[] = $obj;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>État de préparation des commandes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .screen-wrap {
            max-width: 1200px;
            margin: 0 auto;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-size: 28px;
        }
        .commande {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 15px 20px;
            margin-bottom: 15px;
            font-size: 20px;
            transition: opacity 0.5s ease, transform 0.5s ease;
        }
        .commande-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .ref-client {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .ref {
            font-weight: bold;
            font-size: 22px;
            color: #222;
        }
        .client {
            color: #666;
            font-size: 16px;
        }
        .status {
            padding: 8px 14px;
            border-radius: 4px;
            color: #fff;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 15px;
            min-width: 140px;
            text-align: center;
        }

        /* Couleurs selon l'état */
        .status-a_preparer,
        .status-en_cours {
            background: #f59e0b; /* orange : En cours */
        }
        .status-prepare {
            background: #22c55e; /* vert clair : Prêt */
        }
        .status-livre {
            background: #16a34a; /* vert foncé : Livré */
        }

        .no-commande {
            text-align: center;
            color: #777;
            font-size: 18px;
            padding: 40px;
        }

        /* Classe pour faire disparaître en douceur */
        .fade-out {
            opacity: 0;
            transform: translateY(-10px);
            pointer-events: none;
        }


                /* Bandeau de texte défilant */
        .marquee-wrap {
            overflow: hidden;
            white-space: nowrap;
            border-radius: 6px;
            margin-bottom: 30px;
            padding: 10px 0;
            background: #1f2937; /* fond sombre */
        }
        .marquee-text {
            display: inline-block;
            padding-left: 100%;
            color: #facc15; /* jaune / doré */
            font-size: 22px;
            font-weight: bold;
            animation: marquee 20s linear infinite;
        }
        @keyframes marquee {
            0%   { transform: translateX(0%); }
            100% { transform: translateX(-100%); }
        }
    </style>

    <!-- Rafraîchissement automatique toutes les 10 secondes -->
    <script>
        setTimeout(function(){
            location.reload();
        }, 20000);
    </script>

    <!-- Disparition des lignes "Livré" après 30 secondes -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.status-livre').forEach(function(el) {
            var row = el.closest('.commande');
            if (!row) return;

            // Attendre 30 secondes, puis faire disparaître
            setTimeout(function() {
                row.classList.add('fade-out');

                // Optionnel : retirer complètement du DOM après la transition
                setTimeout(function() {
                    row.remove();
                }, 600);
            }, 30000);
        });
    });
</script>
</head>
<body>

<div class="screen-wrap">
    <div class="marquee-wrap">
        <div class="marquee-text">
            Veuillez optimiser l'état de préparation de vos commandes
        </div>
    </div>
    <?php if (empty($works)): ?>
        <div class="no-commande">
            Aucune commande en préparation.
        </div>
    <?php else: ?>
        <?php foreach ($works as $w): ?>
            <div class="commande">
                <div class="commande-inner">
                    <div class="ref-client">
                        <div class="ref">
                            <?php echo dol_escape_htmltag($w->facture_ref); ?>
                        </div>
                        <?php if (!empty($w->societe_nom)): ?>
                            <div class="client">
                                <?php echo dol_escape_htmltag($w->societe_nom); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="status status-<?php echo dol_escape_htmltag($w->status); ?>">
                        <?php
                        // On affiche un texte simple, seul "Livré" est explicite
                        switch ($w->status) {
                            case 'a_preparer':
                            case 'en_cours':
                                echo 'En cours...';
                                break;

                            case 'prepare':
                                echo 'Prêt';
                                break;

                            case 'livre':
                                echo 'Livré';
                                break;

                            default:
                                echo dol_escape_htmltag($w->status);
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>