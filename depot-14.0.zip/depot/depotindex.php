<?php
ini_set('display_errors', 0);
error_reporting(0);

require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';

if (!$user->id) accessforbidden();


$fk_product = GETPOST('fk_product', 'int');
$note = GETPOST('note', 'restricthtml');
$contact_name = GETPOST('contact_name', 'alphanohtml');
$fullscreen = (int) GETPOST('fullscreen', 'int');

function depotProductLink($product)
{
    if (empty($product->id)) return '';
    $url = DOL_URL_ROOT.'/product/card.php?id='.(int) $product->id;
    return '<a href="'.$url.'" target="_blank" rel="noopener">'.dol_escape_htmltag($product->ref).'</a>';
}

function depotInvoiceLink($facture)
{
    if (empty($facture->id)) return '';
    $url = DOL_URL_ROOT.'/compta/facture/card.php?id='.(int) $facture->id;
    return '<a href="'.$url.'" target="_blank" rel="noopener">'.dol_escape_htmltag($facture->ref).'</a>';
}


$action = GETPOST('action', 'alpha');
$id = GETPOST('id', 'int');
$view = GETPOST('view', 'alpha');
if (empty($view)) $view = 'preparation';
$phpSelf = $_SERVER['PHP_SELF'];
$tranche = GETPOST('tranche', 'alpha');

// Limite configurable du nombre de commandes affichées en préparation
$preparation_limit = (int) getDolGlobalInt('DEPOT_PREPARATION_LIMIT');

if ($preparation_limit <= 0) {
    $preparation_limit = 2;
}

$cache = array(
    'stocks' => array(),
    'locations' => array(),
    'works' => array(),
    'products' => array(),
);

function depotDurationPretty($sec) {
    $sec = (int) $sec;
    $h = floor($sec / 3600);
    $m = floor(($sec % 3600) / 60);
    $s = $sec % 60;
    if ($h > 0) return $h.'h '.$m.'min '.$s.'s';
    if ($m > 0) return $m.'min '.$s.'s';
    return $s.'s';
}

function depotGetWorkRow($db, $fid, &$cache) {
    $fid = (int) $fid;
    if (isset($cache['works'][$fid])) return $cache['works'][$fid];

    $sql = "SELECT rowid, fk_facture, status, start_time, finish_time, duration, validated_on, delivered_on, archived, archived_on, tms
            FROM ".MAIN_DB_PREFIX."depot_work
            WHERE fk_facture = ".$fid."
            LIMIT 1";
    $res = $db->query($sql);
    if ($res && ($obj = $db->fetch_object($res))) {
        $cache['works'][$fid] = $obj;
        return $obj;
    }
    return null;
}

function depotUpsertWorkRow($db, $fid, $fields = array()) {
    $fid = (int) $fid;
    $check_sql = "SELECT rowid, status, duration
                  FROM ".MAIN_DB_PREFIX."depot_work
                  WHERE fk_facture = ".$fid."
                  LIMIT 1";
    $check_res = $db->query($check_sql);
    $existing = ($check_res && ($obj = $db->fetch_object($check_res)));

    if ($existing && empty($fields['status'])) $fields['status'] = $obj->status;
    if ($existing && empty($fields['duration'])) $fields['duration'] = $obj->duration;

    $status = $fields['status'] ?? 'a_preparer';
    $start_time = !empty($fields['start_time']) ? "'".$db->idate($fields['start_time'])."'" : "NULL";
    $finish_time = !empty($fields['finish_time']) ? "'".$db->idate($fields['finish_time'])."'" : "NULL";
    $validated_on = !empty($fields['validated_on']) ? "'".$db->idate($fields['validated_on'])."'" : "NULL";
    $delivered_on = !empty($fields['delivered_on']) ? "'".$db->idate($fields['delivered_on'])."'" : "NULL";
    $duration = (int)($fields['duration'] ?? 0);
    $archived = !empty($fields['archived']) ? 1 : 0;
    $archived_on = !empty($fields['archived_on']) ? "'".$db->idate($fields['archived_on'])."'" : "NULL";

    if ($existing) {
        $sql = "UPDATE ".MAIN_DB_PREFIX."depot_work SET
            status = '".$db->escape($status)."',
            start_time = $start_time,
            finish_time = $finish_time,
            duration = ".$duration.",
            validated_on = $validated_on,
            delivered_on = $delivered_on,
            archived = ".$archived.",
            archived_on = $archived_on,
            tms = NOW()
            WHERE fk_facture = ".$fid;
    } else {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_work
            (fk_facture, status, start_time, finish_time, duration, validated_on, delivered_on, archived, archived_on, date_creation, tms)
            VALUES
            (".$fid.", '".$db->escape($status)."', $start_time, $finish_time, ".$duration.", $validated_on, $delivered_on, ".$archived.", $archived_on, NOW(), NOW())";
    }

    return $db->query($sql);
}

function depotBatchLoadStocks($db, $ids, &$cache) {
    if (empty($ids)) return;
    $ids = array_values(array_unique(array_map('intval', $ids)));
    if (empty($ids)) return;

    $sql = "SELECT ps.fk_product, ps.reel, e.ref as warehouse_ref
            FROM ".MAIN_DB_PREFIX."product_stock ps
            LEFT JOIN ".MAIN_DB_PREFIX."entrepot e ON e.rowid = ps.fk_entrepot
            WHERE ps.fk_product IN (".implode(',', $ids).")
            ORDER BY ps.fk_product ASC, e.ref ASC";
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $cache['stocks'][$obj->fk_product][] = array(
                'warehouse' => !empty($obj->warehouse_ref) ? $obj->warehouse_ref : 'N/A',
                'qty' => (float) $obj->reel,
            );
        }
    }
}

function depotBatchLoadLocations($db, $ids, &$cache) {
    if (empty($ids)) return;
    $ids = array_values(array_unique(array_map('intval', $ids)));
    if (empty($ids)) return;

    $sql = "SELECT fk_object, salle_depot, etagere, localisation
            FROM ".MAIN_DB_PREFIX."product_extrafields
            WHERE fk_object IN (".implode(',', $ids).")";
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $cache['locations'][$obj->fk_object] = array(
                'salle_depot' => !empty($obj->salle_depot) ? $obj->salle_depot : '',
                'etagere' => !empty($obj->etagere) ? $obj->etagere : '',
                'localisation' => !empty($obj->localisation) ? $obj->localisation : '',
            );
        }
    }
}

function depotGetProductStockByWarehouse_cached($db, $fk_product, &$cache) {
    $fk_product = (int) $fk_product;

    if (isset($cache['stocks'][$fk_product])) {
        $stocks = $cache['stocks'][$fk_product];
        $total = 0;
        foreach ($stocks as $s) $total += $s['qty'];
        return array('total' => $total, 'details' => $stocks);
    }

    $stocks = array();
    $total = 0;
    $sql = "SELECT ps.reel, e.ref as warehouse_ref
            FROM ".MAIN_DB_PREFIX."product_stock ps
            LEFT JOIN ".MAIN_DB_PREFIX."entrepot e ON e.rowid = ps.fk_entrepot
            WHERE ps.fk_product = ".$fk_product."
            ORDER BY e.ref ASC";
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $qty = (float) $obj->reel;
            $total += $qty;
            $stocks[] = array(
                'warehouse' => !empty($obj->warehouse_ref) ? $obj->warehouse_ref : 'N/A',
                'qty' => $qty,
            );
        }
        $cache['stocks'][$fk_product] = $stocks;
    }

    return array('total' => $total, 'details' => $stocks);
}

function depotGetDetailedLocation_cached($db, $fk_product, &$cache) {
    $fk_product = (int) $fk_product;

    // Si déjà en cache, on recompose à partir des valeurs en cache
    if (isset($cache['locations'][$fk_product])) {
        $loc = $cache['locations'][$fk_product];

        $salle = !empty($loc['salle_depot']) ? $loc['salle_depot'] : '';
        $etagere = !empty($loc['etagere']) ? $loc['etagere'] : '';
        $localisation = !empty($loc['localisation']) ? $loc['localisation'] : '';
    } else {
        // Lecture directe des extrafields (phase de test : colonnes présentes mais pas forcément remplies)
        $salle = '';
        $etagere = '';
        $localisation = '';

        $sql2 = 'SELECT salle_depot, etagere, localisation
                 FROM '.MAIN_DB_PREFIX.'product_extrafields
                 WHERE fk_object = '.$fk_product.'
                 LIMIT 1';
        $res2 = $db->query($sql2);
        if ($res2 && $db->num_rows($res2) > 0) {
            $tmp2 = $db->fetch_object($res2);
            if ($tmp2) {
                $salle = !empty($tmp2->salle_depot) ? $tmp2->salle_depot : '';
                $etagere = !empty($tmp2->etagere) ? $tmp2->etagere : '';
                $localisation = !empty($tmp2->localisation) ? $tmp2->localisation : '';
            }
        }
    }

    // Paramètres globaux du module (configuration Dépôt)
    $defaultSalle   = getDolGlobalString('DEPOT_DEFAULT_SALLE');
    $defaultEtagere = getDolGlobalString('DEPOT_DEFAULT_ETAGERE');
    $defaultZone    = getDolGlobalString('DEPOT_DEFAULT_ZONE');

    $parts = array();

    // Salle : extrafield si présent, sinon valeur globale si configurée
    if (!empty($salle) || !empty($defaultSalle)) {
        $parts[] = 'Salle: '.dol_escape_htmltag($salle ?: $defaultSalle);
    }

    // Étagère : extrafield ou valeur globale
    if (!empty($etagere) || !empty($defaultEtagere)) {
        $parts[] = 'Étagère: '.dol_escape_htmltag($etagere ?: $defaultEtagere);
    }

    // Localisation / Zone : extrafield ou valeur globale
    if (!empty($localisation) || !empty($defaultZone)) {
        $parts[] = 'Localisation: '.dol_escape_htmltag($localisation ?: $defaultZone);
    }

    return implode('<br>', $parts);
}

function depotComputeRestes($db, $facture, &$cache) {
    $restes = array();
    if (empty($facture->lines) || !is_array($facture->lines)) return $restes;

    foreach ($facture->lines as $line) {
        if (empty($line->fk_product)) continue;

        $stockData = depotGetProductStockByWarehouse_cached($db, (int) $line->fk_product, $cache);
        $totalStock = (float) $stockData['total'];
        $qty_cmd = (float) $line->qty;

        if ($qty_cmd > $totalStock) {
            if (!isset($cache['products'][$line->fk_product])) {
                $product = new Product($db);
                if ($product->fetch($line->fk_product) <= 0) continue;
                $cache['products'][$line->fk_product] = $product;
            }

            $product = $cache['products'][$line->fk_product];
            $restes[] = array(
                'fk_product' => (int) $product->id,
                'facture_ref' => $facture->ref,
                'ref' => $product->ref,
                'label' => $product->label,
                'qty' => max(0, $qty_cmd - $totalStock),
            );
        }
    }

    return $restes;
}

function depotSyncRestes($db, $fid, $facture, &$cache) {
    $work = depotGetWorkRow($db, $fid, $cache);
    if (!$work) return false;

    $work_id = (int) $work->rowid;
    $sql = "UPDATE ".MAIN_DB_PREFIX."depot_restes SET archived = 1, archived_on = NOW() WHERE fk_depot_work = ".((int)$work_id)." AND resolved = 0";
    $db->query($sql);

    $restes = depotComputeRestes($db, $facture, $cache);
    foreach ($restes as $r) {
        $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_restes
            (fk_depot_work, fk_facture, fk_product, facture_ref, product_ref, product_label, qty_manquante, detected_on, resolved, archived)
            VALUES
            (".$work_id.", ".((int)$fid).", ".((int)$r['fk_product']).", '".$db->escape($r['facture_ref'])."', '".$db->escape($r['ref'])."', '".$db->escape($r['label'])."', ".((float)$r['qty']).", NOW(), 0, 0)
            ON DUPLICATE KEY UPDATE
            qty_manquante = VALUES(qty_manquante),
            archived = 0,
            archived_on = NULL";
        $db->query($sql);
    }

    return true;
}

function depotGetRestes($db, $work_id) {
    $sql = "SELECT fk_product, facture_ref, product_ref, product_label, qty_manquante, detected_on
            FROM ".MAIN_DB_PREFIX."depot_restes
            WHERE fk_depot_work = ".((int)$work_id)." AND resolved = 0 AND archived = 0
            ORDER BY detected_on DESC";
    $restes = array();
    $res = $db->query($sql);

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $restes[] = array(
                'fk_product' => (int) $obj->fk_product,
                'facture_ref' => $obj->facture_ref,
                'ref' => $obj->product_ref,
                'label' => $obj->product_label,
                'qty' => $obj->qty_manquante,
                'time' => date('H:i', strtotime($obj->detected_on)),
            );
        }
    }

    return $restes;
}


function depotGetLivraison($db, $fk_facture)
{
    $fk_facture = (int) $fk_facture;

    $sql = "SELECT rowid, fk_facture, telephone, note, date_prevue_livraison
            FROM ".MAIN_DB_PREFIX."depot_livraisons
            WHERE fk_facture = ".$fk_facture."
            LIMIT 1";

    $resql = $db->query($sql);

    if ($resql && ($obj = $db->fetch_object($resql))) {
        return $obj;
    }

    return null;
}


function depotSaveLivraison($db, $fk_facture, $telephone, $note, $date_prevue_livraison)
{
    $fk_facture = (int) $fk_facture;
    $telephone = trim($telephone);
    $note = trim($note);
    $date_prevue_livraison = trim($date_prevue_livraison);

    $sql = "INSERT INTO ".MAIN_DB_PREFIX."depot_livraisons (
                fk_facture,
                telephone,
                note,
                date_prevue_livraison,
                date_creation
            ) VALUES (
                ".$fk_facture.",
                '".$db->escape($telephone)."',
                '".$db->escape($note)."',
                ".(!empty($date_prevue_livraison)
                    ? "'".$db->escape($date_prevue_livraison)."'"
                    : "NULL").",
                NOW()
            )
            ON DUPLICATE KEY UPDATE
                telephone = VALUES(telephone),
                note = VALUES(note),
                date_prevue_livraison = VALUES(date_prevue_livraison),
                tms = NOW()";

    return $db->query($sql);
}

function depotCheckProductStock($db, $fk_product, $qty_needed, &$cache) {
    $stockData = depotGetProductStockByWarehouse_cached($db, $fk_product, $cache);
    return ((float) $stockData['total'] >= (float) $qty_needed);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['token'])) accessforbidden();

    // Variable pour le message de notification
    $notification_message = '';
    $notification_type    = 'success';

    $telephone_livraison = GETPOST('telephone_livraison', 'alphanohtml');
    $note_livraison = GETPOST('note_livraison', 'restricthtml');
    $date_prevue_livraison = GETPOST('date_prevue_livraison', 'alpha');

    // Actions liées à une facture (id > 0)
    if ($id > 0) {
        $facture = new Facture($db);
        $facture->fetch($id);
        $is_validated = ((int) $facture->statut === 1);
       if ($action === 'save_livraison') {
            $todayDeliveryMin = date('Y-m-d');

            if (
                !empty($date_prevue_livraison)
                && $date_prevue_livraison < $todayDeliveryMin
            ) {
                $_SESSION['depot_notification_message'] = 'La date prévue de livraison ne peut pas être antérieure à aujourd’hui';
                $_SESSION['depot_notification_type'] = 'error';

                header('Location: '.$phpSelf.'?view=reste');
                exit;
            }

            $resultSaveLivraison = depotSaveLivraison(
                $db,
                $id,
                $telephone_livraison,
                $note_livraison,
                $date_prevue_livraison
            );

            if ($resultSaveLivraison > 0) {
                $_SESSION['depot_notification_message'] = 'Informations de livraison enregistrées';
                $_SESSION['depot_notification_type'] = 'success';
            } else {
                $_SESSION['depot_notification_message'] = 'Erreur : informations de livraison non enregistrées - '.$db->lasterror();
                $_SESSION['depot_notification_type'] = 'error';
            }

            header('Location: '.$phpSelf.'?view=reste');
            exit;
        }

        if ($action === 'start') {
            depotUpsertWorkRow($db, $id, array(
                'status' => 'en_cours',
                'start_time' => time(),
                'validated_on' => $is_validated ? time() : null,
            ));
            $notification_message = 'Préparation démarrée';

        } elseif ($action === 'finish') {
            $work = depotGetWorkRow($db, $id, $cache);
            $start = !empty($work->start_time) ? strtotime($work->start_time) : time();
            $duration = time() - $start;

            if ($is_validated) {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'livre',
                    'duration' => $duration,
                    'finish_time' => time(),
                    'delivered_on' => time(),
                    'validated_on' => $work->validated_on ?? null,
                ));
                $notification_message = 'Commande livrée';
            } else {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'prepare',
                    'duration' => $duration,
                    'finish_time' => time(),
                    'validated_on' => $work->validated_on ?? null,
                ));
                $notification_message = 'Commande préparée';
            }

            depotSyncRestes($db, $id, $facture, $cache);

        } elseif ($action === 'deliver') {
            $work = depotGetWorkRow($db, $id, $cache);

            if (!empty($fk_product)) {
                $sql = "UPDATE ".MAIN_DB_PREFIX."depot_restes
                        SET resolved = 1, resolved_on = NOW(), archived = 1, archived_on = NOW()
                        WHERE fk_facture = ".((int)$id)."
                          AND fk_product = ".((int)$fk_product)."
                          AND resolved = 0
                        LIMIT 1";
                $db->query($sql);

                $remaining_sql = "SELECT COUNT(*) as nb
                                  FROM ".MAIN_DB_PREFIX."depot_restes
                                  WHERE fk_facture = ".((int)$id)."
                                    AND resolved = 0
                                    AND archived = 0";
                $res_rem = $db->query($remaining_sql);
                $nb_remaining = 0;
                if ($res_rem && ($obj_rem = $db->fetch_object($res_rem))) {
                    $nb_remaining = (int) $obj_rem->nb;
                }

                if ($nb_remaining == 0) {
                    depotUpsertWorkRow($db, $id, array(
                        'status' => 'livre',
                        'duration' => (int)($work->duration ?? 0),
                        'finish_time' => time(),
                        'delivered_on' => time(),
                    ));
                    $notification_message = 'Commande livrée';
                } else {
                    $notification_message = 'Ligne livrée';
                }
            } else {
                depotUpsertWorkRow($db, $id, array(
                    'status' => 'livre',
                    'duration' => (int)($work->duration ?? 0),
                    'finish_time' => time(),
                    'delivered_on' => time(),
                ));
                depotSyncRestes($db, $id, $facture, $cache);
                $notification_message = 'Commande livrée';
            }

        } elseif ($action === 'archive') {
            $work = depotGetWorkRow($db, $id, $cache);
            $current_status = $work ? $work->status : 'a_preparer';
            depotUpsertWorkRow($db, $id, array(
                'status' => $current_status,
                'archived' => 1,
                'archived_on' => time(),
            ));
            $notification_message = 'Commande archivée';
        }

        // Sauvegarder la notification en session
        if (!empty($notification_message)) {
            $_SESSION['depot_notification_message'] = $notification_message;
            $_SESSION['depot_notification_type']    = $notification_type;
        }

        header('Location: '.$phpSelf.'?view='.$view);
        exit;
    }

    // Action globale (sans id) : TOUT ARCHIVER
    if ($action === 'archive_all') {
        $sql = "UPDATE ".MAIN_DB_PREFIX."depot_work
                SET archived = 1, archived_on = NOW()
                WHERE status = 'livre' AND archived = 0";
        $db->query($sql);

        $_SESSION['depot_notification_message'] = 'Toutes les commandes livrées ont été archivées';
        $_SESSION['depot_notification_type']    = 'success';

        header('Location: '.$phpSelf.'?view=livre');
        exit;
    }

    // Action globale (sans id) : EXPEDIABLE pour toutes les factures totalement disponibles
    if ($action === 'deliver_all') {
        $expediable_ids_str = GETPOST('expediable_ids', 'alpha');
        $expediable_ids = array();

        if (!empty($expediable_ids_str)) {
            foreach (explode(',', $expediable_ids_str) as $fid) {
                $fid = (int) trim($fid);
                if ($fid > 0) $expediable_ids[] = $fid;
            }
        }

        if (!empty($expediable_ids)) {
            foreach ($expediable_ids as $fid) {
                $facture = new Facture($db);
                $facture->fetch($fid);

                $work = depotGetWorkRow($db, $fid, $cache);
                depotUpsertWorkRow($db, $fid, array(
                    'status' => 'livre',
                    'duration' => (int)($work && $work->duration ? $work->duration : 0),
                    'finish_time' => time(),
                    'delivered_on' => time(),
                ));

                $sql = "UPDATE ".MAIN_DB_PREFIX."depot_restes
                        SET resolved = 1, resolved_on = NOW(), archived = 1, archived_on = NOW()
                        WHERE fk_facture = ".$fid." AND resolved = 0 AND archived = 0";
                $db->query($sql);
            }
        }

        $_SESSION['depot_notification_message'] = 'Toutes les commandes disponibles ont été livrées';
        $_SESSION['depot_notification_type']    = 'success';

        header('Location: '.$phpSelf.'?view=reste');
        exit;
    }
}

    llxHeader('', 'Espace Responsable Dépôt');

    // Notification popup (flash)
$notifMessage = '';
$notifType = '';

if (!empty($_SESSION['depot_notification_message'])) {
    $notifMessage = $_SESSION['depot_notification_message'];
    $notifType = !empty($_SESSION['depot_notification_type']) ? $_SESSION['depot_notification_type'] : 'success';
    unset($_SESSION['depot_notification_message'], $_SESSION['depot_notification_type']);
}

if (!empty($notifMessage)) {
    print '<div id="depot-notif" class="depot-notif depot-notif-'.$notifType.'">';
    print dol_escape_htmltag($notifMessage);
    print '</div>';
}

print '<style>

.depot-notif {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    padding: 10px 16px;
    border-radius: 4px;
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}
.depot-notif-success {
    background: #27ae60;
}
.depot-notif-error {
    background: #c0392b;
}

.depot-wrap { margin-top: 20px; }
.depot-toolbar { margin-top: 20px; padding: 10px 12px; background: #fff; border: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center; gap: 10px; }
.depot-title { margin: 0; font-size: 18px; color: #333; }
.depot-btn { padding: 8px 12px; border: 1px solid #999; background: #f7f7f7; color: #222; cursor: pointer; font-weight: bold; text-decoration: none; display: inline-block; }
.depot-btn:hover { background: #efefef; }
.depot-panel { background: #fff; padding: 12px; margin-bottom: 15px; border: 1px solid #ddd; }
.depot-note { background: #f8fbff; border: 1px solid #d6e6f7; padding: 12px; margin-bottom: 16px; }
.depot-table { width: 100%; border-collapse: collapse; background: #fff; border: 1px solid #ddd; font-size: 14px; }
.depot-table th, .depot-table td { border: 1px solid #e3e3e3; padding: 8px 10px; vertical-align: top; }
.depot-table th { background: #f2f2f2; text-align: left; }
.depot-table tr:nth-child(even) td { background: #fafafa; }
.depot-status-ok { background: #eaf7ee; color: #1f7a39; padding: 10px; margin-bottom: 10px; }
.depot-status-warn { background: #fff4db; color: #8a5a00; padding: 10px; margin-bottom: 10px; }
.depot-status-blue { background: #eef6ff; color: #1457a6; padding: 10px; margin-bottom: 10px; }
.depot-status-muted { background: #f3f4f6; color: #333; padding: 10px; margin-bottom: 10px; }
.depot-form { margin-top: 12px; }
.depot-form-btn { padding: 8px 14px; border: 1px solid #888; background: #f7f7f7; cursor: pointer; font-weight: bold; }
.depot-form-btn-success { background: #27ae60; color: #fff; border-color: #27ae60; }
.depot-form-btn-primary { background: #2980b9; color: #fff; border-color: #2980b9; }
.depot-arch-btn { background: #fff; color: #1f7a39; border: 1px solid #1f7a39; padding: 5px 10px; cursor: pointer; font-weight: bold; }

.depot-reste-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin: 8px 0 16px;
}

.depot-reste-card {
    border: 1px solid #e2e8f0;
    border-left: 5px solid #dc2626;
    border-radius: 8px;
    background: #fff;
    padding: 0;
    margin-bottom: 16px;
    overflow: hidden;
}

.depot-reste-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 16px;
    padding: 14px 16px;
    background: #fff7f7;
    border-bottom: 1px solid #fee2e2;
}

.depot-reste-facture {
    font-size: 17px;
    font-weight: bold;
    color: #991b1b;
}

.depot-reste-client {
    margin-top: 4px;
    color: #475569;
    font-size: 14px;
}

.depot-reste-status {
    white-space: nowrap;
    display: inline-block;
    padding: 6px 10px;
    border-radius: 999px;
    background: #fee2e2;
    color: #b91c1c;
    font-size: 12px;
    font-weight: bold;
}

.depot-livraison-summary {
    display: grid;
    grid-template-columns: repeat(3, minmax(170px, 1fr));
    gap: 10px;
    padding: 12px 16px;
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
}

.depot-livraison-item {
    padding: 9px 10px;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: #fff;
    font-size: 13px;
    color: #334155;
}

.depot-livraison-label {
    display: block;
    margin-bottom: 4px;
    font-size: 11px;
    font-weight: bold;
    color: #64748b;
    text-transform: uppercase;
}

.depot-livraison-form {
    margin: 12px 16px;
    padding: 12px;
    border: 1px solid #bfdbfe;
    border-radius: 6px;
    background: #f8fbff;
}

.depot-livraison-form-title {
    margin-bottom: 10px;
    font-size: 14px;
    font-weight: bold;
    color: #1457a6;
}

.depot-livraison-grid {
    display: grid;
    grid-template-columns: minmax(220px, 1fr) minmax(190px, 250px);
    gap: 10px;
}

.depot-livraison-field label {
    display: block;
    margin-bottom: 4px;
    font-size: 12px;
    font-weight: bold;
    color: #475569;
}

.depot-livraison-field input,
.depot-livraison-field textarea {
    width: 100%;
    box-sizing: border-box;
    padding: 8px;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    background: #fff;
}

.depot-livraison-note {
    margin-top: 10px;
}

.depot-livraison-actions {
    margin-top: 10px;
    text-align: right;
}

.depot-reste-products {
    padding: 0 16px 16px;
}

.depot-reste-products-title {
    margin: 14px 0 8px;
    font-size: 13px;
    font-weight: bold;
    color: #475569;
}

.depot-reste-product {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    padding: 12px;
    margin-bottom: 8px;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background: #fff;
}

.depot-reste-product-main {
    min-width: 0;
    flex: 1;
}

.depot-reste-product-name {
    margin-bottom: 7px;
    font-weight: bold;
    color: #1e293b;
}

.depot-reste-product-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 7px 14px;
    color: #475569;
    font-size: 13px;
}

.depot-reste-product-meta strong {
    color: #334155;
}

.depot-reste-product-actions {
    flex: 0 0 auto;
    text-align: right;
}

.depot-reste-global-action {
    margin: 4px 16px 16px;
    padding: 12px;
    border: 1px solid #86efac;
    border-radius: 6px;
    background: #f0fdf4;
    text-align: right;
}

@media screen and (max-width: 800px) {
    .depot-reste-card-header,
    .depot-reste-product {
        display: block;
    }

    .depot-reste-status,
    .depot-reste-product-actions {
        margin-top: 10px;
        text-align: left;
    }

    .depot-livraison-summary,
    .depot-livraison-grid {
        grid-template-columns: 1fr;
    }
}

</style>';

$sql_check = "SELECT count(rowid) as nb FROM ".MAIN_DB_PREFIX."facture WHERE fk_statut IN (0,1) AND entity = ".((int) $conf->entity);
$res_check = $db->query($sql_check);
$nb_actuel = 0;
if ($res_check && ($obj_check = $db->fetch_object($res_check))) {
    $nb_actuel = (int) $obj_check->nb;
}

print '<script>

document.addEventListener("DOMContentLoaded", function() {
    var notif = document.getElementById("depot-notif");
    if (notif) {
        setTimeout(function() {
            notif.style.transition = "opacity 0.5s ease, transform 0.5s ease";
            notif.style.opacity = "0";
            notif.style.transform = "translateY(-10px)";
            setTimeout(function() {
                if (notif && notif.parentNode) {
                    notif.parentNode.removeChild(notif);
                }
            }, 600);
        }, 3000); // 3 secondes avant disparition
    }
});

let currentCount = '.$nb_actuel.';
let lastCount = localStorage.getItem("last_depot_count") || 0;
localStorage.setItem("last_depot_count", currentCount);
function depotFormatHMS(sec) {
    sec = Math.max(0, Math.floor(sec));
    let h = Math.floor(sec / 3600);
    let m = Math.floor((sec % 3600) / 60);
    let s = sec % 60;
    return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
}
function depotStartTimers() {
    document.querySelectorAll("[data-depot-start]").forEach(function(el) {
        let start = parseInt(el.getAttribute("data-depot-start"), 10);
        let target = el.querySelector(".depot-elapsed");
        if (!start || !target) return;
        function tick() {
            target.textContent = depotFormatHMS((Date.now() - (start * 1000)) / 1000);
        }
        tick();
        setInterval(tick, 1000);
    });
}
document.addEventListener("DOMContentLoaded", depotStartTimers);
</script>';

if ($view === 'preparation') {
    print '<script>
    (function() {
        var depotPreparationRefreshInProgress = false;
        var depotPreparationRefreshDelay = 2000;

        function depotRefreshPreparation() {
            if (depotPreparationRefreshInProgress) {
                return;
            }

            depotPreparationRefreshInProgress = true;

            var url = window.location.pathname
                + "?view=preparation&_="
                + Date.now();

            fetch(url, {
                method: "GET",
                cache: "no-store",
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                }
            })
            .then(function(response) {
                if (!response.ok) {
                    throw new Error("Erreur HTTP");
                }

                return response.text();
            })
            .then(function(html) {
                var parser = new DOMParser();
                var newDocument = parser.parseFromString(html, "text/html");

                var newList = newDocument.getElementById("depot-preparation-list");
                var currentList = document.getElementById("depot-preparation-list");

                if (newList && currentList) {
                    currentList.innerHTML = newList.innerHTML;

                    if (typeof depotStartTimers === "function") {
                        depotStartTimers();
                    }
                }
            })
            .catch(function(error) {
                console.log("Actualisation de préparation impossible :", error);
            })
            .finally(function() {
                depotPreparationRefreshInProgress = false;

                setTimeout(function() {
                    depotRefreshPreparation();
                }, depotPreparationRefreshDelay);
            });
        }

        document.addEventListener("DOMContentLoaded", function() {
            setTimeout(function() {
                depotRefreshPreparation();
            }, depotPreparationRefreshDelay);
        });
    })();
    </script>';
}

print '<div class="depot-toolbar">';
print '<h2 class="depot-title">📦 Gestion de commande</h2>';
print '<div style="display:flex; gap:10px; align-items:center;">';
print '<button type="button" class="depot-btn" onclick="location.reload()">🔄 Actualiser</button>';

if ($view === 'preparation') {
$screenClientUrl = dol_buildpath('/custom/depot/screen_client.php', 1);
print '<a href="'.$screenClientUrl.'" target="_blank" class="depot-btn" style="text-decoration:none;color:#222;">';
print 'Écran client';
print '</a>';

}


if ($view === 'livre') {
    print '<form method="POST" style="margin:0;">';
    print '<input type="hidden" name="token" value="'.newToken().'">';
    print '<input type="hidden" name="view" value="livre">';
    print '<button type="submit" name="action" value="archive_all" class="depot-btn">🗂️ Tout archiver</button>';
    print '</form>';
}


   
print '</div>';
print '</div>';

print '<style>
.depot-float-refresh{
    position:fixed;
    right:18px;
    bottom:18px;
    z-index:9999;
    box-shadow:0 8px 18px rgba(0,0,0,0.15);
    border-radius:999px;
}
</style>';


if ($view === 'archives') {
    print '<form method="GET" style="margin:0 0 20px 0; padding:12px; background:#fff; border:1px solid #ddd; display:flex; gap:10px; align-items:center;">';
    print '<input type="hidden" name="view" value="archives">';
    print '<label for="tranche" style="font-weight:bold;">Filtrer par durée :</label>';
    print '<select name="tranche" id="tranche" style="padding:6px; border:1px solid #ccc;">';
    print '<option value="">-- Toutes les durées --</option>';
    print '<option value="<5min" '.($tranche === '<5min' ? 'selected' : '').'>Moins de 5 min</option>';
    print '<option value="5-15min" '.($tranche === '5-15min' ? 'selected' : '').'>5 à 15 min</option>';
    print '<option value="15-30min" '.($tranche === '15-30min' ? 'selected' : '').'>15 à 30 min</option>';
    print '<option value="30-60min" '.($tranche === '30-60min' ? 'selected' : '').'>30 à 60 min</option>';
    print '<option value=">1h" '.($tranche === '>1h' ? 'selected' : '').'>Plus de 1 h</option>';
    print '</select>';
    print '<button type="submit" class="depot-btn">Filtrer</button>';
    print '<a href="'.$phpSelf.'?view=archives" class="depot-btn" style="text-decoration:none;">Réinitialiser</a>';
    print '</form>';
}

if ($view === 'reste') {
    print '<div class="depot-wrap">';

    $sql = "SELECT DISTINCT w.fk_facture
            FROM ".MAIN_DB_PREFIX."depot_work w
            INNER JOIN ".MAIN_DB_PREFIX."depot_restes r ON r.fk_depot_work = w.rowid
            WHERE r.resolved = 0
              AND r.archived = 0";

    $res = $db->query($sql);

    $allRestes = array();

    if ($res) {
        while ($obj = $db->fetch_object($res)) {
            $fid = (int) $obj->fk_facture;

            $work = depotGetWorkRow($db, $fid, $cache);

            if ($work) {
                $allRestes[$fid] = depotGetRestes(
                    $db,
                    (int) $work->rowid
                );
            }
        }
    }

    if (!empty($allRestes)) {
        print '<div class="depot-reste-title">';
        print '<h2 style="color:#666; margin:0;">⚠️ Restes à livrer</h2>';
        print '</div>';

        /*
         * 1. Construire la liste des factures totalement expédiables.
         * Logique métier inchangée.
         */
        $expediableIds = array();

        foreach ($allRestes as $factid => $lesrestes) {
            $livraisonCheck = depotGetLivraison($db, $factid);

            $hasLivraisonInfoCheck = (
                $livraisonCheck
                && !empty(trim($livraisonCheck->telephone))
                && !empty(trim($livraisonCheck->note))
                && !empty($livraisonCheck->date_prevue_livraison)
            );

            $allAvailableForFacture = true;

            foreach ($lesrestes as $rcheck) {
                if (!depotCheckProductStock(
                    $db,
                    $rcheck['fk_product'],
                    $rcheck['qty'],
                    $cache
                )) {
                    $allAvailableForFacture = false;
                    break;
                }
            }

            if ($allAvailableForFacture && $hasLivraisonInfoCheck) {
                $expediableIds[] = (int) $factid;
            }
        }

        $lastExpediableId = null;

        if (!empty($expediableIds)) {
            $lastExpediableId = end($expediableIds);
            reset($expediableIds);
        }

        /*
         * Trier : A commander d’abord, expédiable ensuite.
         * Logique métier inchangée.
         */
        $sortedRestes = array();

        foreach ($allRestes as $factid => $lesrestes) {
            if (!in_array((int) $factid, $expediableIds, true)) {
                $sortedRestes[$factid] = $lesrestes;
            }
        }

        foreach ($expediableIds as $expid) {
            if (isset($allRestes[$expid])) {
                $sortedRestes[$expid] = $allRestes[$expid];
            }
        }

        $allRestes = $sortedRestes;

        // Date minimale autorisée pour une livraison : aujourd'hui
        $todayDeliveryMin = date('Y-m-d');

        /*
         * 2. Affichage des factures.
         */
        foreach ($allRestes as $fact_id => $les_restes) {
            $facturetmp = new Facture($db);
            $facturetmp->fetch($fact_id);

            $soctmp = new Societe($db);
            $soctmp->fetch($facturetmp->socid);

            $livraison = depotGetLivraison($db, (int) $fact_id);

            $telephoneLivraison = '';
            $noteLivraison = '';
            $datePrevueLivraison = '';

            if ($livraison) {
                $telephoneLivraison = !empty($livraison->telephone)
                    ? $livraison->telephone
                    : '';

                $noteLivraison = !empty($livraison->note)
                    ? $livraison->note
                    : '';

                $datePrevueLivraison = !empty($livraison->date_prevue_livraison)
                    ? $livraison->date_prevue_livraison
                    : '';
            }

            $hasLivraisonInfo = (
                !empty(trim($telephoneLivraison))
                && !empty(trim($noteLivraison))
                && !empty($datePrevueLivraison)
            );

            print '<div class="depot-reste-card">';

            /*
             * En-tête facture.
             */
            print '<div class="depot-reste-card-header">';

            print '<div>';
            print '<div class="depot-reste-facture">';
            print 'Facture '.dol_escape_htmltag($facturetmp->ref);
            print '</div>';

            print '<div class="depot-reste-client">';
            print dol_escape_htmltag($soctmp->name);
            print '</div>';
            print '</div>';

            print '<span class="depot-reste-status">Reste à livrer</span>';

            print '</div>';

            /*
             * Résumé informations de livraison.
             */
            print '<div class="depot-livraison-summary">';

            print '<div class="depot-livraison-item">';
            print '<span class="depot-livraison-label">Téléphone</span>';
            print dol_escape_htmltag(
                !empty($telephoneLivraison)
                    ? $telephoneLivraison
                    : 'Non renseigné'
            );
            print '</div>';

            print '<div class="depot-livraison-item">';
            print '<span class="depot-livraison-label">Date prévue</span>';
            print dol_escape_htmltag(
                !empty($datePrevueLivraison)
                    ? $datePrevueLivraison
                    : 'Non renseignée'
            );
            print '</div>';

            print '<div class="depot-livraison-item">';
            print '<span class="depot-livraison-label">Note</span>';
            print dol_escape_htmltag(
                !empty($noteLivraison)
                    ? $noteLivraison
                    : 'Aucune note'
            );
            print '</div>';

            print '</div>';

            /*
             * Formulaire informations de livraison.
             */
            print '<form method="POST" class="depot-livraison-form">';

            print '<input type="hidden" name="token" value="'.newToken().'">';
            print '<input type="hidden" name="view" value="reste">';
            print '<input type="hidden" name="id" value="'.((int) $fact_id).'">';
            print '<input type="hidden" name="action" value="save_livraison">';

            print '<div class="depot-livraison-form-title">';
            print 'Informations de livraison';
            print '</div>';

            print '<div class="depot-livraison-grid">';

            print '<div class="depot-livraison-field">';
            print '<label>Téléphone de livraison</label>';
            print '<input type="text" name="telephone_livraison" value="'.dol_escape_htmltag($telephoneLivraison).'">';
            print '</div>';

            print '<div class="depot-livraison-field">';
            print '<label>Date prévue de livraison</label>';
            print '<input type="date" name="date_prevue_livraison" min="'.dol_escape_htmltag($todayDeliveryMin).'" value="'.dol_escape_htmltag($datePrevueLivraison).'">';
            print '</div>';

            print '</div>';

            print '<div class="depot-livraison-field depot-livraison-note">';
            print '<label>Note de livraison</label>';
            print '<textarea name="note_livraison" rows="2">'.dol_escape_htmltag($noteLivraison).'</textarea>';
            print '</div>';

            print '<div class="depot-livraison-actions">';
            print '<button type="submit" class="depot-form-btn depot-form-btn-primary">Enregistrer</button>';
            print '</div>';

            print '</form>';

            /*
             * Produits manquants.
             */
            print '<div class="depot-reste-products">';
            print '<div class="depot-reste-products-title">Produits restant à livrer</div>';

            foreach ($les_restes as $r) {
                $isAvailable = depotCheckProductStock(
                    $db,
                    $r['fk_product'],
                    $r['qty'],
                    $cache
                );

                $product = new Product($db);
                $currentStock = 0;
                $detailedLoc = '';

                if ($product->fetch($r['fk_product']) > 0) {
                    $currentStock = (int) ($product->stock_reel ?? 0);

                    $detailedLoc = depotGetDetailedLocation_cached(
                        $db,
                        $r['fk_product'],
                        $cache
                    );
                }

                print '<div class="depot-reste-product">';

                print '<div class="depot-reste-product-main">';

                print '<div class="depot-reste-product-name">';
                print '<a href="'.DOL_URL_ROOT.'/product/card.php?id='.((int) $r['fk_product']).'" target="_blank" rel="noopener">';
                print dol_escape_htmltag($r['ref']);
                print '</a>';
                print ' — '.dol_escape_htmltag($r['label']);
                print '</div>';

                print '<div class="depot-reste-product-meta">';

                print '<span><strong>Manquant :</strong> ';
                print number_format($r['qty'], 0, ',', ' ');
                print '</span>';

                print '<span><strong>Stock :</strong> ';
                print number_format($currentStock, 0, ',', ' ');
                print '</span>';

                print '<span><strong>Emplacement :</strong> ';
                print $detailedLoc;
                print '</span>';

                print '<span><strong>Signalé :</strong> ';
                print dol_escape_htmltag($r['time']);
                print '</span>';

                print '</div>';
                print '</div>';

                /*
                 * Action de ligne.
                 */
                print '<div class="depot-reste-product-actions">';
                print '<form method="POST" class="depot-form" style="margin:0;">';

                print '<input type="hidden" name="token" value="'.newToken().'">';
                print '<input type="hidden" name="view" value="reste">';
                print '<input type="hidden" name="id" value="'.((int) $fact_id).'">';
                print '<input type="hidden" name="fk_product" value="'.((int) $r['fk_product']).'">';

                if (!$hasLivraisonInfo) {
                    print '<button type="button" class="depot-form-btn" disabled style="color:#666; background:#ddd; border-color:#ddd; cursor:not-allowed;">';
                    print 'Informations livraison requises';
                    print '</button>';

                } elseif (!$isAvailable) {
                    print '<button type="button" class="depot-form-btn" disabled style="color:#666; background:#ddd; border-color:#ddd; cursor:not-allowed;">';
                    print 'A commander';
                    print '</button>';

                } else {
                    print '<button type="submit" name="action" value="deliver" class="depot-form-btn depot-form-btn-success">';
                    print 'Livrer cette ligne';
                    print '</button>';
                }

                print '</form>';
                print '</div>';

                print '</div>';
            }

            print '</div>';

            /*
             * Bouton global.
             */
            if (
                !empty($expediableIds)
                && $lastExpediableId !== null
                && (int) $fact_id === (int) $lastExpediableId
            ) {
                print '<div class="depot-reste-global-action">';

                print '<form method="POST" class="depot-form" style="margin:0;">';

                print '<input type="hidden" name="token" value="'.newToken().'">';
                print '<input type="hidden" name="view" value="reste">';
                print '<input type="hidden" name="action" value="deliver_all">';
                print '<input type="hidden" name="expediable_ids" value="'.dol_escape_htmltag(implode(',', $expediableIds)).'">';

                print '<button type="submit" class="depot-form-btn depot-form-btn-success">';
                print '🚚 Livrer toutes les factures disponibles';
                print '</button>';

                print '</form>';

                print '</div>';
            }

            print '</div>';
        }

    } else {
        print '<p style="color:#666;">⚠️ Aucun reste à livrer.</p>';
    }

    print '</div>';
    llxFooter();
    exit;
}

if ($view === 'archives') {
    print '<div class="depot-wrap">';
    print '<h2 style="color:#666;">📚 Archives des Commandes Livrées</h2>';

    $duration_filter = '';
    if (!empty($tranche)) {
        if ($tranche === '<5min') $duration_filter = ' AND w.duration < 300';
        elseif ($tranche === '5-15min') $duration_filter = ' AND w.duration >= 300 AND w.duration < 900';
        elseif ($tranche === '15-30min') $duration_filter = ' AND w.duration >= 900 AND w.duration < 1800';
        elseif ($tranche === '30-60min') $duration_filter = ' AND w.duration >= 1800 AND w.duration < 3600';
        elseif ($tranche === '>1h') $duration_filter = ' AND w.duration >= 3600';
    }

    $sql = "SELECT w.rowid, w.fk_facture, w.status, w.duration, w.archived, w.archived_on
            FROM ".MAIN_DB_PREFIX."depot_work w
            WHERE w.archived = 1 AND w.status = 'livre'".$duration_filter."
            ORDER BY w.archived_on DESC, w.tms DESC";
    $resql = $db->query($sql);

    $archives = array();
    if ($resql && $db->num_rows($resql) > 0) {
        while ($w = $db->fetch_object($resql)) {
            $facture = new Facture($db);
            if ($facture->fetch((int) $w->fk_facture) <= 0) continue;
            $archives[] = array('facture' => $facture, 'work' => $w, 'duration' => (int) $w->duration);
        }
    }

    if (!empty($archives)) {
        print '<table class="depot-table">';
        print '<tr><th>Facture</th><th>Produit</th><th>Libellé</th><th>Qté</th><th>Emplacement</th><th>Durée</th></tr>';
        foreach ($archives as $arch) {
            $facture = $arch['facture'];
            $dur = $arch['duration'];
            $soc = new Societe($db);
            $soc->fetch($facture->socid);

            foreach ($facture->lines as $line) {
                if (empty($line->fk_product)) continue;
                $product = new Product($db);
                $product->fetch($line->fk_product);
                $detailedLoc = depotGetDetailedLocation_cached($db, $product->id, $cache);

                print '<tr>';
                print '<td>'.dol_escape_htmltag($facture->ref).' | '.dol_escape_htmltag($soc->name).'</td>';
                print '<td><a href="'.DOL_URL_ROOT.'/product/card.php?id='.(int)$product->id.'" target="_blank" rel="noopener">'.dol_escape_htmltag($product->ref).'</a></td>';
                print '<td>'.dol_escape_htmltag($product->label).'</td>';
                print '<td align="center">'.dol_escape_htmltag($line->qty).'</td>';
                print '<td align="center">'.$detailedLoc.'</td>';
                print '<td align="center" style="font-weight:bold; color:#1f7a39;">'.depotDurationPretty($dur).'</td>';
                print '</tr>';
            }
        }
        print '</table>';
    } else {
        print '<p style="color:#666; font-size:16px;">📭 Aucune archive disponible.</p>';
        print '<p style="color:#999; font-size:13px;">Aucune archive correspondante au filtre sélectionné.</p>';
    }

    print '</div>';
    llxFooter();
    exit;
}

if ($view === 'preparation') {
    $sql = "SELECT f.rowid
            FROM ".MAIN_DB_PREFIX."facture f
            INNER JOIN ".MAIN_DB_PREFIX."facturedet fd
                ON fd.fk_facture = f.rowid
               AND fd.fk_product > 0
            LEFT JOIN ".MAIN_DB_PREFIX."depot_work w
                ON w.fk_facture = f.rowid
            WHERE f.entity = ".((int) $conf->entity)."
              AND f.fk_statut IN (0,1)
              AND f.datec >= CURDATE()
              AND f.datec < CURDATE() + INTERVAL 1 DAY
              AND (w.rowid IS NULL OR w.status IN ('a_preparer','en_cours'))
              AND (w.archived IS NULL OR w.archived = 0)
            GROUP BY f.rowid
            ORDER BY f.datec ASC
           LIMIT ".((int) $preparation_limit);
} elseif ($view === 'prepare') {
    $sql = "SELECT w.fk_facture AS rowid
            FROM ".MAIN_DB_PREFIX."depot_work w
            WHERE w.status = 'prepare'
              AND w.archived = 0
            ORDER BY w.tms DESC";
} elseif ($view === 'livre') {
    $sql = "SELECT w.fk_facture AS rowid
            FROM ".MAIN_DB_PREFIX."depot_work w
            WHERE w.status = 'livre'
              AND w.archived = 0
            ORDER BY w.delivered_on DESC";
} else {
    $sql = "SELECT rowid
            FROM ".MAIN_DB_PREFIX."facture
            WHERE fk_statut IN (0,1)
              AND entity = ".((int) $conf->entity)."
            ORDER BY datec DESC";
}

$resql = $db->query($sql);

if ($resql && $db->num_rows($resql) > 0) {
    while ($obj = $db->fetch_object($resql)) {
        $fid = (int) $obj->rowid;
        $facture = new Facture($db);
        if ($facture->fetch($fid) <= 0) continue;

        $work = depotGetWorkRow($db, $fid, $cache);
        if ($work && (int)$work->archived === 1) continue;

        $status = $work ? $work->status : 'a_preparer';
        $isValidated = ((int) $facture->statut === 1);
        $isProv = ((int) $facture->statut === 0);

        if ($view === 'preparation') {
            if ($status === 'livre') continue;
            if ($status === 'prepare') continue;
            if (!($status === 'a_preparer' || $status === 'en_cours')) {
                continue;
            }
            if ($isValidated && !$work) {
                $today = date('Y-m-d');
                $fact_date = !empty($facture->date) ? date('Y-m-d', $facture->date) : '';
                if ($fact_date !== $today) continue;
            }
        } elseif ($view === 'prepare') {
            if ($status !== 'prepare') continue;
        } elseif ($view === 'livre') {
            if ($status !== 'livre') continue;
        } else {
            if ($isValidated && !$work) {
                $today = date('Y-m-d');
                $fact_date = !empty($facture->date) ? date('Y-m-d', $facture->date) : '';
                if ($fact_date !== $today) continue;
            }
        }

            $computedRestes = array();
            $hasRestes = false;

        if ($view !== 'livre') {
            $computedRestes = depotComputeRestes($db, $facture, $cache);
            $hasRestes = !empty($computedRestes);
        } else {
            // En vue "livre", on n'affiche l'alerte que s'il reste vraiment des produits non expédiés
            $remainingCheckSql = "SELECT COUNT(*) as nb
                                FROM ".MAIN_DB_PREFIX."depot_restes
                                WHERE fk_facture = ".((int)$fid)."
                                    AND resolved = 0
                                    AND archived = 0";
            $resRemainingCheck = $db->query($remainingCheckSql);
            $nbRemainingCheck = 0;
            if ($resRemainingCheck && ($objRemainingCheck = $db->fetch_object($resRemainingCheck))) {
                $nbRemainingCheck = (int) $objRemainingCheck->nb;
            }

            if ($nbRemainingCheck > 0) {
                $computedRestes = depotComputeRestes($db, $facture, $cache);
                $hasRestes = !empty($computedRestes);
            }
        }

        $soc = new Societe($db);
        $soc->fetch($facture->socid);

        if ($view === 'prepare') {
            print '<div class="depot-note">';
            print '<strong style="color:#1457a6; font-size:16px;">Commande préparée</strong>';
            print '<p style="color:#444; margin:5px 0 0 0; font-size:14px;">';
            if ($isValidated) {
                print "La facture est validée, vous pouvez livrer la commande maintenant.";
            } else {
                print "La facture est en attente de validation, livrez quand validée.";
            }
            print '</p></div>';
        }

        $startTs = (!empty($work) && !empty($work->start_time)) ? strtotime($work->start_time) : 0;
        print '<div class="depot-panel" data-depot-card="'.$fid.'" data-depot-start="'.$startTs.'">';
        print '<h3>'.dol_escape_htmltag($facture->ref).' | '.dol_escape_htmltag($soc->name).'</h3>';

       if ($status === 'livre') {
            $dur = (int)($work ? $work->duration : 0);
            $durationTxt = 'Durée de préparation '.depotDurationPretty($dur);
            print "<div class='depot-status-ok' style='display:flex; justify-content:space-between; align-items:center;'>";
            print "<span>✅ LIVRÉE ($durationTxt)</span>";
            print "<form method='POST' class='depot-form' style='margin:0;'>";
            print "<input type='hidden' name='token' value='".newToken()."'>";
            print "<input type='hidden' name='view' value='".dol_escape_htmltag($view)."'>";
            print "<input type='hidden' name='id' value='".$fid."'>";
            print "<button type='submit' name='action' value='archive' class='depot-arch-btn'>Archiver</button>";
            print "</form>";
            print "</div>";
        } elseif ($status === 'en_cours') {
            print "<div class='depot-status-warn'>⏳ EN COURS... (⏱ <span class='depot-elapsed'>00:00:00</span>)</div>";
        } elseif ($status === 'prepare') {
            $dur = (int)($work ? $work->duration : 0);
            $durationTxt = depotDurationPretty($dur);
            print "<div class='depot-status-blue' style='display:flex; justify-content:space-between; align-items:center;'>";
            print "<span>✅ EXPEDIABLE (Durée : $durationTxt)</span>";
            if ($isValidated) {
                print "<form method='POST' class='depot-form' style='margin:0;'>";
                print "<input type='hidden' name='token' value='".newToken()."'>";
                print "<input type='hidden' name='view' value='prepare'>";
                print "<input type='hidden' name='id' value='".$fid."'>";
                print "<button type='submit' name='action' value='deliver' class='depot-form-btn depot-form-btn-success'>Livré</button>";
                print "</form>";
            }
            print "</div>";
        } else {
            print "<div class='depot-status-muted'>🕒 En attente de préparation</div>";
        }

        print '<table class="depot-table">';
        print '<tr><th>Réf</th><th>Libellé</th><th>Qté</th><th>Stock/Entrepot</th><th>Emplacement</th><th>Etat</th></tr>';

        if (!empty($facture->lines)) {
            foreach ($facture->lines as $line) {
                if (empty($line->fk_product)) continue;

                if (!isset($cache['products'][$line->fk_product])) {
                    $product = new Product($db);
                    $product->fetch($line->fk_product);
                    $cache['products'][$line->fk_product] = $product;
                }
                $product = $cache['products'][$line->fk_product];

                $qty_cmd = (int) $line->qty;
                $stockData = depotGetProductStockByWarehouse_cached($db, $product->id, $cache);
                $totalStock = (float) $stockData['total'];
                $detailedLoc = depotGetDetailedLocation_cached($db, $product->id, $cache);
                $manquant = max(0, $qty_cmd - $totalStock);

                print '<tr>';
                print '<td><a href="'.DOL_URL_ROOT.'/product/card.php?id='.(int)$product->id.'" target="_blank" rel="noopener">'.dol_escape_htmltag($product->ref).'</a></td>';
                print '<td>'.dol_escape_htmltag($product->label).'</td>';
                print '<td align="center">'.dol_escape_htmltag($qty_cmd).'</td>';
                print '<td align="left">';
                if (!empty($stockData['details'])) {
                    foreach ($stockData['details'] as $s) {
                        if ((float) $s['qty'] > 0) {
                            print dol_escape_htmltag($s['warehouse']).': '.number_format($s['qty'], 0, ',', ' ').'<br>';
                        }
                    }
                    print '<strong>Total: '.number_format($totalStock, 0, ',', ' ').'</strong>';
                } else {
                    print 'Aucun stock';
                }
                print '</td>';
                print '<td align="center">'.$detailedLoc.'</td>';
                print '<td align="center">';
                if ($hasRestes && $manquant > 0) {
                    print '⚠️';
                } elseif ($totalStock < $qty_cmd && $status !== 'livre') {
                    print "<span style='color:#e74c3c; font-weight:bold;'>⚠️</span>";
                } else {
                    print '✅';
                }
                print '</td>';
                print '</tr>';
            }
        }
        print '</table>';

       if ($hasRestes) {
            print "<div class='depot-panel' style='border:1px solid #ef4444; background:#fff8f8; margin-top:10px; color:#b91c1c;'>";
            print "⚠️ <b>Produit non disponible :</b><br>";
            foreach ($computedRestes as $r) {
                print "• <b>".dol_escape_htmltag($r['facture_ref'])."</b> | ".dol_escape_htmltag($r['ref'])." (".dol_escape_htmltag($r['label']).") | Manquant : ".number_format($r['qty'], 0, ',', ' ')."<br>";
            }
            print "</div>";
        }
        if ($view === 'preparation' && $status !== 'livre') {
            print "<form method='POST' class='depot-form'>";
            print "<input type='hidden' name='token' value='".newToken()."'>";
            print "<input type='hidden' name='view' value='preparation'>";
            print "<input type='hidden' name='id' value='".$fid."'>";

            if ($status === 'a_preparer') {
                print "<button type='submit' name='action' value='start' class='depot-form-btn depot-form-btn-primary'>▶ COMMENCER LA PRÉPARATION</button>";
            } elseif ($status === 'en_cours') {
                print "<button type='submit' name='action' value='finish' class='depot-form-btn depot-form-btn-success'>✅ PRET</button>";
            } elseif ($status === 'prepare' && $isValidated) {
                print "<button type='submit' name='action' value='deliver' class='depot-form-btn depot-form-btn-success'>🚚 Livré</button>";
            }

            print '</form>';
        }

        print '</div>';
    }
} else {
    if($view === 'preparation') {
      print '<p>Aucune commande à préparer.</p>';
    } elseif($view === 'prepare'){
        print '<p>Aucune commande n\'a été préparée.</p>';
    } elseif($view === 'livre'){
        print '<p>Aucune commande n\'a été livrée.</p>';
    }
    
}

llxFooter();
?>

