CREATE TABLE IF NOT EXISTS llx_depot_location (
    rowid INT AUTO_INCREMENT PRIMARY KEY,
    ref VARCHAR(80) NOT NULL,
    label VARCHAR(180) NOT NULL,
    active TINYINT DEFAULT 1,
    entity INT DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS llx_depot_room (
    rowid INT AUTO_INCREMENT PRIMARY KEY,
    fk_depot_location INT NOT NULL,
    ref VARCHAR(80) NOT NULL,
    label VARCHAR(180) NOT NULL,
    active TINYINT DEFAULT 1,
    entity INT DEFAULT 1,
    CONSTRAINT fk_depot_room_location
        FOREIGN KEY (fk_depot_location)
        REFERENCES llx_depot_location(rowid)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS llx_depot_shelf (
    rowid INT AUTO_INCREMENT PRIMARY KEY,
    fk_depot_room INT NOT NULL,
    letter VARCHAR(3) NOT NULL,
    label VARCHAR(80) NOT NULL,
    active TINYINT DEFAULT 1,
    entity INT DEFAULT 1,
    CONSTRAINT fk_depot_shelf_room
        FOREIGN KEY (fk_depot_room)
        REFERENCES llx_depot_room(rowid)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS llx_depot_shelf_line (
    rowid INT AUTO_INCREMENT PRIMARY KEY,
    fk_depot_shelf INT NOT NULL,
    line_number INT NOT NULL,
    label VARCHAR(80) NOT NULL,
    active TINYINT DEFAULT 1,
    entity INT DEFAULT 1,
    CONSTRAINT fk_depot_line_shelf
        FOREIGN KEY (fk_depot_shelf)
        REFERENCES llx_depot_shelf(rowid)
) ENGINE=InnoDB;