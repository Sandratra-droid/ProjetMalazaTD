<?php
/* Copyright (C) 2026		SuperAdmin
 * Copyright (C) 2025       Frédéric France         <frederic.france@free.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    depot/lib/depot.lib.php
 * \ingroup depot
 * \brief   Library files with common functions for Depot
 */

/**
 * Prepare admin pages header
 *
 * @return array<array{string,string,string}>
 */
function depotAdminPrepareHead()
{
	global $langs, $conf;

	// global $db;
	// $extrafields = new ExtraFields($db);
	// $extrafields->fetch_name_optionals_label('myobject');

	$langs->load("depot@depot");

	$h = 0;
	$head = array();

	$head[$h][0] = dolBuildUrl(dol_buildpath("/depot/admin/setup.php", 1));
	$head[$h][1] = $langs->trans("Settings");
	$head[$h][2] = 'settings';
	$h++;

	/*
	$head[$h][0] = dolBuildUrl(dol_buildpath("/depot/admin/myobject_extrafields.php", 1));
	$head[$h][1] = $langs->trans("ExtraFields");
	$nbExtrafields = (isset($extrafields->attributes['myobject']['label']) && is_countable($extrafields->attributes['myobject']['label'])) ? count($extrafields->attributes['myobject']['label']) : 0;
	if ($nbExtrafields > 0) {
		$head[$h][1] .= '<span class="badge marginleftonlyshort">' . $nbExtrafields . '</span>';
	}
	$head[$h][2] = 'myobject_extrafields';
	$h++;

	$head[$h][0] = dolBuildUrl(dol_buildpath("/depot/admin/myobjectline_extrafields.php", 1));
	$head[$h][1] = $langs->trans("ExtraFieldsLines");
	$nbExtrafields = (isset($extrafields->attributes['myobjectline']['label']) && is_countable($extrafields->attributes['myobjectline']['label'])) ? count($extrafields->attributes['myobject']['label']) : 0;
	if ($nbExtrafields > 0) {
		$head[$h][1] .= '<span class="badge marginleftonlyshort">' . $nbExtrafields . '</span>';
	}
	$head[$h][2] = 'myobject_extrafieldsline';
	$h++;
	*/

	$head[$h][0] = dolBuildUrl(dol_buildpath("/depot/admin/about.php", 1));
	$head[$h][1] = $langs->trans("About");
	$head[$h][2] = 'about';
	$h++;

	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@depot:/depot/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@depot:/depot/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, null, $head, $h, 'depot@depot');

	complete_head_from_modules($conf, $langs, null, $head, $h, 'depot@depot', 'remove');

	return $head;
}

//Ajouté le 27 oct 2026
/**
 * Convertit la clé d'un extrafield select en libellé lisible.
 * Conserve les anciennes valeurs texte si elles ne sont pas des clés.
 */
function depotLocationOptionLabel($db, $code, $value, &$cache)
{
    global $langs;

    $value = trim((string) $value);

    if ($value === '' || $value === '0') {
        return '';
    }

    if (!isset($cache['depot_location_options'])) {
        require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';

        $extra = new ExtraFields($db);
        $extra->fetch_name_optionals_label('product');

        $cache['depot_location_options'] = array();

        foreach (
            array('localisation', 'salle_depot', 'etagere', 'ligne')
            as $fieldCode
        ) {
            $options = isset(
                $extra->attributes['product']['param'][$fieldCode]['options']
            )
                ? $extra->attributes['product']['param'][$fieldCode]['options']
                : array();

            $cache['depot_location_options'][$fieldCode] =
                is_array($options) ? $options : array();
        }
    }

    $options = isset($cache['depot_location_options'][$code])
        ? $cache['depot_location_options'][$code]
        : array();

    if (array_key_exists($value, $options)) {
        $parts = explode('|', (string) $options[$value], 2);
        $label = trim($parts[0]);

        return $langs->trans($label);
    }

    // Compatibilité avec des valeurs texte déjà enregistrées.
    return $value;
}
