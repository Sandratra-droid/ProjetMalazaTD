<?php
/* Copyright (C) 2004-2018  Laurent Destailleur          <eldy@users.sourceforge.net>
 * Copyright (C) 2018-2019  Nicolas ZABOURI             <info@inovea-conseil.com>
 * Copyright (C) 2019-2024  Frédéric France             <frederic.france@free.fr>
 * Copyright (C) 2026       SuperAdmin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 */


include_once DOL_DOCUMENT_ROOT.'/core/modules/DolibarrModules.class.php';

class modDepot extends DolibarrModules
{
    public function __construct($db)
    {
        global $conf, $langs;

        $this->db = $db;
        $this->numero = 500000;
        $this->rights_class = 'depot';
        $this->family = "other";
        $this->module_position = '90';
        $this->name = preg_replace('/^mod/i', '', get_class($this));
        $this->description = "DepotDescription";
        $this->descriptionlong = "DepotDescription";
        $this->editor_name = 'Malaza-TD Test';
        $this->editor_url = '';
        $this->editor_squarred_logo = '';
        $this->version = '1.0';
        $this->const_name = 'MAIN_MODULE_'.strtoupper($this->name);
        $this->picto = 'fa-file';

        $this->tables = array(
            MAIN_DB_PREFIX.'depot_work',
            MAIN_DB_PREFIX.'depot_restes',
            MAIN_DB_PREFIX.'depot_livraisons_lignes',
            MAIN_DB_PREFIX.'depot_livraisons',
        );
        $this->module_parts = array(
            'triggers' => 0,
            'login' => 0,
            'substitutions' => 0,
            'menus' => 0,
            'tpl' => 0,
            'barcode' => 0,
            'models' => 0,
            'printing' => 0,
            'theme' => 0,
            'css' => array(),
            'js' => array(),
            'hooks' => array(),
            'moduleforexternal' => 0,
            'websitetemplates' => 0,
            'captcha' => 0
        );

        $this->dirs = array("/depot/temp");
        $this->config_page_url = array("setup.php@depot");
        $this->hidden = getDolGlobalInt('MODULE_DEPOT_DISABLED');
        $this->depends = array();
        $this->requiredby = array();
        $this->conflictwith = array();
        $this->langfiles = array("depot@depot");
        $this->phpmin = array(7, 2);
        $this->need_dolibarr_version = array(19, -3);
        $this->need_javascript_ajax = 0;
        $this->warnings_activation = array();
        $this->warnings_activation_ext = array();

        if (!isModEnabled("depot")) {
            $conf->depot = new stdClass();
            $conf->depot->enabled = 0;
        }

        $this->tabs = array();
        $this->dictionaries = array();
        $this->boxes = array();
        $this->cronjobs = array();

        $this->rights = array();
        $r = 0;

        $this->menu = array();
        $r = 0;

        // TOP MENU : Bouton "Depot" dans le menu haut
        $this->menu[$r++] = array(
            'fk_menu' => '',
            'type' => 'top',
            'titre' => 'Préparation',
            'prefix' => img_picto('', 'fa-clipboard', 'class="paddingright pictofixedwidth valignmiddle"'),
            'mainmenu' => 'depot',
            'leftmenu' => '',
            'url' => '/custom/depot/depotindex.php?view=preparation',
            'langs' => 'depot@depot',
            'position' => 1000 + $r,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => '',
            'target' => '',
            'user' => 2,
        );

                // LEFT MENU : En préparation
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'En préparation',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_preparation',
            'url' => '/custom/depot/depotindex.php?view=preparation',
            'langs' => 'depot@depot',
            'position' => 1001,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-clock-o',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Prêt non livré
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Prét non livrable',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_prepare',
            'url' => '/custom/depot/depotindex.php?view=prepare',
            'langs' => 'depot@depot',
            'position' => 1002,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-check',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Livrable & Facturé
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Pret & livrable',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_livre',
            'url' => '/custom/depot/depotindex.php?view=livre',
            'langs' => 'depot@depot',
            'position' => 1003,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-truck',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Livrés
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Livré',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_archives',
            'url' => '/custom/depot/depotindex.php?view=archives',
            'langs' => 'depot@depot',
            'position' => 1004,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-archive',
            'target' => '',
            'user' => 2,
        );


        // LEFT MENU : Reste à livrer
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Reste à livrer',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_reste',
            'url' => '/custom/depot/depotindex.php?view=reste',
            'langs' => 'depot@depot',
            'position' => 1005,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-exclamation-triangle',
            'target' => '',
            'user' => 2,
        );

                // LEFT MENU : Aucun stock
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=depot',
            'type' => 'left',
            'titre' => 'Aucun Stock',
            'mainmenu' => 'depot',
            'leftmenu' => 'depot_sans_stock',
            'url' => '/custom/depot/depotindex.php?view=sans_stock',
            'langs' => 'depot@depot',
            'position' => 1006,
            'enabled' => "isModEnabled('depot')",
            'perms' => '1',
            'icon' => 'fa fa-clock-o',
            'target' => '',
            'user' => 2,
        );
    }

    public function init($options = '')
    {
        /*
        * Création/contrôle des tables SQL du module :
        * custom/depot/sql/
        */
        $result = $this->_load_tables('/depot/sql/');
        if ($result < 0) {
            return -1;
        }

        /*
        * Logique existante du module.
        * Votre méthode remove() actuelle ne contient pas de SQL de suppression.
        */
        $this->remove($options);

        $sql = array();

            /*
        * Création des quatre extrafields d'emplacement Produit.
        * Les champs existants ne sont ni modifiés ni recréés.
        */
        require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';

        $extrafields = new ExtraFields($this->db);

        $fetchResult = $extrafields->fetch_name_optionals_label('product');

        if ($fetchResult < 0) {
            $this->error = $extrafields->error;
            return -1;
        }

        $depotLocationFields = array(
            'localisation' => array(
                'label' => 'Localisation',
                'position' => 100,
                'options' => array(
                    '1' => 'Dépôt Boulangerie',
                    '2' => 'Dépôt Pain'
                )
            ),
            'salle_depot' => array(
                'label' => 'Salle dépôt',
                'position' => 101,
                'options' => array(
                    '11' => 'Salle Boulangerie 1|options_localisation:1',
                    '12' => 'Salle Boulangerie 2|options_localisation:1',
                    '21' => 'Salle Pain 1|options_localisation:2',
                    '22' => 'Salle Pain 2|options_localisation:2'
                )
            ),
            'etagere' => array(
                'label' => 'Étagère',
                'position' => 102,
                'options' => array(
                    '111' => 'A|options_salle_depot:11',
                    '112' => 'B|options_salle_depot:11',
                    '121' => 'A|options_salle_depot:12',
                    '122' => 'B|options_salle_depot:12',
                    '211' => 'A|options_salle_depot:21',
                    '212' => 'B|options_salle_depot:21',
                    '221' => 'A|options_salle_depot:22',
                    '222' => 'B|options_salle_depot:22'
                )
            ),
            'ligne' => array(
                'label' => 'Ligne',
                'position' => 103,
                'options' => array(
                    '1111' => '1|options_etagere:111',
                    '1112' => '2|options_etagere:111',
                    '1121' => '1|options_etagere:112',
                    '1122' => '2|options_etagere:112',
                    '1211' => '1|options_etagere:121',
                    '1212' => '2|options_etagere:121',
                    '1221' => '1|options_etagere:122',
                    '1222' => '2|options_etagere:122',
                    '2111' => '1|options_etagere:211',
                    '2112' => '2|options_etagere:211',
                    '2121' => '1|options_etagere:212',
                    '2122' => '2|options_etagere:212',
                    '2211' => '1|options_etagere:221',
                    '2212' => '2|options_etagere:221',
                    '2221' => '1|options_etagere:222',
                    '2222' => '2|options_etagere:222'
                )
            )
        );

        foreach ($depotLocationFields as $code => $definition) {
            $exists = isset($extrafields->attributes['product']['label'])
                && array_key_exists(
                    $code,
                    $extrafields->attributes['product']['label']
                );

            if ($exists) {
                continue;
            }

            $result = $extrafields->addExtraField(
                $code,                                      // Nom
                $definition['label'],                       // Libellé
                'select',                                   // Liste simple
                $definition['position'],                    // Position
                255,                                        // Taille
                'product',                                  // Objet
                0,                                          // Unique
                0,                                          // Obligatoire
                '',                                         // Défaut
                array('options' => $definition['options']),  // Options
                1,                                          // Toujours éditable
                '',                                         // Permissions
                '1',                                        // Affichage
                '',                                         // Aide
                '',                                         // Calcul
                (int) $conf->entity,                         // Entité
                '',                                         // Langue
                '1'                                         // Activé
            );

            if ($result < 0) {
                $this->error = 'Champ '.$code.' : '.$extrafields->error;
                return -1;
            }
        }

        /*
        * Partie d'origine générée par ModuleBuilder :
        * elle est conservée sans changement.
        */
        $moduledir = dol_sanitizeFileName('depot');

        $myTmpObjects = array();
        $myTmpObjects['MyObject'] = array(
            'includerefgeneration' => 0,
            'includedocgeneration' => 0
        );

        foreach ($myTmpObjects as $myTmpObjectKey => $myTmpObjectArray) {
            if ($myTmpObjectArray['includerefgeneration']) {
                $src = DOL_DOCUMENT_ROOT.'/install/doctemplates/'.$moduledir.'/template_myobjects.odt';
                $dirodt = DOL_DATA_ROOT.($conf->entity > 1 ? '/'.$conf->entity : '').'/doctemplates/'.$moduledir;
                $dest = $dirodt.'/template_myobjects.odt';

                if (file_exists($src) && !file_exists($dest)) {
                    require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';

                    dol_mkdir($dirodt);
                    $result = dol_copy($src, $dest, '0', 0);

                    if ($result < 0) {
                        $langs->load("errors");
                        $this->error = $langs->trans('ErrorFailToCopyFile', $src, $dest);
                        return 0;
                    }
                }

                $sql = array_merge($sql, array(
                    '/depot/sql/llx_depot.sql',

                    "DELETE FROM ".$this->db->prefix()."document_model
                    WHERE nom = 'standard_".strtolower($myTmpObjectKey)."'
                    AND type = '".$this->db->escape(strtolower($myTmpObjectKey))."'
                    AND entity = ".((int) $conf->entity),

                    "INSERT INTO ".$this->db->prefix()."document_model
                    (nom, type, entity)
                    VALUES(
                        'standard_".strtolower($myTmpObjectKey)."',
                        '".$this->db->escape(strtolower($myTmpObjectKey))."',
                        ".((int) $conf->entity)."
                    )",

                    "DELETE FROM ".$this->db->prefix()."document_model
                    WHERE nom = 'generic_".strtolower($myTmpObjectKey)."_odt'
                    AND type = '".$this->db->escape(strtolower($myTmpObjectKey))."'
                    AND entity = ".((int) $conf->entity),

                    "INSERT INTO ".$this->db->prefix()."document_model
                    (nom, type, entity)
                    VALUES(
                        'generic_".strtolower($myTmpObjectKey)."_odt',
                        '".$this->db->escape(strtolower($myTmpObjectKey))."',
                        ".((int) $conf->entity)."
                    )"
                ));
            }
        }

        return $this->_init($sql, $options);
    }

    public function remove($options = '')
    {
        $sql = array();
        return $this->_remove($sql, $options);
    }
}
?>